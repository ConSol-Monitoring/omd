package HP::BladeSystem::Component;

use strict;

our @ISA = qw(HP::BladeSystem);

1;
