<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'Benchmarks',
	'post_data'    => 'Datos Posteados',
	'no_post'      => 'No hay datos posteados',
	'session_data' => 'Datos de sesión',
	'no_session'   => 'No hay datos de sesión',
	'queries'      => 'Consultas a la base de datos',
	'no_queries'   => 'No hay consultas a la base de datos',
	'no_database'  => 'No se encuentra la base de datos',
	'cookie_data'  => 'Datos de la cookie',
	'no_cookie'    => 'No se encuentran los datos de la cookie',
);
