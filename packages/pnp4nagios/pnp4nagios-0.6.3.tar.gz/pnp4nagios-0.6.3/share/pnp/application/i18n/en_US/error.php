<?php defined('SYSPATH') OR die('No direct access allowed.');
$lang = array
(
    'rrdtool-not-found' => 'RRDTool not found in %s. <a href="http://docs.pnp4nagios.org/faq/1">Read FAQ online</a>',
    'config-not-found' => 'Config file %s not found. <a href="http://docs.pnp4nagios.org/faq/2">Read FAQ online</a>',
    'perfdata-dir-empty' => 'perfdata directory "%s" is empty. Please check your Nagios config. <a href="http://docs.pnp4nagios.org/faq/3">Read FAQ online</a>',
    'host-perfdata-dir-empty' => 'perfdata directory "%s" is empty. Please check your Nagios config. <a href="http://docs.pnp4nagios.org/faq/4">Read FAQ online</a>',
    'perfdata-dir-for-host' => 'perfdata directory "%s" for host "%s" does not exist. <a href="http://docs.pnp4nagios.org/faq/5">Read FAQ online</a>',
    'xml-not-found' => 'XML file "%s" not found. <a href="http://docs.pnp4nagios.org/faq/6">Read FAQ online</a>',
    'get-first-service' => 'Can´t find first service for host "%s". <a href="http://docs.pnp4nagios.org/faq/7">Read FAQ online</a>',
    'get-first-host' => 'Can´t find any Host. <a href="http://docs.pnp4nagios.org/faq/8">Read FAQ online</a>',
    'xml-structure-mismatch' => 'XML structure mismatch. Found version "%d" but should be "%d". <a href="http://docs.pnp4nagios.org/faq/9">Read FAQ online</a>',
    'save-rrd-image' => 'php fopen("%s") failed. <a href="http://docs.pnp4nagios.org/faq/10">Read FAQ online</a>',
	'xml-structure-without-version-tag' => 'XML structure mismatch. Version tag not found in "%s". <a href="http://docs.pnp4nagios.org/faq/11">Read FAQ online</a>',
	'template-without-opt' => 'Template %s does not provide array $opt[]. <a href="http://docs.pnp4nagios.org/faq/12">Read FAQ online</a>',
	'template-without-def' => 'Template %s does not provide array $def[]. <a href="http://docs.pnp4nagios.org/faq/13">Read FAQ online</a>',
	'no-data-for-page' => 'Sorry, but we can´t find any data using config file "%s", <a href="http://docs.pnp4nagios.org/faq/14">Read FAQ online</a>',
	'page-not-readable' => 'Config file "%s" is not readable or does not exist. <a href="http://docs.pnp4nagios.org/faq/15">Read FAQ online</a>',
	'auth-pages' => 'You are not authorized to view "pages" <a href="http://docs.pnp4nagios.org/faq/16">Read FAQ online</a>',
	'page-config-dir' => 'No page config file found in "%s" <a href="http://docs.pnp4nagios.org/faq/17">Read FAQ online</a>',
	'xport-host-service' => 'Xport controller needs "host" and "srv" URL parameters. <a href="http://docs.pnp4nagios.org/faq/18">Read FAQ online</a>',
	'mod-rewrite' => 'Apache Rewrite Module is not enabled. <a href="http://docs.pnp4nagios.org/faq/19">Read FAQ online</a>',
);
