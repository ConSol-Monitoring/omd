<!-- Logo Box Start -->
<div class="ui-widget">
<div class="logo ui-widget-content ui-corner-all" >
<a href="http://www.pnp4nagios.org"><img src="<?php echo url::base()?>media/images/pnp.png"></a>
<a href="http://www.rrdtool.org"><img src="<?php echo url::base()?>media/images/rrdtool.png"></a>
</div>
</div>
<!-- Logo Box End -->

