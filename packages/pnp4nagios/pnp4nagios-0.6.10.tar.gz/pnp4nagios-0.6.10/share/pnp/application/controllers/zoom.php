<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * Zoom controller.
 *
 * @package    PNP4Nagios
 * @author     Joerg Linge 
 * @license    GPL
 */
class Zoom_Controller extends System_Controller  {


    public function __construct()
    {
        parent::__construct();
        $this->template          = $this->add_view('zoom');
        $this->tpl               = $this->input->get('tpl');
        $this->graph_width       = $this->input->get('graph_width');
        $this->graph_height      = $this->input->get('graph_height');
    }

    public function index()
    {
        $this->source  = $this->input->get('source');
        $this->view    = "";

        if(isset($_GET['view']) && $_GET['view'] != "" ){
            $this->view = pnp::clean($_GET['view']);
        }else{
            $this->view = $this->config->conf['overview-range'];
        }

        $this->data->getTimeRange($this->start,$this->end,$this->view);

        if(isset($this->tpl) && $this->tpl != 'undefined' ){
            if($this->start && $this->end ){
                    $this->session->set("start", $this->start);
                    $this->session->set("end", $this->end);
            }
            $this->template->tpl     = $this->tpl;
            $this->template->view    = $this->view;
            $this->template->source  = $this->source;
            $this->template->end     = $this->end;
            $this->template->start   = $this->start;
            $this->template->graph_height = $this->graph_height;
            $this->template->graph_width  = $this->graph_width;
        }elseif(isset($this->host) && isset($this->service)){
            if($this->start && $this->end ){
                    $this->session->set("start", $this->start);
                    $this->session->set("end", $this->end);
            }
            $this->template->host    = $this->host;
            $this->template->srv     = $this->service;
            $this->template->view    = $this->view;
            $this->template->source  = $this->source;
            $this->template->end     = $this->end;
            $this->template->start   = $this->start;
            $this->template->graph_height = $this->graph_height;
            $this->template->graph_width  = $this->graph_width;
        }else{
            url::redirect("/graph");
        }
    }
}
