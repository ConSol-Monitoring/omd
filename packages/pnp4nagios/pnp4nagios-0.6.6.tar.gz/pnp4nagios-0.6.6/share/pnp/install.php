<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

<title>Installation</title>

<style type="text/css">
body { width: 42em; margin: 0 auto; font-family: sans-serif; font-size: 90%; }

#tests table { border-collapse: collapse; width: 100%; }
	#tests table th,
	#tests table td { padding: 0.2em 0.4em; text-align: left; vertical-align: top; }
	#tests table th { width: 12em; font-weight: normal; font-size: 1.2em; }
	#tests table tr:nth-child(odd) { background: #eee; }
	#tests table td.pass { color: #191; }
	#tests table td.fail { color: #911; }
	#tests table td.warn { background: #ff3; }
	#tests #results { color: #fff; }
	#tests #results p { padding: 0.8em 0.4em; }
	#tests #results p.pass { background: #191; }
	#tests #results p.fail { background: #911; }
	#tests #results p.warn { background: #ff3; }
</style>

</head>
<body>

<?php $failed = 0 ?>
<h1>PNP4Nagios Environment Tests</h1>

<p>The following options are determined by "configure". If any of the tests have failed, consult the <a href="http://docs.pnp4nagios.org/pnp-0.6/installer">documentation</a> for more information on how to correct the problem.</p>

<div id="tests">
<table cellspacing="0">
<tr>
<th>PNP4Nagios Version</th>
<td class="pass">pnp4nagios-0.6.5</td>
</tr>
<tr>
<th>Prefix</th>
<td class="pass">/omd/versions/0.42</td>
</tr>
<tr>
<th>RRD Storage</th>
<?php if (is_readable('/omd/versions/0.42/var/pnp4nagios/perfdata')): ?>
<td class="pass">/omd/versions/0.42/var/pnp4nagios/perfdata is readable.</td>
<?php else: $failed++ ?>
<td class="fail">/omd/versions/0.42/var/pnp4nagios/perfdata is not readable.</td>
<?php endif ?>
</tr>
<tr>
<th>RRDtool Binary</th>
<?php if (is_executable('/usr/bin/rrdtool') ): ?>
<td class="pass">/usr/bin/rrdtool is executable by PHP</td>
<?php else: $failed++ ?>
<td class="fail">/usr/bin/rrdtool is <a href="http://docs.pnp4nagios.org/faq/i8">not executable</a> by PHP</td>
<?php endif ?>
</tr>
<tr>
<th>PHP GD extension</th>
<?php if (function_exists('imagecreatefrompng')): ?>
<td class="pass">Pass</td>
<?php else: $failed++ ?>
<td class="fail">PHP GD extension not available</td>
<?php endif ?>
</tr>
<tr>
<th>PHP function proc_open()</th>
<?php if (function_exists('proc_open')): ?>
<td class="pass">Pass</td>
<?php else: $failed++ ?>
<td class="fail">PHP function <a href="http://docs.pnp4nagios.org/faq/i10">proc_open</a> not available/enabled</td>
<?php endif ?>
</tr>
<tr>
<th>PHP zlib extension</th>
<?php if (function_exists('gzfile')): ?>
<td class="pass">Pass</td>
<?php else: $failed++ ?>
<td class="fail">PHP zlib extension not available</td>
<?php endif ?>
</tr>
<tr>
<th>PHP session extension</th>
<?php if (function_exists('session_start')): ?>
<td class="pass">Pass</td>
<?php else: $failed++ ?>
<td class="fail">PHP session extension not available</td>
<?php endif ?>
</tr>
<tr>
<th>PHP JSON extension</th>
<?php if (function_exists('json_encode')): ?>
<td class="pass">Pass</td>
<?php else: $failed++ ?>
<td class="fail"><a href="http://docs.pnp4nagios.org/faq/i10">PHP JSON extension</a> not available</td>
<?php endif ?>
</tr>
<th>PHP magic_quotes_gpc</th>
<?php if (get_magic_quotes_gpc() == FALSE): ?>
<td class="pass">Off</td>
<?php else: $failed++ ?>
<td class="fail">PHP <a href="http://docs.pnp4nagios.org/faq/i7">magic_quotes_gpc</a> is deprecated</td>
<?php endif ?></tr>
<?php if(function_exists('apache_get_modules')) : ?>
<th>Apache Rewrite Module</th>
<?php if(in_array('mod_rewrite', apache_get_modules())) : ?>
<td class="pass">Pass</td>
<?php else: ?>
<td class="warn"><a href="http://docs.pnp4nagios.org/faq/i9">Apache mod_rewrite</a> is not enabled</td>
<?php endif ?></tr>
<?php else: ?>
<th>Apache Rewrite Module</th>
<td class="pass">Not running within Apache mod_php</td>
<?php endif ?></tr>
</table>
</div>

<h1>Kohana Environment Tests</h1>

<p>The following tests have been run to determine if Kohana will work in your environment. If any of the tests have failed, consult the <a href="http://docs.pnp4nagios.org/pnp-0.6/installer">documentation</a> for more information on how to correct the problem.</p>

<div id="tests">
<table cellspacing="0">
<tr>
<th>PHP Version</th>
<?php if (version_compare(PHP_VERSION, '5.2', '>=')): ?>
<td class="pass"><?php echo PHP_VERSION ?></td>
<?php else: $failed++ ?>
<td class="fail">Kohana requires PHP 5.2 or newer, this version is <?php echo PHP_VERSION ?>.</td>
<?php endif ?>
</tr>
<tr>
<th>System Directory</th>
<?php if (is_dir(SYSPATH) AND is_file(SYSPATH.'core/Bootstrap'.EXT)): ?>
<td class="pass"><?php echo SYSPATH ?></td>
<?php else: $failed++ ?>
<td class="fail">The configured <code>system</code> directory does not exist or does not contain required files.</td>
<?php endif ?>
</tr>
<tr>
<th>Application Directory</th>
<?php if (is_dir(APPPATH) AND is_file(APPPATH.'config/config'.EXT)): ?>
<td class="pass"><?php echo APPPATH ?></td>
<?php else: $failed++ ?>
<td class="fail">The configured <code>application</code> directory does not exist or does not contain required files.</td>
<?php endif ?>
</tr>
<tr>
<th>PCRE UTF-8</th>
<?php if ( ! @preg_match('/^.$/u', 'ñ')): $failed++ ?>
<td class="fail"><a href="http://docs.pnp4nagios.org/faq/i1">PCRE</a> has not been compiled with UTF-8 support.</td>
<?php elseif ( ! @preg_match('/^\pL$/u', 'ñ')): $failed++ ?>
<td class="fail"><a href="http://docs.pnp4nagios.org/faq/i2">PCRE</a> has not been compiled with Unicode property support.</td>
<?php else: ?>
<td class="pass">Pass</td>
<?php endif ?>
</tr>
<tr>
<th>Reflection Enabled</th>
<?php if (class_exists('ReflectionClass')): ?>
<td class="pass">Pass</td>
<?php else: $failed++ ?>
<td class="fail">PHP <a href="http://docs.pnp4nagios.org/faq/i3">reflection</a> is either not loaded or not compiled in.</td>
<?php endif ?>
</tr>
<tr>
<th>Filters Enabled</th>
<?php if (function_exists('filter_list')): ?>
<td class="pass">Pass</td>
<?php else: $failed++ ?>
<td class="fail">The <a href="http://docs.pnp4nagios.org/faq/i4">filter</a> extension is either not loaded or not compiled in.</td>
<?php endif ?>
</tr>
<tr>
<th>Iconv Extension Loaded</th>
<?php if (extension_loaded('iconv')): ?>
<td class="pass">Pass</td>
<?php else: $failed++ ?>
<td class="fail">The <a href="http://docs.pnp4nagios.org/faq/i5">iconv</a> extension is not loaded.</td>
<?php endif ?>
<tr>
<?php if (extension_loaded('mbstring')): ?>
<th>Mbstring Not Overloaded</th>
<?php if (ini_get('mbstring.func_overload') & MB_OVERLOAD_STRING): $failed++ ?>
<td class="fail">The <a href="http://docs.pnp4nagios.org/faq/i6">mbstring</a> extension is overloading PHP's native string functions.</td>
<?php else: ?>
<td class="pass">Pass</td>
<?php endif ?>
</tr>
<?php endif ?>
</tr>
<tr>
<th>URI Determination</th>
<?php if (isset($_SERVER['REQUEST_URI']) OR isset($_SERVER['PHP_SELF'])): ?>
<td class="pass">Pass</td>
<?php else: $failed++ ?>
<td class="fail">Neither <code>$_SERVER['REQUEST_URI']</code> or <code>$_SERVER['PHP_SELF']</code> is available.</td>
<?php endif ?>
</tr>
</table>

<div id="results">
<?php if ($failed > 0): ?>
<p class="fail">pnp4nagios may not work correctly with your environment. Remove or rename the <code>install<?php echo EXT ?></code> file on your own risk.</p>
<?php else: ?>
<p class="pass">Your environment passed all requirements. Remove or rename the <code>install<?php echo EXT ?></code> file now.</p>
<?php endif ?>
</div>

</div>

</body>
</html>
