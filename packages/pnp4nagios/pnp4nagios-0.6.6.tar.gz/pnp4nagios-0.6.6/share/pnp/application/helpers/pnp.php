<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
*
* 
*/
class pnp_Core {

    public static function clean($string = FALSE){
        if($string === FALSE){
            return;
        }
        $string = preg_replace('/[ :\/\\\]/', "_", $string);
        return $string;
    
    }
    public static function shorten($string = FALSE, $length = 25){
        if($string === FALSE){
            return;
        }
        if(strlen($string) > $length){
            $string = substr($string, 0, $length) . "...";
        }
        return $string;
    }
    /*
    *
    */
    public static function xml_version_check($string = FALSE){
        if($string === FALSE){
            return FALSE;
        }
        if( $string == XML_STRUCTURE_VERSION ){
            $string = "valid";
        }else{
            $string = Kohana::lang('error.xml-structure-mismatch', $string, XML_STRUCTURE_VERSION);
        }
        return $string;
    }
    /*
    *
    */
    public static function zoom_icon($host,$service,$start,$end,$source,$view){
        print "<a href=\"javascript:Gzoom('".url::base(TRUE)."zoom?host=$host&srv=$service&view=$view&source=$source&end=$end&start=$start');\" title=\"Zoom into the Graph\"><img src=\"".url::base()."media/images/zoom.png\"></a>\n";
    }

    /*
    *
    */
    public static function zoom_icon_special($tpl,$start,$end,$source,$view){
        print "<a href=\"javascript:Gzoom('".url::base(TRUE)."zoom?tpl=$tpl&view=$view&source=$source&end=$end&start=$start');\" title=\"Zoom into the Graph\"><img src=\"".url::base()."media/images/zoom.png\"></a>\n";
    }

    /*
    *
    */
    public static function add_to_basket_icon($host,$service){
        print "<span id=\"basket_action_add\"><a title=\"Add This Item\" id=\"".$host."::".$service."\"><img width=16px height=16px src=\"".url::base()."media/images/add.png\"></a></span><br>\n";
}

    /*
    *
    */
    public static function multisite_link($base_url=FALSE,$site=FALSE,$host=FALSE,$service=FALSE){
        if($host && $service){
            $link = sprintf("'%s/view.py?view_name=service&site=%s&host=%s&service=%s'", $base_url,$site,urlencode($host),urlencode($service));
            return $link;
        }
        if($host){
            $link = sprintf("'%s/view.py?view_name=host&site=%s&host=%s'", $base_url,$site,urlencode($host));
            return $link;
        }
    }

    public static function addToUri($fields,$base = True){
        if(!is_array($fields)){
            return false;
        }
        $get = $_GET;
        if($base === True){
            $uri  = url::base(TRUE);
            $uri .= Router::$current_uri;
        }else{
            $uri  = "";
        }
        $uri .= '?';
        foreach($fields as $key=>$value){
            $get[$key] = $value;
        }
        foreach($get as $key=>$value){
            $uri .= $key."=".urlencode($value)."&";
        }
        return rtrim($uri,"&");
    }

} 
