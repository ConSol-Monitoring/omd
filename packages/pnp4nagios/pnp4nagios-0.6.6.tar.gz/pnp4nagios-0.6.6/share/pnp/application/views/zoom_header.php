		<script type="text/javascript">
		function Gzoom (url) {
		  GzoomWindow = window.open(url, "PNP", "width=600,height=300,resizable=yes,scrollbars=yes");
		  GzoomWindow.focus();
		}
		</script>
