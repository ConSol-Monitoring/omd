<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['query_methods_not_allowed'] = 'Die Query-Methoden können nicht über ORM benutzt werden.';