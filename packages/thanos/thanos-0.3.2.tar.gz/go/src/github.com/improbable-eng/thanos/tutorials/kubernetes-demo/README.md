# Thanos - Transforming Prometheus to a Global Scale in a Seven Simple Steps

TODO: Describe full demo.
