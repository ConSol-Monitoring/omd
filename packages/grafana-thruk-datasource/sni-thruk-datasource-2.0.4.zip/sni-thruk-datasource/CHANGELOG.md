### Changelog

2.0.4  2023-12-04
    - remove time filter restriction
    - update grafana toolkit to 10.1.5

2.0.3  2023-07-14
    - make drag/drop more obvious
    - set correct field type for numeric columns
    - fix removing * from column list

2.0.2  2023-05-30
    - fix using variables in path/from field

2.0.1  2022-12-02
    - fix syntax error in variables query

2.0.0  2022-10-28
    - rebuild with react for grafana 9
    - add support for logs explorer
    - query editor:
        - support sorting columns

1.0.7  2022-02-11
    - rebuild for grafana 8
    - update dependencies

1.0.6  2021-01-04
    - sign plugin
    - switch package builds to yarn

1.0.5  2020-09-11
    - improve packaging

1.0.4  2020-06-29
    - fix export with "Export for sharing externally" enabled

1.0.3  2019-02-15
    - support aggregation functions
    - convert hash responses into tables
    - support timeseries based panels

1.0.2  2019-01-04
    - add more time styles

1.0.1  2018-09-30
    - fix annotation query parser

1.0.0  2018-09-14
    - inital release
