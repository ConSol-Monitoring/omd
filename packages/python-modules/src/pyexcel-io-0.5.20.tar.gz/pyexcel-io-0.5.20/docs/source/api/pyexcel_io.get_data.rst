pyexcel_io.get_data
===================

.. currentmodule:: pyexcel_io

.. autofunction:: get_data