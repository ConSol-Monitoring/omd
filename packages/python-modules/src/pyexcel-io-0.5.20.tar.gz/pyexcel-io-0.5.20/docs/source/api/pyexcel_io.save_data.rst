pyexcel_io.save_data
====================

.. currentmodule:: pyexcel_io

.. autofunction:: save_data