from __future__ import annotations

from setuptools import setup

setup(
    name="unicode.dist",
    version="0.1",
    description="A testing distribution \N{SNOWMAN}",
    packages=["unicodedist"],
    zip_safe=True,
)
