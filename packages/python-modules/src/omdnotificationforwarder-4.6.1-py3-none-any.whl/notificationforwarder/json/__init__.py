# JSON logger module
