.. toctree::
   :maxdepth: 2

Advanced topic
--------------

.. include:: /../../examples/v3arch/asyncore/agent/ntforg/send-custom-pdu.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/v3arch/asyncore/agent/ntforg/send-custom-pdu.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/v3arch/asyncore/agent/ntforg/send-custom-pdu.py>` script.


See also: :doc:`library reference </docs/api-reference>`.
