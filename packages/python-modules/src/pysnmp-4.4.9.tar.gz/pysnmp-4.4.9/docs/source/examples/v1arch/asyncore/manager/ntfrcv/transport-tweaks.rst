.. toctree::
   :maxdepth: 2

Transport tweaks
----------------

.. include:: /../../examples/v1arch/asyncore/manager/ntfrcv/listen-on-ipv4-and-ipv6-interfaces.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/v1arch/asyncore/manager/ntfrcv/listen-on-ipv4-and-ipv6-interfaces.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/v1arch/asyncore/manager/ntfrcv/listen-on-ipv4-and-ipv6-interfaces.py>` script.


See also: :doc:`library reference </docs/api-reference>`.
