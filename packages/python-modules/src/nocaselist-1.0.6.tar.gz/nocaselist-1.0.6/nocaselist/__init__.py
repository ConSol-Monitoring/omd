"""
nocaselist - A case-insensitive list for Python
"""

from __future__ import absolute_import

from ._version import __version__  # noqa: F401
from ._nocaselist import *  # noqa: F403,F401
