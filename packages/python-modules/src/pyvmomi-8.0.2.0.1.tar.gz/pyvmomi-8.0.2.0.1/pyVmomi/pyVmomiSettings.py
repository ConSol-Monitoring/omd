# **********************************************************
# Copyright (c) 2008-2022 VMware, Inc.
# **********************************************************

allowGetSet = False
allowCapitalizedNames = False
binaryIsBytearray = True
