from pysnmp.proto.secmod.rfc3414 import service

SnmpUSMSecurityModel = service.SnmpUSMSecurityModel
