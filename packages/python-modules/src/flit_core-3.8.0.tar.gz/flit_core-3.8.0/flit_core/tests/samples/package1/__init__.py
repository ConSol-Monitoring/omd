"""A sample package"""

__version__ = '0.1'

def main():
    print("package1 main")
