

18 contributors
================================================================================

In alphabetical order:

* `Akshaya Kumar Sharma <https://github.com/akshayakrsh>`_
* `Andre Almar <https://github.com/andrealmar>`_
* `Arunkumar Rajendran <https://github.com/arunkumar-ra>`_
* `Ayan Banerjee <https://github.com/ayan-b>`_
* `Chris Hill-Scott <https://github.com/quis>`_
* `Craig Anderson <https://github.com/craiga>`_
* `Daryl Yu <https://github.com/darylyu>`_
* `J Harley <https://github.com/julzhk>`_
* `Joel Nothman <https://github.com/jnothman>`_
* `John Vandenberg <https://github.com/jayvdb>`_
* `Linghui Zeng <https://github.com/mathsyouth>`_
* `nikolas <https://github.com/nikolas>`_
* `Rintze M. Zelle <https://github.com/rmzelle>`_
* `Simeon Visser <https://github.com/svisser>`_
* `Simon Allen <https://github.com/garfunkel>`_
* `simon klemenc <https://github.com/hiaselhans>`_
* `Tim Gates <https://github.com/timgates42>`_
* `William Jamir Silva <https://github.com/williamjamir>`_
