pyexcel.internal.sheets.Column
==============================

.. currentmodule:: pyexcel.internal.sheets

.. autoclass:: Column

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Column.__init__
      ~Column.format
      ~Column.get_converter
      ~Column.select
   
   

   
   
   