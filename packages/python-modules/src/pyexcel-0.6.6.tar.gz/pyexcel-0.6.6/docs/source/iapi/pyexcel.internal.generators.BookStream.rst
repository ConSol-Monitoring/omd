pyexcel.internal.generators.BookStream
======================================

.. currentmodule:: pyexcel.internal.generators

.. autoclass:: BookStream

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BookStream.__init__
      ~BookStream.load_from_sheets
      ~BookStream.number_of_sheets
      ~BookStream.sheet_names
      ~BookStream.to_dict
   
   

   
   
   