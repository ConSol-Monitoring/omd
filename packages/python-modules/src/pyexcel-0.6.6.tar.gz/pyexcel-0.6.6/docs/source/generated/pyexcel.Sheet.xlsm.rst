pyexcel.Sheet.xlsm
==================

.. currentmodule:: pyexcel

.. autoattribute:: Sheet.xlsm