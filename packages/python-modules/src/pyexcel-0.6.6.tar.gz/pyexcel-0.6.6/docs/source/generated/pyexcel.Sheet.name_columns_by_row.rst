pyexcel.Sheet.name\_columns\_by\_row
====================================

.. currentmodule:: pyexcel

.. automethod:: Sheet.name_columns_by_row