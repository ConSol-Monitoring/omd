pyexcel.merge\_all\_to\_a\_book
===============================

.. currentmodule:: pyexcel

.. autofunction:: merge_all_to_a_book