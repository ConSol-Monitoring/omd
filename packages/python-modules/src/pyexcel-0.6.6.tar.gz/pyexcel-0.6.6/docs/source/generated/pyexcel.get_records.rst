pyexcel.get\_records
====================

.. currentmodule:: pyexcel

.. autofunction:: get_records