pyexcel.Sheet.records
=====================

.. currentmodule:: pyexcel

.. autoattribute:: Sheet.records