pyexcel.Sheet.number\_of\_rows
==============================

.. currentmodule:: pyexcel

.. automethod:: Sheet.number_of_rows