pyexcel.Book.save\_to\_memory
=============================

.. currentmodule:: pyexcel

.. automethod:: Book.save_to_memory