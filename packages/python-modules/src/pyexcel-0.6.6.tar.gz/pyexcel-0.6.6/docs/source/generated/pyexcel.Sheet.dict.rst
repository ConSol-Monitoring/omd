pyexcel.Sheet.dict
==================

.. currentmodule:: pyexcel

.. autoattribute:: Sheet.dict