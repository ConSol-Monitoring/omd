pyexcel.Sheet.project
=====================

.. currentmodule:: pyexcel

.. automethod:: Sheet.project