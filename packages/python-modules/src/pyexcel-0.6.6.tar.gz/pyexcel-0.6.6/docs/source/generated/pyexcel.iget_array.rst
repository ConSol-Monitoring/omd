pyexcel.iget\_array
===================

.. currentmodule:: pyexcel

.. autofunction:: iget_array