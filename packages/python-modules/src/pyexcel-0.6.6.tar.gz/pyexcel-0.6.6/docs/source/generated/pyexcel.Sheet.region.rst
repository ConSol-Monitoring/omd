pyexcel.Sheet.region
====================

.. currentmodule:: pyexcel

.. automethod:: Sheet.region