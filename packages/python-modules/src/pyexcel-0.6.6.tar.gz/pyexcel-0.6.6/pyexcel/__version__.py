__version__ = '0.6.6'
__author__ = 'chfw'
