READ ME
=========

A robot chef was created to master the cuisines around the world. It learns faster
than a human because it just needs a plugin to be installed. It consumes less
memory as it load the cuisine knowlege on demand.

Please note that there are two implementations of the robot chef. One is pure
command line interface(CLI) using lml directly; the other one is CLI using
robotchef_api package which uses lml. The former demonstrates how lml could
be used in a CLI package. The latter illustrates how to construct a pure
python library using lml.
