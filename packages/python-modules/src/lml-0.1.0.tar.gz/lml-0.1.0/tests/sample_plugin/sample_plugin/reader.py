from lml.plugin import Plugin


class TestPlugin(Plugin):
    def do_something(self):
        print("hello world")
