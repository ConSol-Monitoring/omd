Appendix
===============

.. _rb-plugin:

Robot Chef plugin.py
----------------

.. literalinclude:: ../../examples/robotchef/robotchef/plugin.py
  :language: python


Robot Chef Version 3
------------------------

.. _rb3-diff-rb0-plugin:

code difference with Robot Chef All In One solution: plugin.py
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

.. literalinclude:: ../../examples/robotchef_allinone_lml/robotchef_allinone_lml/plugin.py
   :diff: ../../examples/robotchef_allinone/robotchef_allinone/plugin.py

