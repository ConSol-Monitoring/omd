API documentation
====================

.. automodule:: lml.loader

.. autofunction:: scan_plugins_regex

.. automodule:: lml.plugin

.. autoclass:: PluginInfo

.. autoclass:: PluginInfoChain

.. autoclass:: PluginManager
   :members:
