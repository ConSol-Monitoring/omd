[Documentation](https://consol-monitoring.github.io/check_vsphere/#/)

# Installation

```
pip install checkvsphere
```

# LICENSE

If not stated otherwise in a source file everything is licensed under
GNU AFFERO GENERAL PUBLIC LICENSE Version 3.

See also the LICENSE file.
