.. pyexcel-xls documentation master file, created by
   sphinx-quickstart on Sun Nov  1 18:41:01 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../../README.rst

