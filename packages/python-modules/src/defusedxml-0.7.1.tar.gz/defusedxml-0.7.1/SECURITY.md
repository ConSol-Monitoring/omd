# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.7.0   | :white_check_mark: |
| 0.6.0   | :white_check_mark: |
| < 0.6   | :x:                |

## Reporting a Vulnerability

Please report security issues to christian@python.org
