from smbc import xattr
from _smbc import *

