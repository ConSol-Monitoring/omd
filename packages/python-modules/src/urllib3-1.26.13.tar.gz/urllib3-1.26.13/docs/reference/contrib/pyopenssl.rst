PyOpenSSL
=========
.. warning::
    DEPRECATED: This module is deprecated and will be removed in a future 2.x release.
    Read more in this `issue <https://github.com/urllib3/urllib3/issues/2680>`_.

.. automodule:: urllib3.contrib.pyopenssl
    :members:
    :undoc-members:
    :show-inheritance:
