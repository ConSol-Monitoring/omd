Installation of nocasedict project
=======================================================

To install the latest released version of the
nocasedict project into your active Python environment:

      $ pip install nocasedict

This will also install any prerequisite Python packages.

For more details and alternative ways to install, see
[Installation](https://nocasedict.readthedocs.io/en/stable/intro.html#installation).
