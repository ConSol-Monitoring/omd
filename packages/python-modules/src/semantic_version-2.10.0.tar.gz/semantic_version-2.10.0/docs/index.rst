======================
python-semanticversion
======================

.. include:: introduction.rst


Contents
========

.. toctree::
   :maxdepth: 2

   introduction
   guide
   reference
   django
   changelog
   credits




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

