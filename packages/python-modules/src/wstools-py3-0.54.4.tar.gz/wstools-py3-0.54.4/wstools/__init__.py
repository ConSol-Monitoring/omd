#! /usr/bin/env python
"""WSDL parsing services package for Web Services for Python."""

ident = "$Id$"

from . import WSDLTools  # noqa
from . import XMLname   # noqa
