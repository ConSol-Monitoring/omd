=========================================================
WSDL parsing services package for Web Services for Python
=========================================================

.. image:: https://img.shields.io/pypi/pyversions/wstools-py3.svg
        :target: https://pypi.python.org/pypi/wstools-py3/

.. image:: https://img.shields.io/github/license/Synerty/wstools-py3.svg
        :target: https://pypi.python.org/pypi/wstools-py3/

		
------------

.. image:: https://img.shields.io/pypi/status/wstools-py3.svg
        :target: https://pypi.python.org/pypi/wstools-py3/


General
=======

-  Homepage: https://github.com/Synerty/wstools-py3
-  Package: http://pypi.python.org/pypi/wstools-py3/

Credits
=======

Companies
---------

\|makinacom\|\_

-  ``Planet Makina Corpus <http://www.makina-corpus.org>``\ \_
-  ``Contact us <mailto:python@makina-corpus.org>``\ \_

.. \|makinacom\| image:: http://depot.makina-corpus.org/public/logo.gif
.. \_makinacom: http://www.makina-corpus.com

Authors
-------

-  Makina Corpus python@makina-corpus.com

Contributors
------------

-  Sorin Sbarnea sorin.sbarnea@gmail.com
