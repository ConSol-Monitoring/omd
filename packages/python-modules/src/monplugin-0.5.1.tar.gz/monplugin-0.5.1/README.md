partial port of perls Monitoring::Plugins

At least the stuff I needed so far

    pip install monplugin

## Why?

Because everything else I found was more like a framework than a library.