# This is setting template.
# You must change these parameter if you perform test.
# The following configration will create \\server\share\testdir
# directory, so user should have write permission.

WORKGROUP = "WORKGROUP"
SERVER = "server"
SHARE = "share"
USERNAME = "username"
PASSWORD = "password"
TESTDIR = "testdir"


