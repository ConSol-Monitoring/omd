pyexcel\_io.save\_data
======================

.. currentmodule:: pyexcel_io

.. autofunction:: save_data