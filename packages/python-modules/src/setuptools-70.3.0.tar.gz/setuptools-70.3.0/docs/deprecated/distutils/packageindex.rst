:orphan:

.. _package-index:

*******************************
The Python Package Index (PyPI)
*******************************

The `Python Package Index (PyPI) <https://pypi.org>`_ stores
metadata describing distributions packaged with distutils and
other publishing tools, as well the distribution archives
themselves.

The best resource for working with PyPI is the
`Python Packaging User Guide <https://packaging.python.org>`_.
