:orphan:

***************************************
Uploading Packages to the Package Index
***************************************

See the
`Python Packaging User Guide <https://packaging.python.org>`_
for the best guidance on uploading packages.
