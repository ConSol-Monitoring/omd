==========
Change log
==========

.. include:: ../ChangeLog.rst

.. Please see the `ChangeLog.rst` file located in the root of the pymssql source
   code tree.
