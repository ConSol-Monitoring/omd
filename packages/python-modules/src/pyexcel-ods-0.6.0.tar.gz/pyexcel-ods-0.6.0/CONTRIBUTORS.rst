

3 contributors
================================================================================

In alphabetical order:

* `Azamat H. Hackimov <https://github.com/winterheart>`_
* `John Vandenberg <https://github.com/jayvdb>`_
* `Mateusz Konieczny <https://github.com/matkoniecz>`_
