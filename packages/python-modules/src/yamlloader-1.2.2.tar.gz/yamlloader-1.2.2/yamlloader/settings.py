"""Global settings for the behavior of the module."""

ALLOW_NON_C_FALLBACK = True
