pyexcel\_io.get\_data
=====================

.. currentmodule:: pyexcel_io

.. autofunction:: get_data