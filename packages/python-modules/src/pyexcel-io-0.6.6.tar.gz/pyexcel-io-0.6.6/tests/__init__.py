# needed for Python 2.7, python setup.py test to discover tests directory
