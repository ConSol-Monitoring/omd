char tav = 'b';
char* moral = "ain't I \\\"\\\t\" a nice string?\"\"";
char* comment_inside = "but you will /* see it */!!!!";
char* i_have_newlines = "line one\nline two\nline three";

int main()
{
    auto char* multi = "a multi";
}



