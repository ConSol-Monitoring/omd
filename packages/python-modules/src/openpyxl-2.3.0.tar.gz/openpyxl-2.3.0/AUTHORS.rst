This project was started by Eric Gazoni. In 2013 Charlie Clark became
co-maintainer of the project.

It was initiallay *heavily* inspired by the PHPExcel library:
http://www.phpexcel.net/

Thanks to all those who participate in the project (in alphabetical order):

* Stephane Bard
* Day Barr
* Stefan Behnel
* Bernt R. Brenna
* Sven Burk
* Anders Chrigstrom
* ccoacley
* Maarten De Paepe
* Etienne Desautels
* Eric Chlebek
* Alexandre Fayolle
* Eric Gazoni
* Brice Gelineau
* Alex Gronholm
* Yaroslav Halchenko
* Khchine Hamza
* Josh Haywood
* Jeff Holman
* Brent Hoover
* Eric Hurkman
* Jean Pierre Huart
* JarekPS
* Heikki Junes
* Chi Ho Kwok
* Yingjie Lan
* Detlef Lannert
* Nicholas Laver
* Greg Lehmann
* Adam Lofts
* Marko Loparic
* Samuel Loretan
* Amin Mirzaee
* Adam Morris
* aceMueller
* Gabi Nagy
* Thomas Nygards
* Felipe Ochoa
* Jun Omae
* Waldemar Osuch
* Jonathan Peirce
* Sergey Pikhovkin
* Ted Pollari
* Elias Rabel
* Rick Rankin
* ramn_se
* Philip Roche
* James Smagala
* Wolfgane Scherer
* Joseph Tate
* Dieter Vandenbussche
* Paul Van Der Linden
* Gerald Van Huffelen
* Laurent Vasseur
* Kay Webber
* Shibukawa Yoshiki

Project logo designed by Eric Gazoni, font by claudeserieux
(http://www.dafont.com/profile.php?user=337503)
