##########################
nagiosplugin Documentation
##########################

This documentation covers nagiosplugin |version|.

Contents
========

.. toctree::
   :maxdepth: 2

   readme
   tutorial/index
   topic/index
   api/index
   glossary
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

To download the package, see the `PyPI page`_.

.. _PyPI page: https://pypi.python.org/pypi/nagiosplugin

.. general:
   http://www.packtpub.com/article/documenting-your-python-project-1
   http://lusislog.blogspot.de/2011/07/monitoring-sucks-watch-your-language.html
