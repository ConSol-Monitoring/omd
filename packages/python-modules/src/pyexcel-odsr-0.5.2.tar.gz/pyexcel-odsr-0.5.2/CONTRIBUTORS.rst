Contributors
================

Author is in setup.py file and module __author__. Hence please find the
contributors here.

In alphabetic order:

*. `Jona <https://github.com/jonadem>`_


