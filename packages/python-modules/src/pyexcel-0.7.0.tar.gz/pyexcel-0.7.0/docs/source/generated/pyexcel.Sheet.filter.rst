pyexcel.Sheet.filter
====================

.. currentmodule:: pyexcel

.. automethod:: Sheet.filter