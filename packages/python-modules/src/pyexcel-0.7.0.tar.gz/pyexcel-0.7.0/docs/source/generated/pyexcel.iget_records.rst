pyexcel.iget\_records
=====================

.. currentmodule:: pyexcel

.. autofunction:: iget_records