pyexcel.Book.save\_to\_django\_models
=====================================

.. currentmodule:: pyexcel

.. automethod:: Book.save_to_django_models