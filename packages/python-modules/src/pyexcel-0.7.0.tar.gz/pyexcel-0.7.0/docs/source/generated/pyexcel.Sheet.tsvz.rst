pyexcel.Sheet.tsvz
==================

.. currentmodule:: pyexcel

.. autoattribute:: Sheet.tsvz