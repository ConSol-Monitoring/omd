pyexcel.Sheet.name\_rows\_by\_column
====================================

.. currentmodule:: pyexcel

.. automethod:: Sheet.name_rows_by_column