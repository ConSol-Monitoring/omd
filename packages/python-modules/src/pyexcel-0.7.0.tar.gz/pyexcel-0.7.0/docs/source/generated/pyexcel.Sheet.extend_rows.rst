pyexcel.Sheet.extend\_rows
==========================

.. currentmodule:: pyexcel

.. automethod:: Sheet.extend_rows