pyexcel.Book.xlsm
=================

.. currentmodule:: pyexcel

.. autoattribute:: Book.xlsm