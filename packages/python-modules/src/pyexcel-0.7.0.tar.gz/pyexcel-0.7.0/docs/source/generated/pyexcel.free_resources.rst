pyexcel.free\_resources
=======================

.. currentmodule:: pyexcel

.. autofunction:: free_resources