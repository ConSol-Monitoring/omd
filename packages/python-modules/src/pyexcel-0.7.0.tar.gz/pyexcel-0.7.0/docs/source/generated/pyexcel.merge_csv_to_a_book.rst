pyexcel.merge\_csv\_to\_a\_book
===============================

.. currentmodule:: pyexcel

.. autofunction:: merge_csv_to_a_book