pyexcel.Sheet.rows
==================

.. currentmodule:: pyexcel

.. automethod:: Sheet.rows