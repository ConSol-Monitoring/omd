pyexcel.Book.url
================

.. currentmodule:: pyexcel

.. autoattribute:: Book.url