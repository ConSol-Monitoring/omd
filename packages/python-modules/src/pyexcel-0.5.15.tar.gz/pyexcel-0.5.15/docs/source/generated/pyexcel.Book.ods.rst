pyexcel.Book.ods
================

.. currentmodule:: pyexcel

.. autoattribute:: Book.ods