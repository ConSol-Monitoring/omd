pyexcel.Sheet.columns
=====================

.. currentmodule:: pyexcel

.. automethod:: Sheet.columns