pyexcel.Sheet.save\_to\_database
================================

.. currentmodule:: pyexcel

.. automethod:: Sheet.save_to_database