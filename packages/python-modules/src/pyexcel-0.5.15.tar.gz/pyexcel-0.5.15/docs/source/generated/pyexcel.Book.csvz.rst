pyexcel.Book.csvz
=================

.. currentmodule:: pyexcel

.. autoattribute:: Book.csvz