pyexcel.Sheet.vertical
======================

.. currentmodule:: pyexcel

.. automethod:: Sheet.vertical