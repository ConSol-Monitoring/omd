pyexcel.Sheet.rcolumns
======================

.. currentmodule:: pyexcel

.. automethod:: Sheet.rcolumns