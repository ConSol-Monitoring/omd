pyexcel.isave\_book\_as
=======================

.. currentmodule:: pyexcel

.. autofunction:: isave_book_as