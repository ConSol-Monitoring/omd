pyexcel.save\_as
================

.. currentmodule:: pyexcel

.. autofunction:: save_as