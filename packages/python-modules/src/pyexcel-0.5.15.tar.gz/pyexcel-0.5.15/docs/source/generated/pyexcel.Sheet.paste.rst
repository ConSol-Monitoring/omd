pyexcel.Sheet.paste
===================

.. currentmodule:: pyexcel

.. automethod:: Sheet.paste