pyexcel.get\_sheet
==================

.. currentmodule:: pyexcel

.. autofunction:: get_sheet