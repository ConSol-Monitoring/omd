pyexcel.Book.stream
===================

.. currentmodule:: pyexcel

.. autoattribute:: Book.stream