pyexcel.Sheet.rvertical
=======================

.. currentmodule:: pyexcel

.. automethod:: Sheet.rvertical