pyexcel.Sheet.reverse
=====================

.. currentmodule:: pyexcel

.. automethod:: Sheet.reverse