pyexcel.Sheet.rrows
===================

.. currentmodule:: pyexcel

.. automethod:: Sheet.rrows