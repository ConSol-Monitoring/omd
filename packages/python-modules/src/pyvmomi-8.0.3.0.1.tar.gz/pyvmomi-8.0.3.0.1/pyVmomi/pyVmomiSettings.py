# Copyright (c) 2008-2024 Broadcom. All Rights Reserved.
# The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.

allowGetSet = False
allowCapitalizedNames = False
binaryIsBytearray = True
