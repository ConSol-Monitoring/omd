<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">

<html>
<head>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW">
<title>Nagios</title>
<link rel="shortcut icon" href="images/favicon.ico" type="image/ico">
</head>

<frameset cols="180,*">
<frame src="side.php" name="side" frameborder="0">
<frame src="main.php" name="main" frameborder="0">

<noframes>
<!-- This page requires a web browser which supports frames. --> 
<h2>Nagios</h2>
<p align="center">
<a href="http://www.nagios.org/">www.nagios.org</a><br>
Copyright (c) 1999-2009 Ethan Galstad<br>
</p>
<p>
<i>Note: These pages require a browser which supports frames</i>
</p>
</noframes>

</frameset>

</html>

