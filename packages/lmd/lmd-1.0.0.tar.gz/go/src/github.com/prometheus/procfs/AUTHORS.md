The Prometheus project was started by Matt T. Proud (emeritus) and
Julius Volz in 2012.

Maintainers of this repository:

* Tobias Schmidt <ts@soundcloud.com>

The following individuals have contributed code to this repository
(listed in alphabetical order):

* Armen Baghumian <abaghumian@noggin.com.au>
* Bjoern Rabenstein <beorn@soundcloud.com>
* David Cournapeau <cournape@gmail.com>
* Ji-Hoon, Seol <jihoon.seol@gmail.com>
* Jonas Große Sundrup <cherti@letopolis.de>
* Julius Volz <julius.volz@gmail.com>
* Matthias Rampke <mr@soundcloud.com>
* Nicky Gerritsen <nicky@streamone.nl>
* Rémi Audebert <contact@halfr.net>
* Tobias Schmidt <tobidt@gmail.com>
