# goid [![Build Status](https://travis-ci.org/petermattis/goid.svg?branch=master)](https://travis-ci.org/petermattis/goid)

Programatically retrieve the current goroutine's ID. See [the CI
configuration](.travis.yml) for supported Go versions. In addition,
gccgo 7.2.1 (Go 1.8.3) is supported.
