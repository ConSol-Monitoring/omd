package main

import (
	log "github.com/kdar/factorlog"
)

func main() {
	log.Println("Basic")
}
