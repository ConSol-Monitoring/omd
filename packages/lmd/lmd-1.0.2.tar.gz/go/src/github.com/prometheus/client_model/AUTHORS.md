The Prometheus project was started by Matt T. Proud (emeritus) and
Julius Volz in 2012.

Maintainers of this repository:

* Björn Rabenstein <beorn@soundcloud.com>

The following individuals have contributed code to this repository
(listed in alphabetical order):

* Björn Rabenstein <beorn@soundcloud.com>
* Matt T. Proud <matt.proud@gmail.com>
* Tobias Schmidt <ts@soundcloud.com>
