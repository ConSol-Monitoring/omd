The Prometheus project was started by Matt T. Proud (emeritus) and
Julius Volz in 2012.

Maintainers of this repository:

* Björn Rabenstein <beorn@soundcloud.com>

More than [30 individuals][1] have contributed to this repository. Please refer
to the Git commit log for a complete list.

[1]: https://github.com/prometheus/client_golang/graphs/contributors
