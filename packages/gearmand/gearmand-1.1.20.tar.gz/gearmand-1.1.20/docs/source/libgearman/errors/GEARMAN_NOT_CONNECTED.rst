=====================
GEARMAN_NOT_CONNECTED
=====================

Please see :c:type:`GEARMAN_NOT_CONNECTED`
