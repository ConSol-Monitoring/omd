=====================
GEARMAN_IGNORE_PACKET
=====================

Please see :c:type:`GEARMAN_IGNORE_PACKET`
