=========================
GEARMAN_COULD_NOT_CONNECT
=========================

Please see :c:type:`GEARMAN_COULD_NOT_CONNECT`
