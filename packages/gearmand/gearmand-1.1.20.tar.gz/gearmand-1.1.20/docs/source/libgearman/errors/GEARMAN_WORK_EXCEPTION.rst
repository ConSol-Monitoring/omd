======================
GEARMAN_WORK_EXCEPTION
======================

Please see :c:type:`GEARMAN_WORK_EXCEPTION`
