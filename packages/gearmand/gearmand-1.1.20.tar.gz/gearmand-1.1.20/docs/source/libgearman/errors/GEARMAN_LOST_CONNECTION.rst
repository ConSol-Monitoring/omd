=======================
GEARMAN_LOST_CONNECTION
=======================

Please see :c:type:`GEARMAN_LOST_CONNECTION`
