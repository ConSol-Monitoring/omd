=============================
GEARMAN_INVALID_FUNCTION_NAME
=============================

Please see :c:type:`GEARMAN_INVALID_FUNCTION_NAME`
