==============================
GEARMAN_NO_REGISTERED_FUNCTION
==============================

Please see :c:type:`GEARMAN_NO_REGISTERED_FUNCTION`
