===============
GEARMAN_SUCCESS
===============

Please see :c:type:`GEARMAN_SUCCESS`
