=============
GEARMAN_ERRNO
=============

Please see :c:type:`GEARMAN_ERRNO`
