======================
GEARMAN_UNKNOWN_OPTION
======================

Please see :c:type:`GEARMAN_UNKNOWN_OPTION`
