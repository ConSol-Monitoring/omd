=============
GEARMAN_ERROR
=============

Please see :c:type:`GEARMAN_ERROR`


