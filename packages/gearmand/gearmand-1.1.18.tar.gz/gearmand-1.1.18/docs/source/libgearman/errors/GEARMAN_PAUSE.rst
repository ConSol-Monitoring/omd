=============
GEARMAN_PAUSE
=============

Used only in custom application for client return based on GEARMAN_WORK_DATA, GEARMAN_WORK_WARNING, GEARMAN_TASK_STATE_EXCEPTION, or GEARMAN_WORK_STATUS.

Please see :c:type:`GEARMAN_PAUSE` for additional information.
