==================
GEARMAN_WORK_ERROR
==================

Please see :c:type:`GEARMAN_WORK_ERROR`
