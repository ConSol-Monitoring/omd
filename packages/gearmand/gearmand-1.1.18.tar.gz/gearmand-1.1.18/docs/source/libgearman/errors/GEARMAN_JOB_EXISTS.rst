==================
GEARMAN_JOB_EXISTS
==================

Please see :c:type:`GEARMAN_JOB_EXISTS`
