=========================
GEARMAN_UNEXPECTED_PACKET
=========================

Please see :c:type:`GEARMAN_UNEXPECTED_PACKET`
