===============
GEARMAN_IO_WAIT
===============

Blocking IO was found. gearman_continue() can be used for testing this.

Please see :c:type:`GEARMAN_IO_WAIT` for additional information.

