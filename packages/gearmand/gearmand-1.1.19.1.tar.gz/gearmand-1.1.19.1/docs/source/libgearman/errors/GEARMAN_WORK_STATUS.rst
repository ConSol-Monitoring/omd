===================
GEARMAN_WORK_STATUS
===================

Please see :c:type:`GEARMAN_WORK_STATUS`
