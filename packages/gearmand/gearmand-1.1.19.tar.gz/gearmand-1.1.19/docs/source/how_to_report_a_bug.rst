===================
How to report a bug
===================

Bugs for Gearmand can be reported at https://github.com/gearman/gearmand/issues/. On the right side of the page you will see the link to "Report a bug", alongside links to ask questions, submit code, etc. 
