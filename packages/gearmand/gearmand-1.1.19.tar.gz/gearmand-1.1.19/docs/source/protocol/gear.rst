=================================
GEAR, The Gearman Binary Protocol
=================================

See libgearman-1.0/protocol.h for specifics, or look on http://gearman.org/
