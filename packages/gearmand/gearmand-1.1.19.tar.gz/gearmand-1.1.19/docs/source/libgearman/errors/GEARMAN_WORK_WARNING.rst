====================
GEARMAN_WORK_WARNING
====================

Please see :c:type:`GEARMAN_WORK_WARNING`
