===================
GEARMAN_QUEUE_ERROR
===================

This is a server only related error, and will not be found in any client or
worker return.
