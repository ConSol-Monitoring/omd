=====================
GEARMAN_NO_ACTIVE_FDS
=====================

Please see :c:type:`GEARMAN_NO_ACTIVE_FDS`
