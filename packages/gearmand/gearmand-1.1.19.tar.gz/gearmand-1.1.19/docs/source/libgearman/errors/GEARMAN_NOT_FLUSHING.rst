====================
GEARMAN_NOT_FLUSHING
====================

Please see :c:type:`GEARMAN_NOT_FLUSHING`
