=====================
GEARMAN_INVALID_MAGIC
=====================

Please see :c:type:`GEARMAN_INVALID_MAGIC`
