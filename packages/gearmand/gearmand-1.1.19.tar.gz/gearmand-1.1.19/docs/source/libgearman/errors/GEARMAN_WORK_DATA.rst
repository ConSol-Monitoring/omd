=================
GEARMAN_WORK_DATA
=================

Please see :c:type:`GEARMAN_WORK_DATA`
