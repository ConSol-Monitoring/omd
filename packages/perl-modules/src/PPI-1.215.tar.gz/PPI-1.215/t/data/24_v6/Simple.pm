use v6-alpha;

foo
