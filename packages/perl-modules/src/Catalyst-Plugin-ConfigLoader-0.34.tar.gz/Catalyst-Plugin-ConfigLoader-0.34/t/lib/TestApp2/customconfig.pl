{
    bar => "baz2"
}
