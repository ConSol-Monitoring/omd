package main;
use MyClass;

my MyClass $x :Good :Bad(1**1-1) :Omni(vorous);

package SomeOtherClass;
use base MyClass;

sub tent { 'acle' }

sub w :Ugly(sister) :Omni('po',tent()) {}

my @y :Good :Omni(s/cie/nt/);

my %y :Good(q/bye) :Omni(q/bus/);

