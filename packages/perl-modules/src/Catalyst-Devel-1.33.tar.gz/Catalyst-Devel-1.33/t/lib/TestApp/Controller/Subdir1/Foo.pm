package TestApp::Controller::Subdir1::Foo;
use Moose;
BEGIN { extends 'Catalyst::Controller' }
1;
