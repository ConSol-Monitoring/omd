package Font::TTF::Woff::PrivateData;

=head1 NAME

Font::TTF::Woff::PrivateData - WOFF Private data

=head1 DESCRIPTION

Currently a stub, thus read() results in read_dat()

=head1 INSTANCE VARIABLES

=over 4

=back

=cut

use Font::TTF::Utils;
require Font::TTF::Table;

@ISA = qw(Font::TTF::Table);

1;
        
        
