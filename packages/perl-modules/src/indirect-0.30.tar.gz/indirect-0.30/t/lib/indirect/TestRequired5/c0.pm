package indirect::TestRequired5::c0;
require indirect::TestRequired5::d0;
1;
