package indirect::TestRequired1;

BEGIN { require strict; }

import strict;

eval 'import strict;';

1;
