package FCGI;

$VERSION = '0.73';
