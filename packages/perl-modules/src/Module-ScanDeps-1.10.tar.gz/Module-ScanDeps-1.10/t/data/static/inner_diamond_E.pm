package inner_diamond_E;

use inner_diamond_S;

1;
__END__