package t::lib::A;
use c3;
1;