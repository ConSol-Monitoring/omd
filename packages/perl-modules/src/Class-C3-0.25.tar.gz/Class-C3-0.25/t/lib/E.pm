package t::lib::E;
use c3;
1;