package FCGI;

$VERSION = '0.71';
