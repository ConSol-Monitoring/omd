package Dummy;

# Attempt to emulate a bug with finding the version in Exporter.
$VERSION = '5.562';
