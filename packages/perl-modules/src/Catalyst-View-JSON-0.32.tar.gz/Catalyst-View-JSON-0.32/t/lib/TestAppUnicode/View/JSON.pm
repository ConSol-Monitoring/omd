package TestAppUnicode::View::JSON;
use base qw( Catalyst::View::JSON );

1;
