package t::lib::E;
our @ISA = qw//;
1;
