package t::lib::F;
use base ('t::lib::C', 't::lib::D');
1;
