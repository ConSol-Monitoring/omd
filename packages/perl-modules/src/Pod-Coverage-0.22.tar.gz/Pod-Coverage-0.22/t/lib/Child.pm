package Child;
use Parent ();
use base 'Parent';

sub foo {
}

1;
__END__

