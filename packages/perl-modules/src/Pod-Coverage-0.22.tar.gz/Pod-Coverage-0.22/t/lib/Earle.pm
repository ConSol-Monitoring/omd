package Earle;

=head1 NAME

Earle - ape Earle's odd layout stuff.

=head2 C<foo(),bar(),baz()>

These subs are useful if you need example subs

=cut

sub foo {}
sub bar {}

1;
