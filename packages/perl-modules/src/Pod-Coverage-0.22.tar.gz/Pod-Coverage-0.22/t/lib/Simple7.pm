package Simple7;

=head1 NAME

Simple7 -  two, both uncovered

=cut

sub foo {}
sub bar {}

1;
__END__
