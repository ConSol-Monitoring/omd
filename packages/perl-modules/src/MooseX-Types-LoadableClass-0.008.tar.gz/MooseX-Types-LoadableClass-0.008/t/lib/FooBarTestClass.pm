package FooBarTestClass;
use Moose;

1;

