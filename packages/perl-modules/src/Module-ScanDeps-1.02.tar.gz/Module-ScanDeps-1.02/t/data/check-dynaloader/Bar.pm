package Bar;

use Cwd;
use File::Glob;	# Cwd is builtin in perl*.dll

1;

