package Monitoring::GLPlugin::SNMP::MibsAndOids::NETGEARMIB;

$Monitoring::GLPlugin::SNMP::MibsAndOids::origin->{'NETGEAR-MIB'} = {
  url => '',
  name => 'NETGEAR-MIB',
};

$Monitoring::GLPlugin::SNMP::MibsAndOids::mib_ids->{'NETGEAR-MIB'} = 
  '1.3.6.1.4.1.4526';

1;

__END__

