package t::lib::B;
use Class::C3;
1;
