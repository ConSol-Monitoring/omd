package HTTP::Server::PSGI::Net::Server::PreFork;
use parent qw(Starman::Server);

1;
