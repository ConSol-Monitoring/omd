package indirect::TestRequired5::b0;
sub get {
 eval 'require indirect::TestRequired5::c0';
}
1;
