package Monitoring::GLPlugin::DB::Item;
our @ISA = qw(Monitoring::GLPlugin::Item Monitoring::GLPlugin::DB);
use strict;

1;

__END__
