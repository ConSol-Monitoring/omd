use Foo;
1;
