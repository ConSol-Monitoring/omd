package Foo;

1;
