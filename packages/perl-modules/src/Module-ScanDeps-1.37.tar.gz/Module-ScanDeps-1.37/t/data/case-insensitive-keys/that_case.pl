use foo;
1;
