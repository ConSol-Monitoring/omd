package CatalystLike::Controller;
use Moose;
use namespace::clean -except => 'meta';
use MooseX::MethodAttributes;
extends 'MooseX::MethodAttributes::Inheritable';

1;


