package #
Date::Manip::Offset::off081;
# Copyright (c) 2008-2026 Sullivan Beck.  All rights reserved.
# This program is free software; you can redistribute it and/or modify it
# under the same terms as Perl itself.

# This file was automatically generated.  Any changes to this file will
# be lost the next time 'tzdata' is run.
#    Generated on: Mon Mar  2 13:07:45 EST 2026
#    Data version: tzdata2026a
#    Code version: tzcode2026a

# This module contains data from the zoneinfo time zone database.  The original
# data was obtained from the URL:
#    ftp://ftp.iana.org/tz

use strict;
use warnings;
require 5.010000;

our ($VERSION);
$VERSION='6.99';
END { undef $VERSION; }

our ($Offset,%Offset);
END {
   undef $Offset;
   undef %Offset;
}

$Offset        = '+03:30:00';

%Offset        = (
   0 => [
      'asia/tehran',
      ],
);

1;
