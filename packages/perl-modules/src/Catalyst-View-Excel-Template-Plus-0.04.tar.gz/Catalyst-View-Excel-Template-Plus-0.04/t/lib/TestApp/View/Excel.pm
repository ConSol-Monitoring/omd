package TestApp::View::Excel;

use strict;
use warnings;

use base 'Catalyst::View::Excel::Template::Plus';

1;

__END__
