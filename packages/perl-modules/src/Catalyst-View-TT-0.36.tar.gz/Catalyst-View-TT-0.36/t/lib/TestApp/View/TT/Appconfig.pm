package TestApp::View::TT::Appconfig;

use strict;
use base 'Catalyst::View::TT';

1;
