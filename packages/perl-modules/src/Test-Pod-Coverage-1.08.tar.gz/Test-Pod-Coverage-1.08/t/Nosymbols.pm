package Nosymbols;

=head1 NAME

This is a dummy module with all POD, no symbols.

=head1 DESCRIPTION

This is a pod file without errors.

=cut

1;
