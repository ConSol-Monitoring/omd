package Foo::Foo;
use strict;
use warnings;

our $VERSION = 0.01;

1;
