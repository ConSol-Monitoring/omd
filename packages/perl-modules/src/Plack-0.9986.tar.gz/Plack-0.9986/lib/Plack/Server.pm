package Plack::Server;
use strict;

1;

__END__

=head1 NAME

Plack::Server - DEPRECATED. See Plack::Handler

=head1 SEE ALSO

L<Plack::Handler>

=cut

