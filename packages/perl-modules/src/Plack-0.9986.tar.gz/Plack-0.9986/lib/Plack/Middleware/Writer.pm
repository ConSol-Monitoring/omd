package Plack::Middleware::Writer;
use strict;
use parent qw(Plack::Middleware::BufferedStreaming);

__END__

=head1 NAME

Plack::Middleware::Writer - DEPRECATED

=head1 SEE ALSO

L<Plack::Middleware::BufferedStreaming>

=cut
