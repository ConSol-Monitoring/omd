package GDTestApp::View::GD;

use strict;
use warnings;

use base 'Catalyst::View::GD';

1;

__END__
