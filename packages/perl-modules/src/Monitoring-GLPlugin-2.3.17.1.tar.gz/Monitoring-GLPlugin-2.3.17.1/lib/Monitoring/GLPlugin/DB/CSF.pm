package Monitoring::GLPlugin::DB::CSF;
#our @ISA = qw(Monitoring::GLPlugin::DB);
use strict;

# sub create_statefile
# will be set via symbol table, because different database types can have
# different command line parameters (used to construct a filename)

1;

__END__
