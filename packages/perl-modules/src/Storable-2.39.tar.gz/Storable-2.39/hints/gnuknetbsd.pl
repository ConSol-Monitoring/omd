do './hints/linux.pl' or die $@;
