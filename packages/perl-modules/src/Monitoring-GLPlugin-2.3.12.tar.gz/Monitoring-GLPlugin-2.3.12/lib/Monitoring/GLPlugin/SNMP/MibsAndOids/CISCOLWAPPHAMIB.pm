package Monitoring::GLPlugin::SNMP::MibsAndOids::CISCOLWAPPHAMIB;

$Monitoring::GLPlugin::SNMP::MibsAndOids::origin->{'CISCO-LWAPP-HA-MIB'} = {
  url => '',
  name => 'CISCO-LWAPP-HA-MIB',
};

#$Monitoring::GLPlugin::SNMP::MibsAndOids::mib_ids->{'CISCO-LWAPP-HA-MIB'} = 

$Monitoring::GLPlugin::SNMP::MibsAndOids::mibs_and_oids->{'CISCO-LWAPP-HA-MIB'} = {
  ciscoLwappHaMIB => '0.198888',
  ciscoLwappHaMIBObjects => '0.198888.0',
  ciscoLwappHaGlobalConfig => '0.198888.0.1',
  cLHaApSsoConfig => '0.198888.0.1.1',
  cLHaPeerIpAddressType => '0.198888.0.1.2',
  cLHaPeerIpAddress => '0.198888.0.1.3',
  cLHaServicePortPeerIpAddressType => '0.198888.0.1.4',
  cLHaServicePortPeerIpAddress => '0.198888.0.1.5',
  cLHaServicePortPeerIpNetMaskType => '0.198888.0.1.6',
  cLHaServicePortPeerIpNetMask => '0.198888.0.1.7',
  cLHaRedundancyIpAddressType => '0.198888.0.1.8',
  cLHaRedundancyIpAddress => '0.198888.0.1.9',
  cLHaPeerMacAddress => '0.198888.0.1.10',
  cLHaVirtualMacAddress => '0.198888.0.1.11',
  cLHaPrimaryUnit => '0.198888.0.1.12',
  cLHaLinkEncryption => '0.198888.0.1.13',
  cLHaNetworkFailOver => '0.198888.0.1.14',
  cLHaRFStatusUnitIp => '0.198888.0.1.15',
  ciscoLwappHaNetworkConfig => '0.198888.0.2',
  cLHaNetworkRoutePeerConfigTable => '0.198888.0.2.1',
  cLHaNetworkRoutePeerConfigEntry => '0.198888.0.2.1.1',
  cLHaNetworkRoutePeerIPAddressType => '0.198888.0.2.1.1.1',
  cLHaNetworkRoutePeerIPAddress => '0.198888.0.2.1.1.2',
  cLHaNetworkRoutePeerIPNetmaskType => '0.198888.0.2.1.1.3',
  cLHaNetworkRoutePeerIPNetmask => '0.198888.0.2.1.1.4',
  cLHaNetworkRoutePeerGatewayType => '0.198888.0.2.1.1.5',
  cLHaNetworkRoutePeerGateway => '0.198888.0.2.1.1.6',
  cLHaNetworkRoutePeerTransferStatus => '0.198888.0.2.1.1.7',
  cLHaNetworkRoutePeerTransferStatusDefinition => 'CISCO-LWAPP-HA-MIB::cLHaNetworkRoutePeerTransferStatus',
  cLHaNetworkRoutePeerRowStatus => '0.198888.0.2.1.1.8',
  ciscoLwappHaMIBNotifs => '0.198888.0.3',
  ciscoLwappHaNotificationVariable => '0.198888.0.4',
  cLHaSecondaryControllerUsageTrapType => '0.198888.0.4.1',
  cLHaSecondaryControllerUsageTrapTypeDefinition => 'CISCO-LWAPP-HA-MIB::cLHaSecondaryControllerUsageTrapType',
  cLHaSecondaryControllerUsageDayCounter => '0.198888.0.4.2',
};

$Monitoring::GLPlugin::SNMP::MibsAndOids::definitions->{'CISCO-LWAPP-HA-MIB'} = {
  cLHaSecondaryControllerUsageTrapType => {
    '1' => 'usageStart',
    '2' => 'usageComplete',
    '3' => 'overUsage',
  },
  cLHaNetworkRoutePeerTransferStatus => {
    '1' => 'initiate',
    '2' => 'inProgress',
    '3' => 'success',
    '4' => 'failure',
    '5' => 'timeout',
  },
};
