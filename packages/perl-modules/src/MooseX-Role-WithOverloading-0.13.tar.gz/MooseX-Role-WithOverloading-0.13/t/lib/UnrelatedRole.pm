package UnrelatedRole;

use Moose::Role;
use namespace::autoclean;

1;
