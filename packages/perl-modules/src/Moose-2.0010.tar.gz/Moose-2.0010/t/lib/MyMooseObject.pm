package MyMooseObject;

use strict;
use warnings;
use base 'Moose::Object';

1;