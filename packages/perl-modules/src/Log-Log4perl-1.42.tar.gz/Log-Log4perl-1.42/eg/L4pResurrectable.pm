package L4pResurrectable;
use Log::Log4perl qw(:easy);
use vars qw($VERSION);

$VERSION = "0.01";

sub foo {
    ###l4p DEBUG "foo was here";
    ###l4p INFO  "bar was here";
}

1;
