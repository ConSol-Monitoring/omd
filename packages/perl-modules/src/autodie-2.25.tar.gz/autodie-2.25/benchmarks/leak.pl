#!/usr/bin/perl -w
use 5.010;
use strict;
use warnings;
use autodie;

use Fatal_Leaky_Benchmark;

run();  # Loaded from my leaky benchmark
