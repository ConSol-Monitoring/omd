{   name      => 'TestApp',
    Component => { 'Controller::Foo' => { foo => 'bar' } },
    Model     => { 'Model::Baz' => { qux => 'xyzzy' } }
}
