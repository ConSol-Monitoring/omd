package Monitoring::GLPlugin::SNMP::MibsAndOids::OLDSTATISTICSMIB;

$Monitoring::GLPlugin::SNMP::MibsAndOids::origin->{'OLD-STATISTICS-MIB'} = {
  url => '',
  name => 'OLD-STATISTICS-MIB',
};

$Monitoring::GLPlugin::SNMP::MibsAndOids::mibs_and_oids->{'OLD-STATISTICS-MIB'} = {
  'hpSwitchCpuStat' => '1.3.6.1.2.1.1.7.11.12.9.6.1.0',
};


1;

__END__
