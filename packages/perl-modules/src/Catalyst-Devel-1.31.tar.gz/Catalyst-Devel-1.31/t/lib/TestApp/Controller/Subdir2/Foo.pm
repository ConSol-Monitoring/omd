package TestApp::Controller::Subdir2::Foo;
use Moose;
BEGIN { extends 'Catalyst::Controller' }
1;
