package Monitoring::GLPlugin::SNMP::MibsAndOids::STATISTICSMIB;

$Monitoring::GLPlugin::SNMP::MibsAndOids::origin->{'STATISTICS-MIB'} = {
  url => '',
  name => 'STATISTICS-MIB',
};

$Monitoring::GLPlugin::SNMP::MibsAndOids::mibs_and_oids->{'STATISTICS-MIB'} = {
  'hpSwitchCpuStat' => '1.3.6.1.4.1.11.2.14.11.5.1.9.6.1.0',
};


1;

__END__
