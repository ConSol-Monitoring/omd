use strict;
use warnings;
package DoesNotCompile;

this is a syntax error;

0;
