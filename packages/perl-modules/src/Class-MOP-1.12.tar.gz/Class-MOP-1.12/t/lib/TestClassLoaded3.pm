package TestClassLoaded3;
use strict;
use warnings;

our @ISA = 'Foo';

1;

