
package MyMetaClass::Attribute;

use strict;
use warnings;

use base 'Class::MOP::Attribute';

1;
