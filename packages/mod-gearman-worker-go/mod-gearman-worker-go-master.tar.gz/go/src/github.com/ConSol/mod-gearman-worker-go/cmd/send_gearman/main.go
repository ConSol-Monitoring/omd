package main

import (
	modgearman "github.com/ConSol/mod-gearman-worker-go"
)

func main() {
	modgearman.Sendgearman()
}
