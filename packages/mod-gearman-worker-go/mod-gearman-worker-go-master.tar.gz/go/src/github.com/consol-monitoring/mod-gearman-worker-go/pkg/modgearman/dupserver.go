package modgearman

import (
	time "time"

	"github.com/appscode/g2/client"
)

type dupServerConsumer struct {
	queue              chan *answer
	address            string
	terminationRequest chan bool
	config             *config
}

var dupServerConsumers map[string]*dupServerConsumer

func initializeDupServerConsumers(config *config) {
	if len(config.dupserver) > 0 {
		dupServerConsumers = make(map[string]*dupServerConsumer)
		for _, dupAddress := range config.dupserver {
			log.Debugf("creating dupserverConsumer for: %s", dupAddress)
			consumer := &dupServerConsumer{
				terminationRequest: make(chan bool),
				queue:              make(chan *answer, config.dupServerBacklogQueueSize),
				address:            dupAddress,
				config:             config,
			}

			dupServerConsumers[dupAddress] = consumer
			go runDupServerConsumer(consumer)
		}
	}
}

func terminateDupServerConsumers() bool {
	log.Debugf("Terminating DupServers")
	for _, consumer := range dupServerConsumers {
		log.Debugf("Sending DupServer TerminationRequest %s", consumer.address)
		consumer.terminationRequest <- true
		log.Debugf("DupServer Terminated %s", consumer.address)
	}
	log.Debugf("Completed all consumer termination")
	dupServerConsumers = nil

	return true
}

func runDupServerConsumer(dupServer *dupServerConsumer) {
	var clt *client.Client
	var item *answer
	var err error

	for {
		select {
		case <-dupServer.terminationRequest:
			if clt != nil {
				clt.Close()
			}

			return
		case item = <-dupServer.queue:
			for {
				clt, err = sendResultDup(clt, item, dupServer.address, dupServer.config)
				if err != nil {
					clt = nil
					log.Debugf("failed to send back result (to dupserver): %w", err)
					select {
					case <-dupServer.terminationRequest:
						return
					default:
						time.Sleep(ConnectionRetryInterval * time.Second)

						continue
					}
				}

				break
			}
		}
	}
}

func sendResultDup(clt *client.Client, item *answer, dupAddress string, config *config) (*client.Client, error) {
	if config.dupResultsArePassive {
		item.active = "passive"
	}

	return sendAnswer(clt, item, dupAddress, config.encryption)
}

func enqueueDupServerResult(config *config, result *answer) {
	if len(config.dupserver) == 0 {
		return
	}
	duplicateResult := *result

	for _, dupAddress := range config.dupserver {
		channel := dupServerConsumers[dupAddress].queue
		select {
		case channel <- &duplicateResult:
		default:
			log.Debugf("channel is at capacity (%d), dropping message (to dupserver): %s",
				config.dupServerBacklogQueueSize,
				dupAddress,
			)
		}
	}
}
