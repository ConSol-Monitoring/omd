module github.com/consol-monitoring/mod-gearman-worker-go

go 1.26.1

require (
	github.com/appscode/g2 v0.0.0-20190123131438-388ba74fd273
	github.com/consol-monitoring/check_nsc_web v0.7.4
	github.com/consol-monitoring/check_prometheus v0.0.0-20260211103550-7975b0b2fb41
	github.com/davecgh/go-spew v1.1.2-0.20180830191138-d8f796af33cc // indirect
	github.com/kdar/factorlog v0.0.0-20211012144011-6ea75a169038
	github.com/nsf/termbox-go v1.1.1
	github.com/prometheus/client_golang v1.23.2
	github.com/prometheus/client_model v0.6.2
	github.com/sevlyar/go-daemon v0.1.6
	github.com/sni/shelltoken v0.0.0-20251121074725-29095f38eced
	github.com/stretchr/testify v1.11.1
)

require (
	github.com/appscode/go v0.0.0-20201105063637-5613f3b8169f // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/clipperhouse/uax29/v2 v2.7.0 // indirect
	github.com/consol-monitoring/check_x v0.0.0-20260108170459-f7c19720a9ad // indirect
	github.com/golang/glog v1.2.5 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/kardianos/osext v0.0.0-20190222173326-2bc1f35cddc0 // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mattn/go-runewidth v0.0.21 // indirect
	github.com/mgutz/ansi v0.0.0-20200706080929-d51e80ef957d // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/pmezard/go-difflib v1.0.1-0.20181226105442-5d4384ee4fb2 // indirect
	github.com/prometheus/common v0.67.5 // indirect
	github.com/prometheus/procfs v0.20.1 // indirect
	github.com/urfave/cli/v3 v3.8.0 // indirect
	go.yaml.in/yaml/v2 v2.4.4 // indirect
	golang.org/x/sys v0.42.0 // indirect
	google.golang.org/protobuf v1.36.11 // indirect
	gopkg.in/robfig/cron.v2 v2.0.0-20150107220207-be2e0b0deed5 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
