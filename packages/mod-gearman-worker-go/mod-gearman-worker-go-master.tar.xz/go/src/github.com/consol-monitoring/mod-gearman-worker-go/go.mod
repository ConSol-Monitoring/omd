module github.com/consol-monitoring/mod-gearman-worker-go

go 1.26.6

require (
	github.com/appscode/g2 v0.0.0-20190123131438-388ba74fd273
	github.com/consol-monitoring/check_nsc_web v0.7.6
	github.com/consol-monitoring/check_prometheus v0.0.0-20260610160258-069b04a28bd9
	github.com/kdar/factorlog v0.0.0-20211012144011-6ea75a169038
	github.com/nsf/termbox-go v1.1.2
	github.com/prometheus/client_golang v1.24.1
	github.com/prometheus/client_model v0.6.2
	github.com/sevlyar/go-daemon v0.1.7
	github.com/sni/shelltoken v0.0.0-20260824150518-ba5b457dfc8c
	github.com/stretchr/testify v1.12.1
)

require (
	github.com/appscode/go v0.0.0-20201105063637-5613f3b8169f // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/clipperhouse/uax29/v2 v2.7.0 // indirect
	github.com/consol-monitoring/check_x v0.0.0-20260709081430-c4562508a464 // indirect
	github.com/golang/glog v1.2.5 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/kardianos/osext v0.0.0-20190222173326-2bc1f35cddc0 // indirect
	github.com/mattn/go-colorable v0.1.15 // indirect
	github.com/mattn/go-isatty v0.0.24 // indirect
	github.com/mattn/go-runewidth v0.0.28 // indirect
	github.com/mgutz/ansi v0.0.0-20200706080929-d51e80ef957d // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/prometheus/common v0.70.1 // indirect
	github.com/prometheus/procfs v0.21.1 // indirect
	github.com/urfave/cli/v3 v3.11.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/sys v0.47.0 // indirect
	google.golang.org/protobuf v1.36.12 // indirect
	gopkg.in/robfig/cron.v2 v2.0.0-20150107220207-be2e0b0deed5 // indirect
)
