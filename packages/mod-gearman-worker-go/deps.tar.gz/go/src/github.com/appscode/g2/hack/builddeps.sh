#!/bin/bash

# https://github.com/ellisonbg/antipackage
pip install git+https://github.com/ellisonbg/antipackage.git#egg=antipackage

# https://godoc.org/golang.org/x/tools/cmd/stringer
go get -u golang.org/x/tools/cmd/stringer
