$criticalpatterns = [
  "ALAAARM",
];
