package CheckUpsHealth::UPS;
our @ISA = qw(CheckUpsHealth::Device);
use strict;

sub init {
  my ($self) = @_;
  # pre-flight, health modes only: agent reachable but the whole UPS
  # measurement subtree is gone (no battery status and no output source).
  # Two distinct fault states, both need a page; utility modes
  # (uptime, snmpget, walk, ...) fall through to the framework unchanged.
  if ($self->mode =~ /device::(hardware::health|battery)/) {
    $self->get_snmp_objects("UPS-MIB", qw(upsBatteryStatus upsOutputSource));
    if (! defined $self->{upsBatteryStatus} && ! defined $self->{upsOutputSource}) {
      # tag is set only by the TRIMOD branch in Device.pm
      # (check_snmp_and_model: degraded MIB-2 + upsIdentModel =~ /TRIMOD/)
      if ($self->{productname} eq "TRIMOD-with-broken-firmware") {
        $self->add_critical_mitigation(
            'TRIMOD with broken firmware (mid firmware-update?), no UPS measurement data');
      } else {
        $self->add_critical_mitigation(
            'agent reports no battery or output data - lost communication with the UPS controller?');
      }
      return;
    }
  }
  if ($self->mode =~ /device::hardware::health/) {
    $self->analyze_and_check_environmental_subsystem('CheckUpsHealth::UPS::Component::EnvironmentalSubsystem');
  } elsif ($self->mode =~ /device::battery/) {
    $self->analyze_and_check_battery_subsystem('CheckUpsHealth::UPS::Component::BatterySubsystem');
  } else {
    $self->no_such_mode();
  }
}

