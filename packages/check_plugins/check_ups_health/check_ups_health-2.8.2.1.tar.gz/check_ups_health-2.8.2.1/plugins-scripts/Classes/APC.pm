package Classes::APC;
our @ISA = qw(Classes::Device);
use strict;
