package CheckUpsHealth::APC;
our @ISA = qw(CheckUpsHealth::Device);
use strict;
