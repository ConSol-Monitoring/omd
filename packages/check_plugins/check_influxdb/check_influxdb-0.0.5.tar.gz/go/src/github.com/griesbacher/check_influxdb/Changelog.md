# 0.0.5 - 06.04.2017
## Features:
- Query mode - allows to check a single value from the database

# 0.0.4 - 29.09.2016
## Fixes:
- Memory mode: removed necessary database flag
- ReadWrite mode: added ops to read and write

# 0.0.3 - 28.09.2016
## Features:
- old series mode: lists all forgotten series

# 0.0.2 - 28.09.2016
## Features:
- ReadWrite mode - checks the bytes per second on read and write
- Memory mode - checks the RSS

# 0.0.1 - 27.09.2016
## Features:
- Ping mode - tests if InfluxDB is alive
- Disk mode - measures the disk usage
- Number of Services/Measurements
- Difference of Services/Measurements