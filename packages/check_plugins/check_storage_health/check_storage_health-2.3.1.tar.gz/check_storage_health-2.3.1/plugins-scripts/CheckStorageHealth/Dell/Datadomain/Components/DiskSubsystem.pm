package CheckStorageHealth::Dell::Datadomain::Component::DiskSubsystem;
use parent -norequire, 'Monitoring::GLPlugin::SNMP::Item';
use strict;

sub init {
  my ($self) = @_;
  # heuristisch rumprobiert
  $self->reset_snmp_max_msg_size();
  $self->mult_snmp_max_msg_size(10);
  $self->bulk_is_baeh(5);
  $self->get_snmp_tables("DATA-DOMAIN-MIB", [
      ["diskperformances", "diskPerformanceTable", "CheckStorageHealth::Dell::Datadomain::Component::EnvironmentalSubsystem::DiskPerformance"],
  ]);
  $self->reset_snmp_max_msg_size();
  $self->get_snmp_tables("DATA-DOMAIN-MIB", [
      ["nvrambatterys", "nvramBatteryTable", "CheckStorageHealth::Dell::Datadomain::Component::EnvironmentalSubsystem::NvramBattery"],
      ["diskproperties", "diskPropertiesTable", "CheckStorageHealth::Dell::Datadomain::Component::EnvironmentalSubsystem::DiskProperties"],
      ["diskreliabilitys", "diskReliabilityTable", "CheckStorageHealth::Dell::Datadomain::Component::EnvironmentalSubsystem::DiskReliability"],
  ]);
  foreach my $diskprop (@{$self->{diskproperties}}) {
    if ($diskprop->{diskPropState} eq "unknown") {
      # kann bedeuten, dass die Disk zum Cloud Tier gehoert und dieser nicht
      # benutzt wird.
      @{$self->{diskperformances}} = grep {
          $_->{name} ne $diskprop->{name}
      } @{$self->{diskperformances}};
      @{$self->{diskreliabilitys}} = grep {
          $_->{name} ne $diskprop->{name}
      } @{$self->{diskreliabilitys}};
    }
  }

}

package CheckStorageHealth::Dell::Datadomain::Component::EnvironmentalSubsystem::NvramBattery;
use parent -norequire, 'Monitoring::GLPlugin::SNMP::TableItem';
use strict;

sub check {
  my($self) = @_;
  $self->add_info(sprintf "nvram battery %s has status %s",
      $self->{nvramBatteriesIndex}, $self->{nvramBatteryStatus});
  if ($self->{nvramBatteryStatus} ne "ok") {
    $self->add_warning_mitigation();
  }
}

package CheckStorageHealth::Dell::Datadomain::Component::EnvironmentalSubsystem::DiskPerformance;
use parent -norequire, 'Monitoring::GLPlugin::SNMP::TableItem';
use strict;

sub finish {
  my($self) = @_;
  $self->{name} = sprintf "enc:%s/disk:%s",
      $self->{diskPerfEnclosureID}, $self->{diskPerfIndex};
}

sub check {
  my($self) = @_;
  $self->add_info(sprintf "performance of enc:%s/disk:%s is %s (%.2f%% busy)",
      $self->{diskPerfEnclosureID}, $self->{diskPerfIndex},
      $self->{diskPerfState}, $self->{diskBusy});
  if ($self->{diskPerfState} ne "ok" and $self->{diskPerfState} ne "spare") {
    $self->add_warning_mitigation();
  }
}

package CheckStorageHealth::Dell::Datadomain::Component::EnvironmentalSubsystem::DiskProperties;
use parent -norequire, 'Monitoring::GLPlugin::SNMP::TableItem';
use strict;

sub finish {
  my($self) = @_;
  $self->{name} = sprintf "enc:%s/disk:%s",
      $self->{diskPropEnclosureID}, $self->{diskPropIndex};
}

sub check {
  my($self) = @_;
  $self->add_info(sprintf "disk enc:%s/disk:%s (%s) has status %s",
      $self->{diskPropEnclosureID}, $self->{diskPropIndex}, $self->{diskModel},
      $self->{diskPropState});
  if ($self->{diskPropState} eq "failed") {
    $self->add_warning();
  }
}

package CheckStorageHealth::Dell::Datadomain::Component::EnvironmentalSubsystem::DiskReliability;
use parent -norequire, 'Monitoring::GLPlugin::SNMP::TableItem';
use strict;

sub finish {
  my($self) = @_;
  $self->{name} = sprintf "enc:%s/disk:%s",
      $self->{diskErrEnclosureID}, $self->{diskErrIndex};
}

sub check {
  my($self) = @_;
  $self->add_info(sprintf "disk reliability enc:%s/disk:%s has status %s",
      $self->{diskErrEnclosureID}, $self->{diskErrIndex},
      $self->{diskErrState});
  if ($self->{diskErrState} ne "ok" and $self->{diskErrState} ne "spare") {
    $self->add_warning_mitigation();
  }
}

