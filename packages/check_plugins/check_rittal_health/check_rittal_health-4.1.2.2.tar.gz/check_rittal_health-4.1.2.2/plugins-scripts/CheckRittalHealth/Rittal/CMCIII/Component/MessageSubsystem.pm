package CheckRittalHealth::Rittal::CMCIII::Component::MessageSubsystem;
our @ISA = qw(Monitoring::GLPlugin::SNMP::Item);
use strict;

sub init {
  my $self = shift;
  foreach my $scalar (qw(cmcIIIOverallMsgStatus cmcIIINumberOfMsgs)) {
    my $value = $self->get_snmp_object('RITTAL-CMC-III-MIB', $scalar, 0);
    $self->{$scalar} = $value if defined $value;
  }
  my %messages;
  foreach my $column (qw(cmcIIIMsgQuality cmcIIIMsgStatusText)) {
    foreach my $row ($self->get_snmp_table_objects('RITTAL-CMC-III-MIB',
        'cmcIIIMsgTable', undef, [$column])) {
      my $index = join('.', @{$row->{indices}});
      $messages{$index} ||= { indices => $row->{indices}, flat_indices => $row->{flat_indices} };
      $messages{$index}->{$column} = $row->{$column} if exists $row->{$column};
    }
  }
  $self->{messages} = [map {
      CheckRittalHealth::Rittal::CMCIII::Component::MessageSubsystem::Message->new(%{$messages{$_}})
  } sort keys %messages];
}

sub get_entries_get_bulk {
  my ($self, %params) = @_;
  return $self->SUPER::get_entries_get_bulk(%params)
      if $Monitoring::GLPlugin::SNMP::session->version() == 0;
  $params{'-maxrepetitions'} = 10;
  if ($Monitoring::GLPlugin::SNMP::session->version() == 3) {
    $params{-contextengineid} = $self->opts->contextengineid if $self->opts->contextengineid;
    $params{-contextname} = $self->opts->contextname if $self->opts->contextname;
  }
  $self->debug('CMC III message walk: maxrepetitions 10');
  return $Monitoring::GLPlugin::SNMP::session->get_entries(%params);
}

sub check {
  my $self = shift;
  if ($self->mode =~ /device::devices::list/) {
    foreach (@{$self->{devices}}) {
      #printf "dev%d\n", $unit if $self->{"unit$unit"}->{cmcTcUnitStatus} ne "notAvail";
      printf "%s\n", Data::Dumper::Dumper($_);
    }
    $self->add_ok("have fun");
  } elsif ($self->mode =~ /device::variables::list/) {
    foreach (@{$self->{variables}}) {
      printf "%s\n", Data::Dumper::Dumper($_);
    }
    $self->add_ok("have fun");
  } elsif ($self->mode =~ /device::(units|sensors)/) {
    my $info = sprintf 'message status is %s',
        $self->{cmcIIIOverallMsgStatus};
    $self->add_info($info);
    if ($self->{cmcIIIOverallMsgStatus} ne 'ok') {
      $self->add_critical();
    } else {
      #$self->add_ok();
    }
    foreach (@{$self->{messages}}) {
      $_->check();
    }
    #delete $self->{variables};
  } else {
    $self->no_such_mode();
  }
}


package CheckRittalHealth::Rittal::CMCIII::Component::MessageSubsystem::Message;
our @ISA = qw(Monitoring::GLPlugin::SNMP::TableItem);
use strict;

sub finish {
  my $self = shift;
  $self->{cmcIIIDevIndex} = $self->{indices}->[0];
  if ($self->{cmcIIIMsgStatusText} =~ /^(?:[0-9a-f]{2} )+[0-9a-f]{2}$/i) {
    $self->{cmcIIIMsgStatusText} =~ s/\s//g;
    $self->{cmcIIIMsgStatusText} =~ s/(([0-9a-f][0-9a-f])+)/pack('H*', $1)/ie;
  }
}

sub check {
  my $self = shift;
  $self->add_info(sprintf '%s message: %s',
      $self->{cmcIIIMsgQuality}, $self->{cmcIIIMsgStatusText});
  if ($self->{cmcIIIMsgQuality} =~ /^warning/) {
    $self->add_warning();
  } elsif ($self->{cmcIIIMsgQuality} =~ /^alarm/) {
    $self->add_critical();
  } elsif ($self->{cmcIIIMsgQuality} =~ /^undefined/) {
    $self->add_unknown();
  }
}

