package CheckRittalHealth::Rittal::CMCIII;
our @ISA = qw(CheckRittalHealth::Rittal);
use strict;


sub init {
  my $self = shift;
  if ($self->mode =~ /device::(units|sensors)/) {
    # The shorter request timeout is specific to CMC III and is restored
    # after this check, leaving other models' SNMP sessions unchanged.
    # The short timeouts result in more retries, where in the system-wide session the
    # first attempt can already consume too much of the valuable time.
    local $Monitoring::GLPlugin::SNMP::session = $Monitoring::GLPlugin::SNMP::session;
    local $Monitoring::GLPlugin::SNMP::session_params = $Monitoring::GLPlugin::SNMP::session_params;
    $self->cmc_short_snmp_session();
    $self->{cmcIIIUnitStatus} = $self->get_snmp_object(
        'RITTAL-CMC-III-MIB', 'cmcIIIUnitStatus', 0);
    if (! $self->{cmcIIIUnitStatus}) {
      $self->add_critical('snmpwalk returns no health data (rittal-cmc-mib)');
    } else {
      $self->analyze_and_check_device_subsystem('CheckRittalHealth::Rittal::CMCIII::Component::DeviceSubsystem');
      $self->analyze_and_check_message_subsystem('CheckRittalHealth::Rittal::CMCIII::Component::MessageSubsystem');
    }
  } else {
    $self->no_such_mode();
  }
}

sub cmc_short_snmp_session {
  no warnings 'once';
  my $self = shift;
  my $session = $Monitoring::GLPlugin::SNMP::session;
  return unless $session && $session->timeout() > 2;
  my $backend = $Monitoring::GLPlugin::SNMP::backend;
  my $backend_class = $backend eq 'SNMP'
      ? 'Monitoring::GLPlugin::SNMP::Backend::XS'
      : $backend eq 'Net::SNMP'
      ? 'Monitoring::GLPlugin::SNMP::Backend::Netsnmp' : undef;
  return unless $backend_class;
  my %params = %{$Monitoring::GLPlugin::SNMP::session_params};
  $params{'-timeout'} = 2;
  my ($short_session, $error) = $backend_class->session(%params);
  if ($short_session) {
    $Monitoring::GLPlugin::SNMP::session = $short_session;
    $Monitoring::GLPlugin::SNMP::session_params = \%params;
    $self->debug('CMC III %s session request timeout set to 2 seconds', $backend);
  } else {
    $self->add_unknown('unable to create CMC III SNMP session with shorter request timeout');
    $self->debug('CMC III %s session creation failed: %s', $backend, $error || 'unknown error');
  }
}

sub check {
  my $self = shift;
}

