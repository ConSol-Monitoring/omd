package CheckNwcHealth::VRRPMIB;
our @ISA = qw(CheckNwcHealth::Device);
use strict;
