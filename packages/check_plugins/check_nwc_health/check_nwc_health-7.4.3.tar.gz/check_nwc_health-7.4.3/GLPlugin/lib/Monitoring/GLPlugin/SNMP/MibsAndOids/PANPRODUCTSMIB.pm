package Monitoring::GLPlugin::SNMP::MibsAndOids::PANPRODUCTSMIB;

$Monitoring::GLPlugin::SNMP::MibsAndOids::origin->{'PAN-PRODUCTS-MIB'} = {
  url => '',
  name => 'PAN-PRODUCTS-MIB',
};

$Monitoring::GLPlugin::SNMP::MibsAndOids::mib_ids->{'PAN-PRODUCTS-MIB'} = 
  '1.3.6.1.4.1.25461.2.3';

1;

__END__

