package CheckNwcHealth::IPFORWARDMIB;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

