package Classes::RAPIDCITYMIB;
our @ISA = qw(Classes::Device);
use strict;

