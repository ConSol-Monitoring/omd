package CheckNwcHealth::Bintec;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

