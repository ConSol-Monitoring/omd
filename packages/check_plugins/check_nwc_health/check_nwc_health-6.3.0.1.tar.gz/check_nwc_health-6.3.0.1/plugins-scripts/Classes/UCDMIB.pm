package Classes::UCDMIB;
our @ISA = qw(Classes::Device);
use strict;

