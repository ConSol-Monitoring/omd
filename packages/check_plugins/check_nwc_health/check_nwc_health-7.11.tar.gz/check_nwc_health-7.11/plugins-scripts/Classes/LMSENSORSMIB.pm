package Classes::LMSENSORSMIB;
our @ISA = qw(Classes::Device);
use strict;

