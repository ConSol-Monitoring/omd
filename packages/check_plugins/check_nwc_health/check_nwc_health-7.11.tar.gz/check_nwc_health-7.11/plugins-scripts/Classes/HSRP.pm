package Classes::HSRP;
our @ISA = qw(Classes::Device);
use strict;

