package Classes::VRRPMIB;
our @ISA = qw(Classes::Device);
use strict;
