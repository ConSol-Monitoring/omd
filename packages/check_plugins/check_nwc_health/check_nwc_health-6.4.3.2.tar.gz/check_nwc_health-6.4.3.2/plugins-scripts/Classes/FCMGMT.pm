package Classes::FCMGMT;
our @ISA = qw(Classes::Device);
use strict;

