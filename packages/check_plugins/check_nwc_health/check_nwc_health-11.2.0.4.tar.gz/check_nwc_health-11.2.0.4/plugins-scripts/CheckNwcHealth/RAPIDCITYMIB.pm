package CheckNwcHealth::RAPIDCITYMIB;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

