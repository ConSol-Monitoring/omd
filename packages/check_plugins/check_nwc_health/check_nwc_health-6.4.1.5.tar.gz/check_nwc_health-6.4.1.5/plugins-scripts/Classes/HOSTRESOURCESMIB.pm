package Classes::HOSTRESOURCESMIB;
our @ISA = qw(Classes::Device);
use strict;

