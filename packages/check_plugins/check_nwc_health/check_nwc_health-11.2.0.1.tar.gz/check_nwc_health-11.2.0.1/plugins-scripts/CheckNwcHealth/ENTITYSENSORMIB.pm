package CheckNwcHealth::ENTITYSENSORMIB;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

