package Classes::IPMIB;
our @ISA = qw(Classes::Device);
use strict;

