package Classes::ENTITYSENSORMIB;
our @ISA = qw(Classes::Device);
use strict;

