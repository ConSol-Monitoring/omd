package Classes::Bintec;
our @ISA = qw(Classes::Device);
use strict;

