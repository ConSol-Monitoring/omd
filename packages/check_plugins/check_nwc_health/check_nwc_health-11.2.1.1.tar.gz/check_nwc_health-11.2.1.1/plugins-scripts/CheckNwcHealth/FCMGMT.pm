package CheckNwcHealth::FCMGMT;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

