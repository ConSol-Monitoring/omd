package CheckNwcHealth::BGP;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

