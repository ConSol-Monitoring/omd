package Classes::IFMIB;
our @ISA = qw(Monitoring::GLPlugin::SNMP::Item);
use strict;

