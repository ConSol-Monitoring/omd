package CheckNwcHealth::HH3C::Component::EntitySubsystem;
our @ISA = qw(Monitoring::GLPlugin::SNMP::Item);
use strict;

