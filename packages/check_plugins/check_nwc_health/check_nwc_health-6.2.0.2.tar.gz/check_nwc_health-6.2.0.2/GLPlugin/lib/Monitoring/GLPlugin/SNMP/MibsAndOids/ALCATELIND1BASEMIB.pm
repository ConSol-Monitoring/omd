package Monitoring::GLPlugin::SNMP::MibsAndOids::ALCATELIND1BASEMIB;

$Monitoring::GLPlugin::SNMP::MibsAndOids::origin->{'ALCATEL-IND1-BASE-MIB'} = {
  url => '',
  name => 'ALCATEL-IND1-BASE-MIB',
};

$Monitoring::GLPlugin::SNMP::MibsAndOids::mib_ids->{'ALCATEL-IND1-BASE-MIB'} = 
  '1.3.6.1.4.1.6486.800';

1;

__END__

