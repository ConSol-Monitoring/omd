package Monitoring::GLPlugin::SNMP::MibsAndOids::SYNOPTICSROOTMIB;

$Monitoring::GLPlugin::SNMP::MibsAndOids::origin->{'SYNOPTICS-ROOT-MIB'} = {
  url => '',
  name => 'SW-MIB',
};

$Monitoring::GLPlugin::SNMP::MibsAndOids::mib_ids->{'SYNOPTICS-ROOT-MIB'} = 
  '1.3.6.1.4.1.45.3';

1;

__END__

