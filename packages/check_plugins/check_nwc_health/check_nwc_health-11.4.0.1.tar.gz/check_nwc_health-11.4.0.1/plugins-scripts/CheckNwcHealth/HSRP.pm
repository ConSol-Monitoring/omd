package CheckNwcHealth::HSRP;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

