package Monitoring::GLPlugin::SNMP::MibsAndOids::NETSCREENPRODUCTSMIB;

$Monitoring::GLPlugin::SNMP::MibsAndOids::origin->{'NETSCREEN-PRODUCTS-MIB'} = {
  url => '',
  name => 'NETSCREEN-PRODUCTS-MIB',
};

$Monitoring::GLPlugin::SNMP::MibsAndOids::mib_ids->{'NETSCREEN-PRODUCTS-MIB'} = 
  '1.3.6.1.4.1.3224.1';

1;

__END__

