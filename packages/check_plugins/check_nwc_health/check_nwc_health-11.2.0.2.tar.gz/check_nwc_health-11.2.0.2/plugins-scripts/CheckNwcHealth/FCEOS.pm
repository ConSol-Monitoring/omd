package CheckNwcHealth::FCEOS;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

