package CheckNwcHealth::LMSENSORSMIB;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

