package CheckNwcHealth::UPNP;
our @ISA = qw(CheckNwcHealth::Device);
use strict;

