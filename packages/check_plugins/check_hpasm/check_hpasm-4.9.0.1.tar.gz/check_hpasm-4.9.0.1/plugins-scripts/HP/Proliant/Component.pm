package HP::Proliant::Component;
our @ISA = qw(HP::Proliant);

1;

