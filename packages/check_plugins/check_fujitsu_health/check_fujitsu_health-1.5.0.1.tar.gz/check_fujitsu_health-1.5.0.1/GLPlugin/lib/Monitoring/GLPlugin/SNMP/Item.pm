package Monitoring::GLPlugin::SNMP::Item;
our @ISA = qw(Monitoring::GLPlugin::SNMP::CSF Monitoring::GLPlugin::Item Monitoring::GLPlugin::SNMP);
use strict;

1;

__END__
