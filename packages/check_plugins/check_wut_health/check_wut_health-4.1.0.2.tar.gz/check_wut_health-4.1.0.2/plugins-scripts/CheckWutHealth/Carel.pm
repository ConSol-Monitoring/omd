package CheckWutHealth::Carel;
our @ISA = qw(CheckWutHealth::Device);
use strict;
