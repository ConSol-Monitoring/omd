package CheckWutHealth::Rittal;
our @ISA = qw(CheckWutHealth::Device);
use strict;


