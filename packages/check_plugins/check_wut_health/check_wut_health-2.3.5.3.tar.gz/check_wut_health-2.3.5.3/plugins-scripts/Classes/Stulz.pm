package Classes::Stulz;
our @ISA = qw(Classes::Device);


