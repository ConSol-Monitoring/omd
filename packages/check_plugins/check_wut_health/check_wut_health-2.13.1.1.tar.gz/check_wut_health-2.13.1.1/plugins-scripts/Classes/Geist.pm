package Classes::Geist;
our @ISA = qw(Classes::Device);
use strict;

