package Classes::Rittal;
our @ISA = qw(Classes::Device);
use strict;


