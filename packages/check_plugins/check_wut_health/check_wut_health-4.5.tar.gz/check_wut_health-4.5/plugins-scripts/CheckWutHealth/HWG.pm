package CheckWutHealth::HWG;
our @ISA = qw(CheckWutHealth::Device);
use strict;

1;
