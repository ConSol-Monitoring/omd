package CheckWutHealth::HWG::Poseidon;
our @ISA = qw(CheckWutHealth::Device);
use strict;

sub init {
  my $self = shift;
  if ($self->mode =~ /device::hardware::health/) {
    $self->analyze_and_check_environmental_subsystem("CheckWutHealth::HWG::Poseidon::Component::AlarmSubsystem");
  } elsif ($self->mode =~ /device::sensor::status/) {
    $self->analyze_and_check_sensor_subsystem("CheckWutHealth::HWG::Poseidon::Component::SensorSubsystem");
  } else {
    $self->no_such_mode();
  }
}

1;
