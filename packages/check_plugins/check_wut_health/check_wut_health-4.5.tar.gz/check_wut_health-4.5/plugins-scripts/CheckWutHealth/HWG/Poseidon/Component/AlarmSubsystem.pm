package CheckWutHealth::HWG::Poseidon::Component::AlarmSubsystem;
our @ISA = qw(Monitoring::GLPlugin::SNMP::Item);
use strict;

sub init {
  my $self = shift;
  if (! $self->opts->lookback) {
    $self->override_opt('lookback', 3600);
  }
  $self->get_snmp_tables("POSEIDON-MIB", [
      ["alarms", "tsAlarmTable", "CheckWutHealth::HWG::Poseidon::Component::AlarmSubsystem::Alarm"],
  ]);
  $self->{tsAlarmsPresent} = $self->get_snmp_object("POSEIDON-MIB", "tsAlarmsPresent");
}

sub check {
  my $self = shift;
  my $count = defined $self->{tsAlarmsPresent} ? $self->{tsAlarmsPresent} : 0;
  if ($count > 0) {
    $self->add_info(sprintf "%d alarm(s)", $count);
  } else {
    $self->add_ok("no alarms");
  }
}

package CheckWutHealth::HWG::Poseidon::Component::AlarmSubsystem::Alarm;
our @ISA = qw(Monitoring::GLPlugin::SNMP::TableItem);
use strict;

sub check {
  my $self = shift;
  my $ago = $self->ago_sysuptime($self->{tsAlarmTime});
  if ($ago <= $self->opts->lookback) {
    $self->add_info(sprintf "%s on %s (%ds ago)",
        $self->{tsAlarmDescr}, $self->{tsAlarmSensName}, $ago);
    $self->add_critical(sprintf "%s on %s (%ds ago)",
        $self->{tsAlarmDescr}, $self->{tsAlarmSensName}, $ago);
  } else {
    $self->add_info(sprintf "%s on %s (%ds ago, older than %ds)",
        $self->{tsAlarmDescr}, $self->{tsAlarmSensName}, $ago,
        $self->opts->lookback);
    $self->add_ok(sprintf "%s on %s (%ds ago, older than %ds)",
        $self->{tsAlarmDescr}, $self->{tsAlarmSensName}, $ago,
        $self->opts->lookback);
  }
}

1;
