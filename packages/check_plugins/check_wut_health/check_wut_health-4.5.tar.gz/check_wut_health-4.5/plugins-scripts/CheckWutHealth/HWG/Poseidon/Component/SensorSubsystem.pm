package CheckWutHealth::HWG::Poseidon::Component::SensorSubsystem;
our @ISA = qw(Monitoring::GLPlugin::SNMP::Item);
use strict;

sub init {
  my $self = shift;
  $self->get_snmp_tables("POSEIDON-MIB", [
      ["sensors", "sensTable", "CheckWutHealth::HWG::Poseidon::Component::SensorSubsystem::Sensor", sub {
          my $o = shift; return $self->filter_name($o->{sensName});
      }],
      ["inputs", "inpTable", "CheckWutHealth::HWG::Poseidon::Component::SensorSubsystem::Input", sub {
          my $o = shift; return $self->filter_name($o->{inpName});
      }],
      ["outputs", "outTable", "CheckWutHealth::HWG::Poseidon::Component::SensorSubsystem::Output", sub {
          my $o = shift; return $self->filter_name($o->{outName});
      }],
  ]);
}

package CheckWutHealth::HWG::Poseidon::Component::SensorSubsystem::Sensor;
our @ISA = qw(Monitoring::GLPlugin::SNMP::TableItem);
use strict;

sub finish {
  my $self = shift;
  $self->{label} = lc($self->{sensName});
  $self->{label} =~ s/[^a-z0-9_]/_/g;
  $self->{sensValue} = $self->{sensValue} / 10;
}

sub check {
  my $self = shift;
  $self->add_info(sprintf "%s has state %s (%s)",
      $self->{sensName}, $self->{sensState}, $self->{sensString});
  if ($self->{sensState} eq "invalid") {
    $self->add_unknown();
  } elsif ($self->{sensState} eq "alarm" || $self->{sensState} eq "alarmstate") {
    $self->add_critical();
  } else {
    $self->add_ok();
  }
  if ($self->{sensUnit} eq "celsius") {
    $self->add_perfdata(
        label => $self->{label},
        value => $self->{sensValue},
    );
  } elsif ($self->{sensUnit} eq "percent") {
    $self->add_perfdata(
        label => $self->{label},
        value => $self->{sensValue},
        uom => "%",
    );
  }
}

package CheckWutHealth::HWG::Poseidon::Component::SensorSubsystem::Input;
our @ISA = qw(Monitoring::GLPlugin::SNMP::TableItem);
use strict;

sub check {
  my $self = shift;
  $self->add_info(sprintf "%s has state %s",
      $self->{inpName}, $self->{inpAlarmState});
  if ($self->{inpAlarmState} eq "alarm") {
    $self->add_critical();
  } else {
    $self->add_ok();
  }
}

package CheckWutHealth::HWG::Poseidon::Component::SensorSubsystem::Output;
our @ISA = qw(Monitoring::GLPlugin::SNMP::TableItem);
use strict;

sub check {
  my $self = shift;
  $self->add_info(sprintf "%s is %s",
      $self->{outName}, $self->{outValue});
  $self->add_ok();
}

1;
