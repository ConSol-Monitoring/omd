package Classes::Raritan;
our @ISA = qw(Classes::Device);


