package CheckWutHealth::Raritan;
our @ISA = qw(CheckWutHealth::Device);


