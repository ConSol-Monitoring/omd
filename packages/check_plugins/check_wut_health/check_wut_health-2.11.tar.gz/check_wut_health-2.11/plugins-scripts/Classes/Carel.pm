package Classes::Carel;
our @ISA = qw(Classes::Device);
use strict;
