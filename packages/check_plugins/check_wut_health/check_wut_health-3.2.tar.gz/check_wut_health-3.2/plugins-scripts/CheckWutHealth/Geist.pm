package CheckWutHealth::Geist;
our @ISA = qw(CheckWutHealth::Device);
use strict;

