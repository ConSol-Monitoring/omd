package CheckPrinterHealth::HOSTRESOURCESMIB;
our @ISA = qw(CheckPrinterHealth::Device);
use strict;

