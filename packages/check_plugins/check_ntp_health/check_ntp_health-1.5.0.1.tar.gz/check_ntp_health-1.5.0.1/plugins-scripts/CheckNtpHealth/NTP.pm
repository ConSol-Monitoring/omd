package CheckNtpHealth::NTP;
our @ISA = qw(CheckNtpHealth::GenericDaemonWithPeers);
use strict;

