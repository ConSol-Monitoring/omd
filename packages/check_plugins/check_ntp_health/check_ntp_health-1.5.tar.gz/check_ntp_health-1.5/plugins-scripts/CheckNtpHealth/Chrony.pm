package CheckNtpHealth::Chrony;
our @ISA = qw(CheckNtpHealth::GenericDaemonWithPeers);
use strict;

