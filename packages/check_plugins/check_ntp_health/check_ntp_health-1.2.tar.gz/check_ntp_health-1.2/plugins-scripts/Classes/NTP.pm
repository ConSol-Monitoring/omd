package Classes::NTP;
our @ISA = qw(Classes::GenericDaemonWithPeers);
use strict;

