package Classes::GenericDaemonWithPeers;
our @ISA = qw(Classes::Device);
use strict;

