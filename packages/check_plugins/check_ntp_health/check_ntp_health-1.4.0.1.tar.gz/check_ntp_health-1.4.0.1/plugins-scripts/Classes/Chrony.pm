package Classes::Chrony;
our @ISA = qw(Classes::GenericDaemonWithPeers);
use strict;

