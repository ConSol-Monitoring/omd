module github.com/consol-monitoring/check_snclient

go 1.26

require github.com/stretchr/testify v1.12.1

require go.yaml.in/yaml/v3 v3.0.5 // indirect
