# About check_snclient

**check_snclient** collects check results from NSClient++/SNClient agents using
its REST API. It is an alternative to check_nrpe et al. check_snclient can be
used with any monitoring tool, that can use Naemon/Nagios compatible plugins.

To be easily portable, check_snclient is written in Go.

check_snclient is released under the GNU GPL v3.

## check_nsc_web

This project was previously named `check_nsc_web` but stays 100% compatible.

## Building the binaries

### With docker

```bash
make docker
```

or to select a specific makefile target

```bash
make docker target=citest
```

## Usage examples

### Alive check

```bash
./check_snclient/main.go.go -k -p "password from snclient.ini" -u "https://<SERVER_RUNNING_SNCLIENT>:8443"
OK: SNClient API reachable on https://localhost:8443
```

### CPU usage

```bash
check_snclient -k -p "password from snclient.ini" -u "https://<SERVER_RUNNING_SNCLIENT>:8443" check_cpu
OK: CPU load is ok.|'total 5m'=16%;80;90 'total 1m'=8%;80;90 'total 5s'=8%;80;90
```

### CPU usage with thresholds

```bash
check_snclient -k -p "password from snclient.ini" -u "https://<SERVER_RUNNING_SNCLIENT>:8443" check_cpu show-all "warning=load > 75" "critical=load > 90"
OK: 5m: 1%, 1m: 0%, 5s: 0%|'total 5m'=1%;75;90 'total 1m'=0%;75;90 'total 5s'=0%;75;90
```

### Service status

```bash
check_snclient -k -p "password from snclient.ini" -u "https://<SERVER_RUNNING_SNCLIENT>:8443" check_service "service=BvSshServer"
OK: All 1 service(s) are ok.|'BvSshServer'=4;0;0
```

### Complex eventlog check

```bash
check_snclient -k -p "password from snclient.ini" -u "https://<SERVER_RUNNING_SNCLIENT>:8443" check_eventlog "file=system" "filter=id=8000" "crit=count>0" "detail-syntax=\${message}" show-all "scan-range=-900m"
OK: No entries found|'count'=0;0;0 'problem_count'=0;0;0
```

### Reading parameters and queries from file

```bash
check_snclient -config ./sample.conf
OK: 5m: 0%, 1m: 0%, 5s: 0% |'total 5m'=0%;80;90;; 'total 1m'=0%;80;90;; 'total 5s'=0%;80;90;;
```

Contents of ```sample.conf```:

```bash
u https://127.0.0.1:28443
p password
k true
query check_cpu show-all
```

Please note, that everything after query will be **appended** to existing query arguments.

## Program help

```txt
Usage:
  check_snclient [options] [query parameters]

Description:
  check_snclient is a REST client for the NSClient++/SNClient webserver for querying
  and receiving check information over HTTP(S).

Example:
  connectivity check (parent service):
  check_snclient -p "password" -u "https://<SERVER>:8443"

  check without arguments:
  check_snclient -p "password" -u "https://<SERVER>:8443" check_cpu

  check with arguments:
  check_snclient -p "password" -u "https://<SERVER>:8443" check_drivesize disk=c

Options:
  -u <url>                 SNClient/NSCLient++ URL, for example https://10.1.2.3:8443
  -t <seconds>[:<STATE>]   Connection timeout in seconds. Default: 10sec
                           Optional set timeout state: 0-3 or OK, WARNING, CRITICAL, UNKNOWN
                           (default timeout state is UNKNOWN)
  -e <STATE>               exit code for connection errors. Default is UNKNOWN.
  -a <api version>         API version of SNClient/NSClient++ (legacy or 1) Default: legacy
  -l <username>            REST webserver login. Default: admin
  -p <password>            REST webserver password
  -config <file>           Path to config file

TLS/SSL Options:
  -C <pem file>            Use client certificate (pem) to connect. Must provide -K as well
  -K <key file>            Use client certificate key file to connect
  -ca <pem file>           Use certificate ca to verify server certificate
  -tlsmax <string>         Maximum tls version used to connect
  -tlsmin <string>         Minimum tls version used to connect. Default: tls1.0
  -tlshostname <string>    Use this servername when verifying tls server name
  -k                       Insecure mode - skip TLS verification

Output Options:
  -h                       Print help
  -v                       Enable verbose output
  -vv                      Enable very verbose output (and log directly to stdout)
  -V                       Print program version
  -f <integer>             Round performance data float values to this number of digits. Default: -1
  -j                       Print out JSON response body
  -r                       Print raw result without pre/post processing
  -query <string>          Placeholder for query string from config file
```
