package Classes::APS::DBI;
our @ISA = qw(Classes::APS Classes::Sybase::DBI);
use strict;
