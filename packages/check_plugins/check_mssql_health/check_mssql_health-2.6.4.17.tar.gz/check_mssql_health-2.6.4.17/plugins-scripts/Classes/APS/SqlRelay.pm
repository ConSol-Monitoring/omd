package Classes::APS::Sqlrelay;
our @ISA = qw(Classes::APS Classes::Sybase::Sqlrelay);
use strict;
