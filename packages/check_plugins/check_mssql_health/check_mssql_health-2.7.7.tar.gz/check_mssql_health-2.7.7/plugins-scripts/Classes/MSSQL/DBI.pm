package Classes::MSSQL::DBI;
our @ISA = qw(Classes::MSSQL Classes::Sybase::DBI);
use strict;
