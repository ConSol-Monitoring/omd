package Classes::ASE::DBI;
our @ISA = qw(Classes::ASE Classes::Sybase::DBI);
use strict;
