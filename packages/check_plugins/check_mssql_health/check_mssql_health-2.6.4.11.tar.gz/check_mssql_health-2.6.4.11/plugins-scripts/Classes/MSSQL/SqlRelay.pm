package Classes::MSSQL::Sqlrelay;
our @ISA = qw(Classes::MSSQL Classes::Sybase::Sqlrelay);
use strict;
