package Classes::POLYCOMACCESSMANAGEMENTMIB;
our @ISA = qw(Classes::Device);
use strict;

