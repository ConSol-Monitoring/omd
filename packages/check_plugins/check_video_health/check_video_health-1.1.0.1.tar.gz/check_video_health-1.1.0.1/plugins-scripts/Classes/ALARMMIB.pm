package Classes::ALARMMIB;
our @ISA = qw(Classes::Device);
use strict;

