package Classes::Polycom;
our @ISA = qw(Classes::Device);
use strict;

