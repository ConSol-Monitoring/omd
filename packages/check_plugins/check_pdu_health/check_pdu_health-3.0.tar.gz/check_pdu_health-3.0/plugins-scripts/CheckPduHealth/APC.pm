package CheckPduHealth::APC;
our @ISA = qw(CheckPduHealth::Device);
use strict;
