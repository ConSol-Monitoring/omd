package CheckPduHealth::HWG;
our @ISA = qw(CheckPduHealth::Device);
use strict;

