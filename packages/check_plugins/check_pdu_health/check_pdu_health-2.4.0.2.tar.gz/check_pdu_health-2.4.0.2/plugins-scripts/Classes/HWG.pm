package Classes::HWG;
our @ISA = qw(Classes::Device);
use strict;

