package CheckPduHealth::Vertiv::V5::Components::LeakRopeSubsystem;
our @ISA = qw(Monitoring::GLPlugin::SNMP::Item);
use strict;

# Leak-rope ("SN-L") detectors on the Vertiv IMD5 (rPDU): one row per attached
# rope in the snlSensorTable (OID branch .1.3.6.1.4.1.21239.5.2.15, "imd 15").
# The verdict is driven by the human status strings snlSensorLeakDisplayState /
# snlSensorFaultDisplayState (case-insensitive, trimmed; only 'OK' is healthy);
# the raw integer snlSensorLeakState / snlSensorFaultState (already decoded to
# the vendor enum names by make_symbolic) is the fallback when a row lacks the
# status string. One message per rope at the max severity; a non-OK
# leak-detection state is CRITICAL (maintainer requirement: add_critical).

sub init {
  my $self = shift;
  $self->get_snmp_tables('VERTIV-V5-MIB', [
    ['leakropes', 'snlSensorTable', 'CheckPduHealth::Vertiv::V5::Components::LeakRopeSubsystem::LeakRope'],
  ]);
}


package CheckPduHealth::Vertiv::V5::Components::LeakRopeSubsystem::LeakRope;
our @ISA = qw(Monitoring::GLPlugin::SNMP::TableItem);
use strict;

sub finish {
  my ($self) = @_;
  # row identity: the serial; fall back to the row index if the device does
  # not report a serial
  my $serial = $self->{snlSensorSerial};
  $serial = '' unless defined $serial;
  $serial =~ s/^\s+|\s+$//g;
  $self->{serial} = ($serial ne '') ? $serial : ($self->{snlSensorIndex} // '');
  return $self;
}

# the state to report for one of the two statuses: the human string if the
# device provided one, else the decoded raw integer (make_symbolic has already
# mapped it through the MIB definition: e.g. 1 -> 'Wet', 2 -> 'OK',
# other -> 'unknown_<raw>'); '' if the row carries neither
sub _state {
  my ($self, $display, $raw) = @_;
  my $v = defined $display ? $display : (defined $raw ? $raw : '');
  $v =~ s/^\s+|\s+$//g;
  return $v;
}

sub check {
  my ($self) = @_;
  my $avail = $self->{snlSensorAvail};
  return unless (defined $avail && $avail == 1);
  # "Device availability: 0 = Unavailable, 1 = Available,
  # 2 = Partially Unavailable" -- unavailable rows are skipped entirely,
  # like the a2dSensorAvail != 1 convention in EnvironmentalSubsystem

  my $leakstate  = _state($self, $self->{snlSensorLeakDisplayState}, $self->{snlSensorLeakState});
  my $faultstate = _state($self, $self->{snlSensorFaultDisplayState}, $self->{snlSensorFaultState});
  # a row that carries neither a status string nor a decodable integer is an
  # undecodable state: never OK, never a silent pass
  $leakstate  = 'unknown' if $leakstate  eq '';
  $faultstate = 'unknown' if $faultstate eq '';

  my $label = $self->{snlSensorLabel};
  $label = '' unless defined $label;
  $label =~ s/^\s+|\s+$//g;

  # one info line per rope, both states reported verbatim
  $self->add_info(sprintf 'leak rope %s (%s): leak detection is %s, fault status is %s',
      $self->{serial},
      $label,
      $leakstate,
      $faultstate
  );

  # verdict per state, ranked for the single per-rope message (framework
  # precedence: CRITICAL > WARNING > UNKNOWN > OK):
  #   leak detection: non-OK string -> CRITICAL (add_critical, maintainer
  #                   requirement); unknown_* / undecodable -> UNKNOWN
  #   fault status:   non-OK string -> WARNING; unknown_* / undecodable -> UNKNOWN
  # a rope that is both leaked and faulted records only the CRITICAL message
  # (max severity wins, one message per rope)
  my $leak_rank  = (lc($leakstate)  eq 'ok') ? 1 : ($leakstate  =~ /^unknown/) ? 2 : 4;
  my $fault_rank = (lc($faultstate) eq 'ok') ? 1 : ($faultstate =~ /^unknown/) ? 2 : 3;
  my $row_rank   = ($leak_rank > $fault_rank) ? $leak_rank : $fault_rank;
  if ($row_rank == 4) {
    $self->add_critical();
  } elsif ($row_rank == 3) {
    $self->add_warning();
  } elsif ($row_rank == 2) {
    $self->add_unknown();
  } else {
    $self->add_ok();
  }

  # one state metric per rope: 0 = dry, 1 = fault only, 2 = wet,
  # 3 = undecodable state; value only -- no thresholds, no min/max
  my $metric = 'leakrope_'.$self->{serial};
  my $value  = 0;
  if ($row_rank == 2) {
    $value = 3;
  } elsif (lc($leakstate) ne 'ok') {
    $value = 2;
  } elsif (lc($faultstate) ne 'ok') {
    $value = 1;
  }
  $self->add_perfdata(
      label => $metric,
      value => $value,
  );
}


1;
