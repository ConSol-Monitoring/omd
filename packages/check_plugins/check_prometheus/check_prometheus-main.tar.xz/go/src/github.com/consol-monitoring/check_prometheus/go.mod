module github.com/consol-monitoring/check_prometheus

go 1.26.0

require (
	github.com/consol-monitoring/check_x v0.0.0-20260709081430-c4562508a464
	github.com/prometheus/client_golang v1.25.0
	github.com/prometheus/common v0.72.0
	github.com/urfave/cli/v3 v3.14.0
)

require (
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/prometheus/client_model v0.6.3 // indirect
	google.golang.org/protobuf v1.36.12 // indirect
)
