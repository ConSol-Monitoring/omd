# 0.0.8 - 09.10.2026
- update dependencies

# 0.0.7 - 10.06.2026
- Write check results to standard output.

# 0.0.6 - 08.05.2026
- Apply request timeouts consistently across check modes.
- Execute Go templates supplied through the query alias option.
- Restore target labels in targets health results.

# 0.0.5 - 09.01.2026
- Expose the checker as a reusable Go package.

# 0.0.4 - 18.12.2025
- Add base64 and URL-encoded query options.
- Add verbose output for Prometheus request headers and body.
- Correct critical threshold handling for queries.

# 0.0.2 - 09.01.2020
- change to ConSol repos
- update modul check_x
- Issue #2 Warning Thershold Value is used as Critical Value: also for query

# 0.0.1 - 27.09.2016
- Ping mode
- Query mode
- Targets_Health mode
