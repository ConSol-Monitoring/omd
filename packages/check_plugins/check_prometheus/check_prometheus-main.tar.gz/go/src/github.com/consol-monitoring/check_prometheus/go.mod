module github.com/consol-monitoring/check_prometheus

go 1.25.7

require (
	github.com/consol-monitoring/check_x v0.0.0-20260108170459-f7c19720a9ad
	github.com/prometheus/client_golang v1.23.2
	github.com/prometheus/common v0.67.5
	github.com/urfave/cli/v3 v3.6.2
)

require (
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/prometheus/client_model v0.6.2 // indirect
	go.yaml.in/yaml/v2 v2.4.3 // indirect
	google.golang.org/protobuf v1.36.11 // indirect
)
