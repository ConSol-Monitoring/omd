# 0.0.1 - 27.09.2016
## Features:
- Ping mode
- Query mode
- Targets_Health mode