# 0.0.2 - 09.01.2020
## Changes:
- change to ConSol repos
- update modul check_x


# 0.0.1 - 27.09.2016
## Features:
- Ping mode
- Query mode
- Targets_Health mode
