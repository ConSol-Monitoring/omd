---
name: Question
about: 'Questions should be handled in the mailing list: lokiproject@googlegroups.com'
title: ''
labels: ''
assignees: ''

---

Please ask questions you have in the mailing list: https://groups.google.com/forum/#!forum/lokiproject

Or join our #loki slack channel at http://slack.raintank.io/
