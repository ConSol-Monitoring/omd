# Loki Simple Scaleable Deployment Example


## Usage
1) Setup Tanka see the [Tanka Installation Docs](../../../../docs/sources/installation/tanka.md).
2) Next, you'll need to install Jsonnet library for SSD.
```bash
jb install github.com/grafana/loki/production/ksonnet/loki-simple-scalable@main
```
3) Configure main.jsonnet and `tk apply` :tada: