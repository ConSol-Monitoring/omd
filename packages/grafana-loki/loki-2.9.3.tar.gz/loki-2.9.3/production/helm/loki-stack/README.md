# ⚠️  DEPRECATED - Loki-Stack Helm Chart

This chart was moved to <https://github.com/grafana/helm-charts>.

The source code for this chart was removed from this repoistory after commit [11caa49](https://github.com/grafana/loki/commit/11caa492210c201bd0b0272d9187151be647d3e0).
