# Loki Maintainers Guide

This section details information for maintainers of Loki.

1. [Releasing Loki](./release.md)
2. [Releasing `loki-build-image`](./release-loki-build-image.md)
