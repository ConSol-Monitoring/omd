# Best Practices

1. [Current Best Practices](current-best-practices.md) includes a (hopefully) current guide for some best practices regarding Label usage and configuration in Loki.
