# Installing Loki

1. [Installing using Tanka (recommended)](./tanka.md)
2. [Installing through Helm](./helm.md)
3. [Installing locally](./local.md)
