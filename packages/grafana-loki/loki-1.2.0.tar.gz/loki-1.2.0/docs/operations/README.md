# Operating Loki

1. [Authentication](authentication.md)
2. [Observability](observability.md)
3. [Scalability](scalability.md)
4. [Storage](storage/README.md)
    1. [Table Manager](storage/table-manager.md)
    2. [Retention](storage/retention.md)
5. [Multi-tenancy](multi-tenancy.md)
6. [Loki Canary](loki-canary.md)
