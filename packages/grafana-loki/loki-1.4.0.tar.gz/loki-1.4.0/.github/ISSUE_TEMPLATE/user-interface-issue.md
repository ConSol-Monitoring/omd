---
name: User Interface issue
about: 'Open UI issues here: https://github.com/grafana/grafana/issues/new'
title: ''
labels: ''
assignees: ''

---

Issues with querying and displaying logs inside Grafana should be opened in the Grafana repo:

https://github.com/grafana/grafana/issues/new
