# Operating Loki

1. [Upgrading](upgrade.md)
2. [Authentication](authentication.md)
3. [Observability](observability.md)
4. [Scalability](scalability.md)
5. [Storage](storage/README.md)
    1. [Table Manager](storage/table-manager.md)
    2. [Retention](storage/retention.md)
6. [Multi-tenancy](multi-tenancy.md)
7. [Loki Canary](loki-canary.md)
