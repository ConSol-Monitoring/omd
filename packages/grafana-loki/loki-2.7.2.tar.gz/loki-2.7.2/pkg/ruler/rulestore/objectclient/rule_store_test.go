package objectclient

// This is an empty placeholder test file to signal that the tests for RuleStore are in:
// pkg/ruler/rulestore/bucketclient/bucket_client_test.go
