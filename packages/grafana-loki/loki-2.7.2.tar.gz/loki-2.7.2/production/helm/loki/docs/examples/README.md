## Introduction
The Helm Charts found under the examples directory are getting started examples which you can use to deploy Loki using the Simple Scalable architecture quickly. Currently, the examples include:
- [Deploying Grafana Enterprise Logs (Loki in Enterprise mode)](https://github.com/grafana/helm-charts/tree/main/charts/loki-simple-scalable/docs/examples/enterprise)
- [Deploying Loki OSS](https://github.com/grafana/helm-charts/tree/main/charts/loki-simple-scalable/docs/examples/oss)
