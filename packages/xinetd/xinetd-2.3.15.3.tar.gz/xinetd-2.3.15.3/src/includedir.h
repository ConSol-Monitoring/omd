#ifndef INCLUDEDIR_H
#define INCLUDEDIR_H

#include "conf.h"

void handle_includedir(const char *service_name,struct configuration *confp);

#endif
