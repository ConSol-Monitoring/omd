<?php
abstract class WuiModule extends CoreModule {
}
?>