<?php
class WuiModLogonDialog extends FrontendModLogonDialog {}
?>
