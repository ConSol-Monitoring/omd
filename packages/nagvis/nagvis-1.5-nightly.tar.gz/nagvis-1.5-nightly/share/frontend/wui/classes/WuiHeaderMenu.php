<?php
class WuiHeaderMenu extends NagVisHeaderMenu {
}
?>
