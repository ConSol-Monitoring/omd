<?php
class WuiModLogonMixed extends FrontendModLogonMixed {}
?>
