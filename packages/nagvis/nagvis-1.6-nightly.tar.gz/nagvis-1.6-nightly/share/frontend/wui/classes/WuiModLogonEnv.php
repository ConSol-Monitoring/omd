<?php
class WuiModLogonEnv extends FrontendModLogonEnv {}
?>
