:mod:`objectid` -- MOVED
========================

.. module:: pymongo.objectid

This module has been deprecated in favor of
:mod:`bson.objectid`. Please use that module instead.

.. versionchanged:: 1.9
   Deprecated.
