:mod:`timestamp` -- MOVED
=========================

.. module:: pymongo.timestamp

This module has been deprecated in favor of
:mod:`bson.timestamp`. Please use that module instead.

.. versionchanged:: 1.9
   Deprecated.
