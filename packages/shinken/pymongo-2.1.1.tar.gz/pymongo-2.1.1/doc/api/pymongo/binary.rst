:mod:`binary` -- MOVED
======================

.. module:: pymongo.binary

This module has been deprecated in favor of :mod:`bson.binary`. Please
use that module instead.

.. versionchanged:: 1.9
   Deprecated.
