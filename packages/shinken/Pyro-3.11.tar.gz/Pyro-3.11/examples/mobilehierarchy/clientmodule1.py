class BaseClass(object):
	def method(self):
		return "this is the method's result"
