import clientmodule2

class MyClass(clientmodule2.SomeClass):
	pass
