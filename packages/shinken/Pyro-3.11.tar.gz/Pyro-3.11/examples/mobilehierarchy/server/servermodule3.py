import servermodule2

class ResponseClass(servermodule2.SomeClass):
	pass
