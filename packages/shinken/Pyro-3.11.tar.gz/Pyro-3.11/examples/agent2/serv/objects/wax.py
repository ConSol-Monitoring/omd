
class wax(object):
	def __init__(self):
		pass
	def getName(self):
		return "wax"
	def getDescription(self):
		return "canister of quick-ski-wax"
