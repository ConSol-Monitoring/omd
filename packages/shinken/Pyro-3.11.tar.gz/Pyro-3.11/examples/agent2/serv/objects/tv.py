
class tv(object):
	def __init__(self):
		pass
	def getName(self):
		return "TV"
	def getDescription(self):
		return "Full-HD LCD television"
