Testing the passing of code from client to server.
No nameserver is required.
