Testing the passing of code from client to server,
where the mobile code also includes other modules.
No nameserver is required.
Requires PYRO_MOBILE_CODE=1 for both server and client.
