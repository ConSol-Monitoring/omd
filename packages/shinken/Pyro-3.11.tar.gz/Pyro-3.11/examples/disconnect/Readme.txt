This example shows the various ways that you can use to disconnect objects from the daemon.

The usual way is just to disconnect the object itself that you previously connected.
But it is also possible to pass in an object's UID (as a string).

You need to have a Name server running to run this example.

