Pyro - Python Remote Objects

This software is copyright � by Irmen de Jong.

This software is released under the MIT software license.
This license, including disclaimer, is available in the 'LICENSE' file.


Please give me credit if you use this software.

The manual, including installation instructions, is in the docs/ directory.
It's in HTML and the title section is called 'PyroManual.html'.


Irmen de Jong
irmen@razorvine.net

