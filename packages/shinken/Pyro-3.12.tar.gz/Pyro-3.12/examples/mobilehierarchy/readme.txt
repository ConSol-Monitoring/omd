Shows that the mobile code logic can deal with a hierarchy of depending modules.

Client sends an object to the server that requires 3 modules to be sent as mobile code.
Server sends an object in its response that also requires 3 modules to be downloaded.
