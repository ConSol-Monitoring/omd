#!/bin/sh

echo "When in doubt... blow it up. | cpu=100%"
#sleep 1.5
exit 0
