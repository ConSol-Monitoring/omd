#!/bin/sh
echo "Hi, I'm for testing only. Please do not use me directly, really | Hip=99% Bob=34mm"
exit 0
