    def test_thruk_servicegroup(self):
        self.print_header()
        now = time.time()
        self.update_broker()
        #---------------------------------------------------------------
        # get services of a certain servicegroup
        #---------------------------------------------------------------
        data = """GET services
Columns: accept_passive_checks acknowledged action_url action_url_expanded acti
Filter: groups >= servicegroup_01
OutputFormat: json
ResponseHeader: fixed16
"""
        response = self.livestatus_broker.livestatus.handle_request(data)
        print response
        time.sleep(100)

