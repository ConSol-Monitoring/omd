% shinken-receiver(8) Shinken User Manuals
% Arthur Gautier
% September 14, 2011

# NAME

shinken-receiver - Shinken receiver command.

# SYNOPSIS

shinken-receiver  [*options*] ...

# DESCRIPTION

Shinken receiver daemon

# OPTIONS

-c *CONFIGFILE*, \--config *CONFIGFILE*
:   Config file

-d, \--daemon
:   Run in daemon mode.

-h, \--help
:   Print detailed help screen.

\--debug *FILE*
:   Debug File.


