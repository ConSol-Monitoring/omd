% shinken-scheduler(8) Shinken User Manuals
% Arthur Gautier
% September 14, 2011

# NAME

shinken-scheduler - Shinken scheduler command.

# SYNOPSIS

shinken-scheduler [*options*] ...

# DESCRIPTION

Shinken scheduler daemon.

# OPTIONS

-c *CONFIGFILE*, \--config *CONFIGFILE*
:   Config file

-d, \--daemon
:   Run in daemon mode.

-r, \--replace
:   Replace previous running scheduler.

-h, \--help
:   Print detailed help screen.

\--debug *FILE*
:   Debug File.


