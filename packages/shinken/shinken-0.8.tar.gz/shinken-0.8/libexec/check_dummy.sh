#!/bin/sh

echo "Return in Dummy" $1

exit $1