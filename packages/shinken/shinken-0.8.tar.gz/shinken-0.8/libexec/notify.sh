#!/bin/bash

echo "" >> ~/notify.log
echo `date` >> ~/notify.log
echo $* >> ~/notify.log

