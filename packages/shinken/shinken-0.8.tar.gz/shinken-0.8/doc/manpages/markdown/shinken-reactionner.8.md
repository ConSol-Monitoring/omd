% shinken-reactionner(8) Shinken User Manuals
% Arthur Gautier
% September 14, 2011


# NAME

shinken-reactionner - Shinken reactionner command.

# SYNOPSIS

shinken-reactionner [*options*] ...

# DESCRIPTION

Shinken reactionner Daemon.

# OPTIONS

-c *CONFIGFILE*, \--config *CONFIGFILE*
:   Config file

-d, \--daemon
:   Run in daemon mode.

-r, \--replace
:   Replace previous running arbiter.

-h, \--help
:   Print detailed help screen.

\--debug *FILE*
:   Debug File.


