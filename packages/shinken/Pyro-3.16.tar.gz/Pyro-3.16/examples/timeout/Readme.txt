This is an example that shows the socket timeout handling.

timeout.py   -- example with _setTimeout()
timeout2.py  -- example without any timeout settings
