This shows a possible way to transfer files.
It implements a very rudimentary server and file browser/download client.
