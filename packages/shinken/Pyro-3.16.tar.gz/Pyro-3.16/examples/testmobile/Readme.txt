Various examples to test the different types of mobile code support.
