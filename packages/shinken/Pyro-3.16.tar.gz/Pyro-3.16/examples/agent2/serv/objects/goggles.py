
class goggles(object):
	def __init__(self):
		pass
	def getName(self):
		return "goggles"
	def getDescription(self):
		return "Yellow Oakley ski-goggles"
