
class computer(object):
	def __init__(self):
		pass
	def getName(self):
		return "Computer"
	def getDescription(self):
		return "Alienware game system"
