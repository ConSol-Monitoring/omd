
class shoes(object):
	def __init__(self):
		pass
	def getName(self):
		return "Shoes"
	def getDescription(self):
		return "Pair of brown casual shoes"
