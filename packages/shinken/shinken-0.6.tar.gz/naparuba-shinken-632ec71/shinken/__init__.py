

# shinken.objects must be imported first:
import objects
