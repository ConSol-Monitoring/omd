#!/bin/sh

echo $*
exit 0
