:mod:`Pyro4.futures` --- asynchronous calls
===========================================

.. automodule:: Pyro4.futures
    :members: Future, FutureResult
