Contributors
============

NSCA was originally written in 2000 by Ethan Galstad.
A full list of authors, contributors, and maintainers is as follows:

 * Ethan Galstad (Original Author, Nagios)
 * Bryan Heden (Nagios)
 * John Frickson (Nagios)
 * Eric Stanley (Nagios)
 * Mike Lindsey
 * Falk Hoeppner
 * Sebastian Wolf (Nagios)
 * mvela
 * Xavier Bachelot
 * mib
 * Daniel Wittenberg
 * Ryan Ordway
 * Brian Seklecki
 * Holger Weiss
 * Ton Voon
 * Chris Wilson
 * Altinity
 * Sean Finney
 * Mark Ferlatte
 * David Binderman
 * Scott Cokely
 * Ralf Ertzinger
 * David Luyer
 * Jay McCarthy
