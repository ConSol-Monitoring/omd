<?php
/**
 * English language strings for the Formular Plugin
 *
 * @author  Stephane Chamberland <stephane.chamberland@gmail.com>
 */
 
$lang['AllowInclude'] = 'Allow Inclusion of PHP-Script?';
$lang['mailPath'] = 'Mail-Scripts Location rel-Path (from DOKU_BASE)';
$lang['selectPage'] = 'wiki-page where SelectBox names are defined. ';
$lang['mailSubject'] = 'Email Subject';
$lang['mailFrom'] = 'Email Sender [Mandatory on Windows]';
$lang['DebugMode'] = 'Activate Debug-Output to file debug.txt?';

//Setup VIM: ex: et ts=2 enc=utf-8 :