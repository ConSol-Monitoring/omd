<?php
/**
 * Italian language strings for the Formular Plugin
 *
 * @author  Stephane Chamberland <stephane.chamberland@gmail.com>
 * @author  Diego Pierotto <ita.translations@tiscali.it>
 */
 
$lang['AllowInclude'] = 'Permettere inclusione di script PHP?';
$lang['mailPath'] = 'Posizione percorso relativo script di posta (da DOKU_BASE)';
$lang['selectPage'] = 'Pagina wiki dove i nomi campi di selezione sono definiti. ';
$lang['mailSubject'] = 'Oggetto email';
$lang['mailFrom'] = 'Mittente email [Obbligatorio per Windows]';
$lang['DebugMode'] = 'Attivare salvataggio Debug nel file debug.txt?';

//Setup VIM: ex: et ts=2 enc=utf-8 :
