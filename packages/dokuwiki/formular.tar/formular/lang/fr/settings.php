<?php
/**
 * English language strings for the Formular Plugin
 *
 * @author  Stephane Chamberland <stephane.chamberland@gmail.com>
 */
 
$lang['AllowInclude'] = "Allouer l'inclusion de scripts PHP?";
$lang['mailPath'] = "Path (relatif a DOKU_BASE) du script d'envoie de courriel";
$lang['selectPage'] = 'Page wiki ou sont definis le nom de SelectBox. ';
$lang['mailSubject'] = 'Subject du Courriel';
$lang['mailFrom'] = "Courriel de l'expediteur [Obligatoire sur Windows]";
$lang['DebugMode'] = 'Activate Debug-Output to file debug.txt?';

//Setup VIM: ex: et ts=2 enc=utf-8 :