<?php
/**
 * German language strings for the Formular Plugin
 *
 * @author  Ole Rienow<dokuwiki@rienow.eu>
 */
 
$lang['AllowInclude'] = 'Soll es moeglich sein PHP-Sripte einzubinden?';
$lang['mailPath'] = 'Relativer Speicherort der Mail-Skripte (ausgehend von DOKU_BASE)';
$lang['selectPage'] = 'Name der Wiki-Seite wo die Namen der SelectBox definiert sind.';
$lang['mailSubject'] = 'Betreff der Email';
$lang['mailFrom'] = 'Email Sender [notwendig unter Windows]';
$lang['DebugMode'] = 'Debug-Modus aktivieren? (Ausgabe in Datei debug.txt)';

//Setup VIM: ex: et ts=2 enc=utf-8 :