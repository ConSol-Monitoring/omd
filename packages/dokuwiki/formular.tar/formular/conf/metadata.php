<?php
/**
 * Metadata for configuration manager plugin
 * Additions for the Formular Plugin
 *
 * @author    Stephane Chamberland <stephane.chamberland@gmail.com>
 */

$meta['AllowInclude'] = array('onoff');
$meta['DebugMode'] = array('onoff');
$meta['mailPath'] = array('string');
$meta['selectPage'] = array('string');
$meta['mailSubject'] = array('string');
$meta['mailFrom'] = array('string');

//Setup VIM: ex: et ts=2 enc=utf-8 :
