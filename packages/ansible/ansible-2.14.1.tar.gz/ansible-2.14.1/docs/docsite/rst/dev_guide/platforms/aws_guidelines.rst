.. _AWS_module_development:

****************************************************
Guidelines for Ansible Amazon AWS module development
****************************************************

This guide has moved to :ref:`ansible_collections.amazon.aws.docsite.dev_guide_intro`.
