.. _VMware_module_development:

******************************************************
Guidelines for VMware module development
******************************************************

This guide has moved to :ref:`ansible_collections.community.vmware.docsite.vmware_ansible_devguide`.
