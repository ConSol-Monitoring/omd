.. _VMware_REST_module_development:

*********************************************
Guidelines for VMware REST module development
*********************************************

This guide has moved to :ref:`ansible_collections.vmware.vmware_rest.docsite.vmware_rest_devguide`.
