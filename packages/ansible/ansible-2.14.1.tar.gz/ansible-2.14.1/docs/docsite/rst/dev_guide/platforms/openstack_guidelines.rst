.. _OpenStack_module_development:

OpenStack Ansible Modules
=========================

Please see the `OpenStack guidelines <https://opendev.org/openstack/ansible-collections-openstack/src/branch/master/docs/openstack_guidelines.rst>`_,  for further information.
