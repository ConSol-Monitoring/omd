from ansible.module_utils.six.moves import input
user_input = input('foo')
print(user_input)
