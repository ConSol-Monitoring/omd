Gentoo ebuilds are available in the main tree:

emerge ansible
