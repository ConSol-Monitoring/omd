# Test script to remove a file.

Remove-Item $args[0] -Force
