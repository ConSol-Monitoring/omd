Param(
[bool]$boolvariable
)

Write-Output $boolvariable.GetType().FullName
Write-Output $boolvariable
