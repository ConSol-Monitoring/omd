# Test script to create a file.

echo $null > $args[0]
