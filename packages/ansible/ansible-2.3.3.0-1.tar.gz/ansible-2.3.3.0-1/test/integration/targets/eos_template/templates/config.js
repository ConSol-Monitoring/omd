interface Ethernet2
   description test description from ansible
   shutdown

