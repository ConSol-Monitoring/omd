aclocal
autoconf
autoheader
automake --add-missing
