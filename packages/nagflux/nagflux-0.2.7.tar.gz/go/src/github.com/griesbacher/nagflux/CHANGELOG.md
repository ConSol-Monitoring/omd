## v0.2.7 - 16.11.2016
### Fix
- Livestatus index out of bound error
- Less Livestatus log entries on an error(downtime)

## v0.2.6 - 26.10.2016
### Feature
- Version is shown within the help message
- check_multi prefixes will be expanded if not done by the core

## v0.2.5 - 22.09.2016
### Fix
- Deadlock when InfluxDB is not running, again !?

## v0.2.4 - 20.09.2016
### Fix
- Deadlock when InfluxDB is not running
- Pass connection args when checking for database
- Missing logfile fix

### Feature
- use of vendor-folder
- Prometheus api

### Breaks
- When using go1.5 the envvar GO15VENDOREXPERIMENT should be set to 1 

## v0.2.3 - 08.09.2016
### Fix
- ignore selfsigned ssl certs
- livestatus detection improved
- wait for influxdb on start
- pause fileparsing when influxdb is not reachable
- skip non digit perfdata(U are ignored)


## v0.2.2 - 17.05.2016
### Fix
- livestatus ServiceNotifications with just 9 entries
- nagflux fileimport exception when column name is too short
- nagios livestatus query for performance issues

## v0.2.1.1 - 08.04.2016
### Features
- mod_gearman key will be cut if it's too long

## v0.2.1 - 30.03.2016
### Features
- mod_gearman support (experimental)

### Breaks
- New Nagflux import format

## v0.2.0 - 10.03.2016

### Features
- Elasticsearch support
- New Importformat

### Fixes
-  Version Bug

### Breaks
- The old InfluxDB layout is not valid anymore. To convert the old data use the Pythonscript in CONVERTER.

## v0.1.0 - 01.12.2015

### Features
- Everything :wink:
