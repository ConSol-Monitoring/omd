## v0.2.0 - upcomming
- Elasticsearch support

### Breaks
- The old InfluxDB layout is not valid anymore. To convert the old data use the Pythonscript in CONVERTER.

## v0.1.0 - 01.12.2015

### Features
- Everything :wink:
