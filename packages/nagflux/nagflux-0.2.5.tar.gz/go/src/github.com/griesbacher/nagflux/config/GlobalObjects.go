package config

import "sync/atomic"

var PauseNagflux atomic.Value

