package nagflux

import (
	"flag"
	"fmt"
	"os"
	"os/signal"
	"runtime"
	"slices"
	"syscall"
	"time"

	"github.com/ConSol-Monitoring/nagflux/pkg/collector"
	"github.com/ConSol-Monitoring/nagflux/pkg/collector/livestatus"
	"github.com/ConSol-Monitoring/nagflux/pkg/collector/modgearman"
	"github.com/ConSol-Monitoring/nagflux/pkg/collector/nagflux"
	"github.com/ConSol-Monitoring/nagflux/pkg/collector/spoolfile"
	"github.com/ConSol-Monitoring/nagflux/pkg/config"
	"github.com/ConSol-Monitoring/nagflux/pkg/data"
	"github.com/ConSol-Monitoring/nagflux/pkg/helper"
	"github.com/ConSol-Monitoring/nagflux/pkg/logging"
	"github.com/ConSol-Monitoring/nagflux/pkg/statistics"
	"github.com/ConSol-Monitoring/nagflux/pkg/target/elasticsearch"
	"github.com/ConSol-Monitoring/nagflux/pkg/target/file/jsontarget"
	"github.com/ConSol-Monitoring/nagflux/pkg/target/influx"
	"github.com/kdar/factorlog"
)

// Stoppable represents every daemonlike struct which can be stopped
type Stoppable interface {
	Stop()
}

// nagfluxVersion contains the current Github-Release
const nagfluxVersion string = "v0.5.9"

var (
	log  *factorlog.FactorLog
	quit = make(chan bool)
)

//nolint:funlen,maintidx
func Nagflux(Build string) {
	// Parse Args
	var configPath string
	var printver bool
	flag.Usage = func() {
		fmt.Printf(`Nagflux version %s (Build: %s, %s)
Commandline Parameter:
-configPath Path to the config file. If no file path is given the default is ./config.gcfg.
-V Print version and exit

Original author: Philip Griesbacher
For further informations / bugs reports: https://github.com/ConSol-Monitoring/nagflux
`, nagfluxVersion, Build, runtime.Version())
	}
	flag.StringVar(&configPath, "configPath", "config.gcfg", "path to the config file")
	flag.BoolVar(&printver, "V", false, "print version and exit")
	flag.Parse()

	// Print version and exit
	if printver {
		fmt.Printf("%s (Build: %s, %s)\n", nagfluxVersion, Build, runtime.Version())
		os.Exit(0)
	}

	// Load config
	if _, err := os.Stat(configPath); os.IsNotExist(err) {
		fmt.Printf("Can not find config file: '%s'.\n\nHelp:\n", configPath)
		flag.Usage()
		os.Exit(1)
	}
	config.InitConfig(configPath)
	cfg := config.GetConfig()

	// Create Logger
	logging.InitLogger(cfg.Log.LogFile, cfg.Log.MinSeverity)
	log = logging.GetLogger()
	log.Info(`Started Nagflux `, nagfluxVersion)
	log.Debugf("Using Config: %s", configPath)
	resultQueues := collector.ResultQueues{}
	stoppables := []Stoppable{}
	if len(cfg.Main.FieldSeparator) < 1 {
		panic("FieldSeparator is too short!")
	}
	pro := statistics.NewPrometheusServer(cfg.Monitoring.PrometheusAddress)
	pro.WatchResultQueueLength(resultQueues)
	fieldSeparator := []rune(cfg.Main.FieldSeparator)[0]

	for name, value := range cfg.InfluxDB {
		if value == nil || !(*value).Enabled {
			continue
		}
		influxConfig := (*value)
		target := data.Target{Name: name, Datatype: data.InfluxDB}
		config.StoreValue(target, false)
		resultQueues[target] = make(chan collector.Printable, cfg.Main.BufferSize)
		influx := influx.ConnectorFactory(
			resultQueues[target],
			influxConfig.Address, influxConfig.Arguments, cfg.Main.DumpFile, influxConfig.Version,
			cfg.Main.InfluxWorker, cfg.Main.MaxInfluxWorker, cfg.InfluxDBGlobal.CreateDatabaseIfNotExists,
			influxConfig.StopPullingDataIfDown, target, cfg.InfluxDBGlobal.ClientTimeout, influxConfig.HealthURL, influxConfig.AuthToken,
		)
		if influx.IsAlive() {
			stoppables = append(stoppables, influx)
		} else {
			log.Criticalf("Nagflux is disabled for InfluxDB(%s)", target.Name)
		}
		influxDumpFileCollector := nagflux.NewDumpfileCollector(resultQueues[target], cfg.Main.DumpFile, target, cfg.Main.FileBufferSize)
		waitForDumpfileCollector(influxDumpFileCollector)
		stoppables = append(stoppables, influxDumpFileCollector)
	}

	for name, value := range cfg.Elasticsearch {
		if value == nil || !(*value).Enabled {
			continue
		}
		elasticConfig := (*value)
		target := data.Target{Name: name, Datatype: data.Elasticsearch}
		resultQueues[target] = make(chan collector.Printable, cfg.Main.BufferSize)
		config.StoreValue(target, false)
		elasticsearch := elasticsearch.ConnectorFactory(
			resultQueues[target],
			elasticConfig.Address, elasticConfig.Index, cfg.Main.DumpFile, elasticConfig.Version,
			cfg.Main.InfluxWorker, cfg.Main.MaxInfluxWorker, true,
		)
		stoppables = append(stoppables, elasticsearch)
		elasticDumpFileCollector := nagflux.NewDumpfileCollector(resultQueues[target], cfg.Main.DumpFile, target, cfg.Main.FileBufferSize)
		waitForDumpfileCollector(elasticDumpFileCollector)
		stoppables = append(stoppables, elasticDumpFileCollector)
	}

	for name, value := range cfg.JSONFileExport {
		if value == nil || !(*value).Enabled {
			continue
		}
		jsonFileConfig := (*value)
		target := data.Target{Name: name, Datatype: data.JSONFile}
		resultQueues[target] = make(chan collector.Printable, cfg.Main.BufferSize)
		templateFile := jsontarget.NewJSONFileWorker(
			log, jsonFileConfig.AutomaticFileRotation,
			resultQueues[target], target, jsonFileConfig.Path,
		)
		stoppables = append(stoppables, templateFile)
	}

	// Some time for the dumpfile to fill the queue
	time.Sleep(time.Duration(100) * time.Millisecond)

	var livestatusConnector *livestatus.Connector
	var livestatusCollector *livestatus.Collector
	var livestatusCache *livestatus.CacheBuilder

	// livestatus spoolfile collection is enabled by default
	livestatusEnabled := true
	if search, found := helper.GetPreferredConfigValue(cfg, "Livestatus.Enabled", []string{}); found {
		ptr, ok := search.(*bool)
		if ok {
			livestatusEnabled = *ptr
		} else {
			log.Warnf("Expected a *bool value out of the config value for Livestatus Enablement")
		}
	}
	if livestatusEnabled {
		livestatusConnector = &livestatus.Connector{Log: log, LivestatusAddress: cfg.Livestatus.Address, ConnectionType: cfg.Livestatus.Type}
		livestatusCollector = livestatus.NewLivestatusCollector(resultQueues, livestatusConnector, cfg.Livestatus.Version)
		livestatusCache = livestatus.NewLivestatusCacheBuilder(livestatusConnector)
	}

	for name, data := range cfg.ModGearman {
		if data == nil {
			continue
		}
		if !data.Enabled {
			log.Debugf("Worker for Mod-Gearman: %s - %s %s will not be started, it is disabled", name, data.Address, data.Queue)
			continue
		}
		if livestatusCache == nil {
			log.Debugf("%s - %s %s will start with a nil livestatusCache, will not process downtime data in perf", name, data.Address, data.Queue)
		}
		log.Infof("Mod_Gearman: %s - %s [%s]", name, data.Address, data.Queue)
		secret := modgearman.GetSecret(data.Secret, data.SecretFile)
		for range data.Worker {
			gearmanWorker, wErr := modgearman.NewGearmanWorker(
				data.Address,
				data.Queue,
				secret,
				resultQueues,
				livestatusCache,
			)
			log.Criticalf("Error when setting up GearmanWorker: %s", wErr.Error())
			stoppables = append(stoppables, gearmanWorker)
		}
	}

	var nagiosCollector *spoolfile.NagiosSpoolfileCollector
	var err error
	// nagios spoolfile collection is enabled by default
	nagiosSpoolFileCollectorEnabled := true
	if search, found := helper.GetPreferredConfigValue(cfg, "NagiosSpoolfile.Enabled", []string{}); found {
		ptr, ok := search.(*bool)
		if ok {
			nagiosSpoolFileCollectorEnabled = *ptr
		} else {
			log.Warnf("Expected a *bool value out of the config value for Nagios Spoolfile Collection Enablement")
		}
	}

	if nagiosSpoolFileCollectorEnabled {
		nagiosCollector, err = spoolfile.NagiosSpoolfileCollectorFactory(
			cfg,
			resultQueues,
			livestatusCache,
			cfg.Main.FileBufferSize,
			collector.Filterable{Filter: cfg.Main.DefaultTarget},
		)
		if err != nil {
			log.Criticalf("Error when setting up NagiosSpoolfileCollectorFactory: %s", err.Error())
			<-quit
		}
	}

	// nagflux spoolfile collection is enabled by default
	var nagfluxCollector *nagflux.FileCollector
	nagfluxCollectorEnabled := true
	if val, found := helper.GetPreferredConfigValue(cfg, "NagfluxSpoolfile.Enabled", []string{}); found {
		ptr, ok := val.(*bool)
		if ok {
			nagfluxCollectorEnabled = *ptr
		} else {
			log.Warnf("Expected a *bool value out of the config value for Nagflux Spoolfile Enablement")
		}
	}
	if nagfluxCollectorEnabled {
		nagfluxCollectorFolderString := ""
		nagfluxCollectorFolderSearch, found := helper.GetPreferredConfigValue(cfg, "NagfluxSpoolfile.Folder", []string{"Main.NagfluxSpoolfileFolder"})
		if !found {
			log.Criticalf("Could not find a config value for Nagflux Spoolfile Folder")
			<-quit
		}
		nagfluxCollectionFolderPtr, ok := nagfluxCollectorFolderSearch.(*string)
		if ok {
			nagfluxCollectorFolderString = *nagfluxCollectionFolderPtr
		} else {
			log.Warnf("Expected a *string value out of the config value for Nagflux Spoolfile Folder")
		}

		if found {
			log.Info("Nagflux Spoolfile Folder: ", nagfluxCollectorFolderString)
			nagfluxCollector = nagflux.NewNagfluxFileCollector(resultQueues, nagfluxCollectorFolderString, fieldSeparator)
		}
	}

	checkActiveModuleCount(stoppables)

	// Listen for Interrupts
	signalChannel := make(chan os.Signal, 1)
	signal.Notify(signalChannel, syscall.SIGINT)
	signal.Notify(signalChannel, syscall.SIGTERM)
	signal.Notify(signalChannel, syscall.SIGUSR1)
	go func() {
		for {
			switch <-signalChannel {
			case syscall.SIGINT, syscall.SIGTERM:
				log.Warn("Got Interrupted")
				if livestatusCollector != nil {
					stoppables = append(stoppables, livestatusCollector)
				}
				if livestatusCache != nil {
					stoppables = append(stoppables, livestatusCache)
				}
				if nagiosCollector != nil {
					stoppables = append(stoppables, nagiosCollector)
				}
				if nagfluxCollector != nil {
					stoppables = append(stoppables, nagfluxCollector)
				}
				cleanUp(stoppables, resultQueues)
				quit <- true
				return
			case syscall.SIGUSR1:
				buf := make([]byte, 1<<16)
				n := runtime.Stack(buf, true)
				if n < len(buf) {
					buf = buf[:n]
				}
				log.Warnf("Got USR1 signal, logging thread dump:\n%s", buf)
			}
		}
	}()

	// wait for quit
	<-quit
}

func waitForDumpfileCollector(dump *nagflux.DumpfileCollector) {
	if dump != nil {
		for i := 0; i < 30 && dump.IsRunning; i++ {
			time.Sleep(time.Duration(2) * time.Second)
		}
	}
}

// Wait till the Performance Data is sent.
func cleanUp(itemsToStop []Stoppable, resultQueues collector.ResultQueues) {
	log.Info("Cleaning up...")
	for i := range slices.Backward(itemsToStop) {
		itemsToStop[i].Stop()
	}
	for _, q := range resultQueues {
		log.Debugf("Remaining queries %d", len(q))
	}
}

// Depending on the configuration, we might not have added any active watchers.
// Exit the program if that is the case
func checkActiveModuleCount(stoppables []Stoppable) {
	activeItemCount := len(stoppables)
	if activeItemCount == 0 {
		log.Fatalf("No active watcher/spooler/listener were constructed after processing the config file, enable at least an item.")
	}
}
