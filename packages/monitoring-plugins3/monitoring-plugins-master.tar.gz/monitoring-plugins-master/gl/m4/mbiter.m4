# mbiter.m4
# serial 7
dnl Copyright (C) 2005, 2008-2026 Free Software Foundation, Inc.
dnl This file is free software; the Free Software Foundation
dnl gives unlimited permission to copy and/or distribute it,
dnl with or without modifications, as long as this notice is preserved.
dnl This file is offered as-is, without any warranty.

dnl autoconf tests required for use of mbiter.h
dnl From Bruno Haible.

AC_DEFUN([gl_MBITER],
[
  AC_REQUIRE([AC_TYPE_MBSTATE_T])
  :
])
