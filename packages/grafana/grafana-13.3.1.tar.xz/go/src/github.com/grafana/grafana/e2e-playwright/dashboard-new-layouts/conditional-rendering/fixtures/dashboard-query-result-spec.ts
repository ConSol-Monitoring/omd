import { type Spec as DashboardV2Spec } from '../../../../packages/grafana-schema/src/schema/dashboard/v2';

export function buildDashboardQueryResultSpec(grafanaVersion: string): DashboardV2Spec {
  return {
    annotations: [
      {
        kind: 'AnnotationQuery',
        spec: {
          builtIn: true,
          enable: true,
          hide: true,
          iconColor: 'rgba(0, 211, 255, 1)',
          name: 'Annotations & Alerts',
          query: {
            datasource: {
              name: '-- Grafana --',
            },
            group: 'grafana',
            kind: 'DataQuery',
            spec: {},
            version: 'v0',
          },
        },
      },
    ],
    cursorSync: 'Off',
    editable: true,
    elements: {
      'panel-1': {
        kind: 'Panel',
        spec: {
          data: {
            kind: 'QueryGroup',
            spec: {
              queries: [
                {
                  kind: 'PanelQuery',
                  spec: {
                    hidden: false,
                    query: {
                      datasource: {
                        name: 'PD8C576611E62080A',
                      },
                      group: 'grafana-testdata-datasource',
                      kind: 'DataQuery',
                      spec: {
                        scenarioId: 'random_walk',
                      },
                      version: 'v0',
                    },
                    refId: 'A',
                  },
                },
              ],
              queryOptions: {},
              transformations: [],
            },
          },
          description: '',
          id: 1,
          links: [],
          title: 'Panel 1',
          vizConfig: {
            group: 'timeseries',
            kind: 'VizConfig',
            spec: {
              fieldConfig: {
                defaults: {
                  color: {
                    mode: 'palette-classic',
                  },
                  custom: {
                    axisBorderShow: false,
                    axisCenteredZero: false,
                    axisColorMode: 'text',
                    axisLabel: '',
                    axisPlacement: 'auto',
                    barAlignment: 0,
                    barWidthFactor: 0.6,
                    drawStyle: 'line',
                    fillOpacity: 0,
                    gradientMode: 'none',
                    hideFrom: {
                      legend: false,
                      tooltip: false,
                      viz: false,
                    },
                    insertNulls: false,
                    lineInterpolation: 'linear',
                    lineWidth: 1,
                    pointSize: 5,
                    scaleDistribution: {
                      type: 'linear',
                    },
                    showPoints: 'auto',
                    showValues: false,
                    spanNulls: false,
                    stacking: {
                      group: 'A',
                      mode: 'none',
                    },
                    thresholdsStyle: {
                      mode: 'off',
                    },
                  },
                  thresholds: {
                    mode: 'absolute',
                    steps: [
                      {
                        color: 'green',
                        value: 0,
                      },
                      {
                        color: 'red',
                        value: 80,
                      },
                    ],
                  },
                },
                overrides: [],
              },
              options: {
                legend: {
                  calcs: [],
                  displayMode: 'list',
                  placement: 'bottom',
                  showLegend: true,
                },
                tooltip: {
                  hideZeros: false,
                  mode: 'single',
                  sort: 'none',
                },
              },
            },
            version: grafanaVersion,
          },
        },
      },
    },
    layout: {
      kind: 'AutoGridLayout',
      spec: {
        columnWidthMode: 'standard',
        items: [
          {
            kind: 'AutoGridLayoutItem',
            spec: {
              element: {
                kind: 'ElementReference',
                name: 'panel-1',
              },
            },
          },
        ],
        maxColumnCount: 3,
        rowHeightMode: 'standard',
      },
    },
    links: [],
    liveNow: false,
    preferences: {
      layout: {
        kind: 'AutoGridLayout',
        spec: {
          columnWidthMode: 'standard',
          items: [],
          maxColumnCount: 3,
          rowHeightMode: 'standard',
        },
      },
    },
    preload: false,
    tags: [],
    timeSettings: {
      autoRefresh: '',
      autoRefreshIntervals: ['5s', '10s', '30s', '1m', '5m', '15m', '30m', '1h', '2h', '1d'],
      fiscalYearStartMonth: 0,
      from: 'now-5m',
      hideTimepicker: false,
      timezone: 'browser',
      to: 'now',
    },
    title: 'New dashboard',
    variables: [],
  };
}
