module github.com/grafana/grafana

go 1.27.3

// Replace references to internal workspaces
replace (
	github.com/grafana/grafana/apps/advisor => ./apps/advisor
	github.com/grafana/grafana/apps/alerting/alertenrichment => ./apps/alerting/alertenrichment
	github.com/grafana/grafana/apps/alerting/alertrulequality => ./apps/alerting/alertrulequality
	github.com/grafana/grafana/apps/alerting/notifications => ./apps/alerting/notifications
	github.com/grafana/grafana/apps/alerting/rules => ./apps/alerting/rules
	github.com/grafana/grafana/apps/annotation => ./apps/annotation
	github.com/grafana/grafana/apps/collections => ./apps/collections
	github.com/grafana/grafana/apps/correlations => ./apps/correlations
	github.com/grafana/grafana/apps/dashboard => ./apps/dashboard
	github.com/grafana/grafana/apps/dashvalidator => ./apps/dashvalidator
	github.com/grafana/grafana/apps/example => ./apps/example
	github.com/grafana/grafana/apps/folder => ./apps/folder
	github.com/grafana/grafana/apps/iam => ./apps/iam
	github.com/grafana/grafana/apps/live => ./apps/live
	github.com/grafana/grafana/apps/logsdrilldown => ./apps/logsdrilldown
	github.com/grafana/grafana/apps/playlist => ./apps/playlist
	github.com/grafana/grafana/apps/plugins => ./apps/plugins
	github.com/grafana/grafana/apps/preferences => ./apps/preferences
	github.com/grafana/grafana/apps/provisioning => ./apps/provisioning
	github.com/grafana/grafana/apps/quotas => ./apps/quotas
	github.com/grafana/grafana/apps/scope => ./apps/scope
	github.com/grafana/grafana/apps/secret => ./apps/secret
	github.com/grafana/grafana/apps/shorturl => ./apps/shorturl

	// Packages
	github.com/grafana/grafana/pkg/apimachinery => ./pkg/apimachinery
	github.com/grafana/grafana/pkg/apiserver => ./pkg/apiserver
	github.com/grafana/grafana/pkg/infra/features => ./pkg/infra/features
	github.com/grafana/grafana/pkg/infra/log => ./pkg/infra/log
	github.com/grafana/grafana/pkg/infra/metrics => ./pkg/infra/metrics
	github.com/grafana/grafana/pkg/infra/tracing => ./pkg/infra/tracing
	github.com/grafana/grafana/pkg/plugins => ./pkg/plugins
	github.com/grafana/grafana/pkg/storage/unified/apistore => ./pkg/storage/unified/apistore
	github.com/grafana/grafana/pkg/storage/unified/resource/kv => ./pkg/storage/unified/resource/kv
	github.com/grafana/grafana/pkg/storage/unified/resourceclient => ./pkg/storage/unified/resourceclient
	github.com/grafana/grafana/pkg/storage/unified/resourcepb => ./pkg/storage/unified/resourcepb
	github.com/grafana/grafana/pkg/util/sqlite => ./pkg/util/sqlite
)

// Direct requirements -- every entry needs an owner
require (
	cloud.google.com/go/aiplatform v1.126.0 // @grafana/grafana-search-and-storage
	cloud.google.com/go/discoveryengine v1.33.0 // @grafana/grafana-search-and-storage
	cloud.google.com/go/kms v1.32.0 // @grafana/grafana-backend-group
	cloud.google.com/go/storage v1.67.1 // @grafana/grafana-backend-group
	dario.cat/mergo v1.0.2 // @grafana/grafana-app-platform-squad
	filippo.io/age v1.3.2 // @grafana/identity-access-team
	github.com/Azure/azure-sdk-for-go v68.0.0+incompatible // @grafana/data-sources-plugins
	github.com/Azure/azure-sdk-for-go/sdk/azcore v1.23.1 // @grafana/identity-access-team
	github.com/Azure/azure-sdk-for-go/sdk/azidentity v1.14.1 // @grafana/grafana-backend-group
	github.com/Azure/azure-sdk-for-go/sdk/keyvault/azkeys v0.10.0 // @grafana/grafana-backend-group
	github.com/Azure/azure-sdk-for-go/sdk/storage/azblob v1.8.0 // @grafana/grafana-backend-group
	github.com/Azure/go-autorest/autorest v0.11.30 // @grafana/grafana-backend-group
	github.com/Azure/go-autorest/autorest/adal v0.9.24 // @grafana/grafana-backend-group
	github.com/BurntSushi/toml v1.6.0 // @grafana/identity-access-team
	github.com/DATA-DOG/go-sqlmock v1.5.2 // @grafana/grafana-search-and-storage
	github.com/Masterminds/semver v1.5.0 // @grafana/grafana-backend-group
	github.com/Masterminds/semver/v3 v3.5.0 // @grafana/grafana-backend-services-squad
	github.com/Masterminds/sprig/v3 v3.3.0 // @grafana/grafana-backend-group
	github.com/PaesslerAG/jsonpath v0.1.1 // @grafana/grafana-search-and-storage
	github.com/VividCortex/mysqlerr v1.0.0 // @grafana/grafana-backend-group
	github.com/andybalholm/brotli v1.2.7 // @grafana/data-sources-plugins
	github.com/apache/arrow-go/v18 v18.8.0 // @grafana/grafana-catalog
	github.com/armon/go-radix v1.0.0 // @grafana/grafana-app-platform-squad
	github.com/aws/aws-sdk-go-v2 v1.46.0 // @grafana/data-sources-plugins
	github.com/aws/aws-sdk-go-v2/config v1.33.3 // @grafana/grafana-search-and-storage
	github.com/aws/aws-sdk-go-v2/credentials v1.20.3 // @grafana/grafana-operator-experience-squad
	github.com/aws/aws-sdk-go-v2/feature/ec2/imds v1.19.2 // @grafana/grafana-operator-experience-squad
	github.com/aws/aws-sdk-go-v2/feature/s3/manager v1.20.12 // @grafana/alerting-backend
	github.com/aws/aws-sdk-go-v2/service/bedrockruntime v1.50.5 // @grafana/grafana-search-and-storage
	github.com/aws/aws-sdk-go-v2/service/kms v1.50.3 // @grafana/grafana-operator-experience-squad
	github.com/aws/aws-sdk-go-v2/service/licensemanager v1.37.14 // @grafana/grafana-operator-experience-squad
	github.com/aws/aws-sdk-go-v2/service/s3 v1.102.2 // @grafana/grafana-search-and-storage
	github.com/aws/aws-sdk-go-v2/service/secretsmanager v1.41.4 // @grafana/grafana-operator-experience-squad
	github.com/aws/aws-sdk-go-v2/service/sts v1.49.0 // @grafana/grafana-operator-experience-squad
	github.com/aws/smithy-go v1.28.1 // @grafana/data-sources-plugins
	github.com/beevik/etree v1.8.0 // @grafana/grafana-backend-group
	github.com/benbjohnson/clock v1.3.5 // @grafana/alerting-backend
	github.com/blevesearch/bleve/v2 v2.5.7 // @grafana/grafana-search-and-storage
	github.com/blevesearch/bleve_index_api v1.3.11 // @grafana/grafana-search-and-storage
	github.com/blevesearch/zapx/v16 v16.3.4 // @grafana/grafana-search-and-storage
	github.com/bradfitz/gomemcache v0.0.0-20260422231931-4d751bb6e37c // @grafana/grafana-backend-group
	github.com/bwmarrin/snowflake v0.3.0 // @grafana/grafana-app-platform-squad
	github.com/cenkalti/backoff/v4 v4.3.0 // @grafana/alerting-backend
	github.com/centrifugal/centrifuge v0.39.0 // @grafana/grafana-app-platform-squad
	github.com/cespare/xxhash/v2 v2.3.0 // @grafana/identity-access-team
	github.com/charmbracelet/bubbles v1.0.0 // @grafana/grafana-app-platform-squad
	github.com/charmbracelet/bubbletea v1.3.10 // @grafana/grafana-app-platform-squad
	github.com/charmbracelet/lipgloss v1.1.0 // @grafana/grafana-app-platform-squad
	github.com/chromedp/cdproto v0.0.0-20260922220944-a19bff23514f // @grafana/data-sources
	github.com/dgraph-io/badger/v4 v4.9.6 // @grafana/grafana-search-and-storage
	github.com/dlmiddlecote/sqlstats v1.0.2 // @grafana/grafana-backend-group
	github.com/dolthub/go-mysql-server v0.19.1-0.20250410182021-5632d67cd46e // @grafana/grafana-datasources-core-services
	github.com/dolthub/vitess v0.0.0-20260225173707-20566e4abe9e // @grafana/grafana-datasources-core-services
	github.com/emicklei/go-restful/v3 v3.14.0 // @grafana/grafana-app-platform-squad
	github.com/fatih/color v1.19.0 // @grafana/grafana-backend-group
	github.com/fsnotify/fsnotify v1.10.1 // @grafana/identity-access-team
	github.com/fullstorydev/grpchan v1.1.2 // @grafana/grafana-backend-group
	github.com/gchaincl/sqlhooks v1.3.0 // @grafana/grafana-search-and-storage
	github.com/getkin/kin-openapi v0.151.0 // @grafana/grafana-app-platform-squad
	github.com/go-jose/go-jose/v4 v4.1.6 // @grafana/identity-access-team
	github.com/go-ldap/ldap/v3 v3.4.4 // @grafana/identity-access-team
	github.com/go-logr/logr v1.4.4 // @grafana/grafana-app-platform-squad
	github.com/go-openapi/runtime v0.33.3 // @grafana/alerting-backend
	github.com/go-openapi/strfmt v0.27.3 // @grafana/alerting-backend
	github.com/go-sourcemap/sourcemap v2.1.4+incompatible // @grafana/grafana-backend-group
	github.com/go-sql-driver/mysql v1.10.0 // @grafana/grafana-search-and-storage
	github.com/gobwas/glob v0.2.3 // @grafana/grafana-backend-group
	github.com/gogo/protobuf v1.3.2 // @grafana/alerting-backend
	github.com/golang-jwt/jwt/v4 v4.5.2 // @grafana/grafana-backend-group
	github.com/golang/mock v1.7.0-rc.1 // @grafana/alerting-backend
	github.com/golang/protobuf v1.5.4 // @grafana/grafana-backend-group
	github.com/golang/snappy v1.0.0 // @grafana/alerting-backend
	github.com/google/go-cmp v0.7.0 // @grafana/grafana-backend-group
	github.com/google/go-github/v82 v82.0.0 // @grafana/grafana-git-ui-sync-team
	github.com/google/safetext v0.0.0-20260330151545-1fb717a317c5 // @grafana/grafana-app-platform-squad
	github.com/google/wire v0.7.0 // @grafana/grafana-backend-group
	github.com/googleapis/gax-go/v2 v2.24.1 // @grafana/grafana-backend-group
	github.com/gorilla/mux v1.8.1 // @grafana/grafana-backend-group
	github.com/grafana/alerting v0.0.0-20261014191024-71374176ca7b // @grafana/alerting-backend
	github.com/grafana/alerting/apps/historian v0.0.0-20260729133334-340f1168af6c // @grafana/alerting-backend
	github.com/grafana/authlib v0.0.0-20261023105149-ed7cea0f2b27 // @grafana/identity-access-team
	github.com/grafana/authlib/types v0.0.0-20261020151310-7a9be4c0c1c3 // @grafana/identity-access-team
	github.com/grafana/dataplane/sdata v0.0.9 // @grafana/observability-metrics
	github.com/grafana/dskit v0.0.0-20260907092321-7585a53bb600 // @grafana/grafana-backend-group
	github.com/grafana/e2e v0.1.2-0.20260309174126-b5393d4e610f // @grafana/grafana-app-platform-squad
	github.com/grafana/gofpdf v0.0.0-20250307124105-3b9c5d35577f // @grafana/sharing-squad
	github.com/grafana/gomemcache v0.0.0-20260728143316-9448343bd654 // @grafana/grafana-operator-experience-squad
	github.com/grafana/grafana-api-golang-client v0.27.0 // @grafana/alerting-backend
	github.com/grafana/grafana-app-sdk v0.61.0 // @grafana/grafana-app-platform-squad
	github.com/grafana/grafana-app-sdk/logging v0.61.0 // @grafana/grafana-app-platform-squad
	github.com/grafana/grafana-aws-sdk v1.5.5 // @grafana/data-sources-plugins
	github.com/grafana/grafana-azure-sdk-go/v2 v2.4.1 // @grafana/data-sources-plugins
	github.com/grafana/grafana-cloud-migration-snapshot v1.11.0 // @grafana/grafana-operator-experience-squad
	github.com/grafana/grafana-google-sdk-go v0.4.2 // @grafana/data-sources-plugins
	github.com/grafana/grafana-openapi-client-go v0.0.0-20231213163343-bd475d63fb79 // @grafana/grafana-backend-group
	github.com/grafana/grafana-plugin-sdk-go v0.297.0 // @grafana/grafana-catalog
	github.com/grafana/grafana/apps/advisor v0.0.0 // @grafana/grafana-catalog
	github.com/grafana/grafana/apps/alerting/alertenrichment v0.0.0 // @grafana/alerting-backend
	github.com/grafana/grafana/apps/alerting/alertrulequality v0.0.0 // @grafana/alerting-backend
	github.com/grafana/grafana/apps/alerting/notifications v0.0.0 // @grafana/alerting-backend
	github.com/grafana/grafana/apps/alerting/rules v0.0.0 // @grafana/alerting-backend
	github.com/grafana/grafana/apps/annotation v0.0.0 // @grafana/grafana-backend-services-squad
	github.com/grafana/grafana/apps/collections v0.0.0 // @grafana/grafana-app-platform-squad @grafana/grafana-frontend-platform
	github.com/grafana/grafana/apps/correlations v0.0.0 // @grafana/datapro
	github.com/grafana/grafana/apps/dashboard v0.0.0 // @grafana/grafana-app-platform-squad @grafana/dashboards-squad
	github.com/grafana/grafana/apps/dashvalidator v0.0.0 // @grafana/sharing-squad
	github.com/grafana/grafana/apps/example v0.0.0 // @grafana/grafana-app-platform-squad
	github.com/grafana/grafana/apps/folder v0.0.0 // @grafana/grafana-app-platform-squad
	github.com/grafana/grafana/apps/iam v0.0.0 // @grafana/access-squad
	github.com/grafana/grafana/apps/live v0.0.0 // @grafana/grafana-app-platform-squad
	github.com/grafana/grafana/apps/logsdrilldown v0.0.0 // @grafana/observability-logs
	github.com/grafana/grafana/apps/playlist v0.0.0 // @grafana/grafana-app-platform-squad
	github.com/grafana/grafana/apps/plugins v0.0.0 // @grafana/grafana-catalog
	github.com/grafana/grafana/apps/preferences v0.0.0 // @grafana/grafana-app-platform-squad @grafana/grafana-frontend-platform
	github.com/grafana/grafana/apps/provisioning v0.0.0 // @grafana/grafana-app-platform-squad
	github.com/grafana/grafana/apps/quotas v0.0.0 // @grafana/grafana-search-and-storage
	github.com/grafana/grafana/apps/scope v0.0.0 // @grafana/grafana-operator-experience-squad
	github.com/grafana/grafana/apps/secret v0.0.0 // @grafana/grafana-operator-experience-squad
	github.com/grafana/grafana/apps/shorturl v0.0.0 // @grafana/sharing-squad
	github.com/grafana/grafana/pkg/apimachinery v0.0.0 // @grafana/grafana-app-platform-squad
	github.com/grafana/grafana/pkg/apiserver v0.0.0 // @grafana/grafana-app-platform-squad
	github.com/grafana/grafana/pkg/infra/features v0.0.0 // @grafana/grafana-backend-services-squad
	github.com/grafana/grafana/pkg/infra/log v0.0.0 // @grafana/grafana-backend-services-squad
	github.com/grafana/grafana/pkg/infra/metrics v0.0.0 // @grafana/grafana-backend-services-squad
	github.com/grafana/grafana/pkg/infra/tracing v0.0.0 // @grafana/grafana-backend-services-squad
	github.com/grafana/grafana/pkg/plugins v0.0.0 // @grafana/grafana-catalog
	github.com/grafana/grafana/pkg/storage/unified/apistore v0.0.0 // @grafana/grafana-search-and-storage
	github.com/grafana/grafana/pkg/storage/unified/resource/kv v0.0.0 // @grafana/grafana-search-and-storage
	github.com/grafana/grafana/pkg/storage/unified/resourceclient v0.0.0 // @grafana/grafana-search-and-storage
	github.com/grafana/grafana/pkg/storage/unified/resourcepb v0.0.0 // @grafana/grafana-search-and-storage
	github.com/grafana/grafana/pkg/util/sqlite v0.0.0 // @grafana/grafana-backend-group
	github.com/grafana/nanogit/gittest v1.7.3 // @grafana/grafana-git-ui-sync-team
	github.com/grafana/pyroscope-go/godeltaprof v0.1.12 // @grafana/data-sources-plugins
	github.com/grafana/saml v0.4.15-0.20260916103902-393394c6d16c // @grafana/identity-access-team
	github.com/grafana/schemads v0.2.3 // @grafana/data-sources
	github.com/grafana/tempo v1.5.1-0.20260427112133-525d1bab07e0 // @grafana/data-sources-plugins
	github.com/grpc-ecosystem/go-grpc-middleware v1.4.0 // @grafana/grafana-search-and-storage
	github.com/grpc-ecosystem/go-grpc-middleware/providers/prometheus v1.1.1 // @grafana/grafana-catalog
	github.com/grpc-ecosystem/go-grpc-middleware/v2 v2.3.4 // @grafana/grafana-backend-group
	github.com/grpc-ecosystem/grpc-gateway/v2 v2.32.0 // @grafana/identity-access-team
	github.com/hashicorp/go-hclog v1.6.3 // @grafana/grafana-catalog
	github.com/hashicorp/go-multierror v1.1.1 // @grafana/alerting-squad
	github.com/hashicorp/go-plugin v1.8.0 // @grafana/grafana-catalog
	github.com/hashicorp/go-version v1.9.0 // @grafana/grafana-backend-group
	github.com/hashicorp/golang-lru/v2 v2.0.7 // @grafana/alerting-backend
	github.com/hashicorp/hcl/v2 v2.24.0 // @grafana/alerting-backend
	github.com/jackc/pgx/v5 v5.10.0 // @grafana/grafana-search-and-storage
	github.com/jmespath-community/go-jmespath v1.1.1 // @grafana/identity-access-team
	github.com/jmoiron/sqlx v1.4.0 // @grafana/grafana-backend-group
	github.com/jonboulle/clockwork v0.5.0 // @grafana/identity-access-team
	github.com/json-iterator/go v1.1.12 // @grafana/grafana-backend-group
	github.com/ktrysmt/go-bitbucket v0.10.0 // @grafana/grafana-app-platform-squad
	github.com/lib/pq v1.12.3 // @grafana/grafana-backend-group
	github.com/m3db/prometheus_remote_client_golang v0.4.4 // @grafana/grafana-backend-group
	github.com/madflojo/testcerts v1.5.0 // @grafana/alerting-backend
	github.com/mattermost/xml-roundtrip-validator v0.1.0 // @grafana/identity-access-team
	github.com/matttproud/golang_protobuf_extensions v1.0.4 // @grafana/alerting-backend
	github.com/migueleliasweb/go-github-mock v1.5.0 // @grafana/grafana-git-ui-sync-team
	github.com/mitchellh/mapstructure v1.5.1-0.20231216201459-8508981c8b6c // @grafana/identity-access-team
	github.com/modern-go/reflect2 v1.0.3-0.20250322232337-35a7c28c31ee // @grafana/alerting-backend
	github.com/mostynb/go-grpc-compression v1.2.3 // @grafana/grafana-search-and-storage
	github.com/mwitkow/go-conntrack v0.0.0-20190716064945-2f068394615f // @grafana/grafana-operator-experience-squad
	github.com/nats-io/nats-server/v2 v2.14.6 // @grafana/grafana-search-and-storage
	github.com/nats-io/nats.go v1.53.1 // @grafana/grafana-search-and-storage
	github.com/oklog/ulid/v2 v2.1.2 // @grafana/grafana-search-and-storage
	github.com/open-feature/go-sdk v1.17.2 // @grafana/grafana-backend-services-squad
	github.com/openai/openai-go/v3 v3.16.0 // @grafana/grafana-search-and-storage
	github.com/openfga/api/proto v0.0.0-20260319214821-f153694bfc20 // @grafana/identity-access-team
	github.com/openfga/language/pkg/go v0.3.2-0.20260730144454-83fedf8a4e70 // @grafana/identity-access-team
	github.com/openfga/openfga v1.18.3 // @grafana/identity-access-team
	github.com/patrickmn/go-cache v2.1.0+incompatible // @grafana/alerting-backend
	github.com/pgvector/pgvector-go v0.4.1 // @grafana/grafana-search-and-storage
	github.com/pressly/goose/v3 v3.27.3 // @grafana/identity-access-team
	github.com/prometheus/alertmanager v0.33.0 // @grafana/alerting-backend
	github.com/prometheus/client_golang v1.25.0 // @grafana/alerting-backend
	github.com/prometheus/client_model v0.6.3 // @grafana/grafana-backend-group
	github.com/prometheus/common v0.72.1 // @grafana/alerting-backend
	github.com/prometheus/prometheus v0.313.0 // @grafana/alerting-backend
	github.com/prometheus/sigv4 v0.4.1 // @grafana/alerting-backend
	github.com/puzpuzpuz/xsync/v4 v4.5.0 // @grafana/grafana-backend-group
	github.com/redis/go-redis/extra/redisotel/v9 v9.22.0 // @grafana/grafana-operator-experience-squad
	github.com/redis/go-redis/v9 v9.22.0 // @grafana/alerting-backend
	github.com/robfig/cron/v3 v3.0.1 // @grafana/grafana-backend-group
	github.com/rs/cors v1.11.1 // @grafana/identity-access-team
	github.com/russellhaering/gosaml2 v0.12.1-0.20260805181527-c47eb2cf608a // @grafana/identity-access-team
	github.com/russellhaering/goxmldsig v1.6.1 // @grafana/grafana-backend-group
	github.com/russross/blackfriday/v2 v2.1.0 // @grafana/grafana-app-platform-squad
	github.com/shopspring/decimal v1.4.0 // @grafana/grafana-datasources-core-services
	github.com/sony/gobreaker/v2 v2.4.0 // @grafana/grafana-app-platform-squad
	github.com/spf13/cobra v1.10.2 // @grafana/grafana-app-platform-squad
	github.com/spf13/pflag v1.0.10 // @grafana/grafana-app-platform-squad
	github.com/spyzhov/ajson v0.9.6 // @grafana/grafana-sharing-squad
	github.com/stretchr/testify v1.12.1 // @grafana/grafana-backend-group
	github.com/testcontainers/testcontainers-go v0.44.0 // @grafana/grafana-app-platform-squad
	github.com/thomaspoignant/go-feature-flag v1.42.0 // @grafana/grafana-backend-services-squad
	github.com/ua-parser/uap-go v0.0.0-20251207011819-db9adb27a0b8 // @grafana/grafana-backend-group
	github.com/urfave/cli/v2 v2.27.7 // @grafana/grafana-backend-group
	github.com/wk8/go-ordered-map v1.0.0 // @grafana/grafana-backend-group
	github.com/youmark/pkcs8 v0.0.0-20240726163527-a2c0da244d78 // @grafana/grafana-operator-experience-squad
	github.com/yudai/gojsondiff v1.0.0 // @grafana/grafana-backend-group
	gitlab.com/gitlab-org/api/client-go v1.46.0 // @grafana/grafana-app-platform-squad
	go.etcd.io/bbolt v1.5.0 // @grafana/grafana-search-and-storage
	go.opentelemetry.io/collector/pdata v1.66.0 // @grafana/grafana-backend-group
	go.opentelemetry.io/contrib/instrumentation/google.golang.org/grpc/otelgrpc v0.72.0 // @grafana/grafana-catalog
	go.opentelemetry.io/contrib/instrumentation/net/http/httptrace/otelhttptrace v0.72.0 // @grafana/grafana-operator-experience-squad
	go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp v0.72.0 // @grafana/sharing-squad
	go.opentelemetry.io/otel v1.47.0 // @grafana/grafana-backend-group
	go.opentelemetry.io/otel/trace v1.47.0 // @grafana/grafana-backend-group
	go.uber.org/atomic v1.11.0 // @grafana/alerting-backend
	go.uber.org/mock v0.6.0 // @grafana/grafana-operator-experience-squad
	go.uber.org/zap v1.28.0 // @grafana/identity-access-team
	go.yaml.in/yaml/v3 v3.0.5 // @grafana/alerting-backend
	gocloud.dev v0.46.0 // @grafana/grafana-app-platform-squad
	gocloud.dev/secrets/hashivault v0.45.0 // @grafana/grafana-operator-experience-squad
	golang.org/x/net v0.62.0 // @grafana/data-sources-plugins
	golang.org/x/oauth2 v0.37.0 // @grafana/identity-access-team
	golang.org/x/sync v0.24.0 // @grafana/alerting-backend
	golang.org/x/text v0.43.0 // @grafana/grafana-backend-group
	golang.org/x/time v0.16.0 // @grafana/grafana-backend-group
	gonum.org/v1/gonum v0.17.0 // @grafana/data-sources-plugins
	google.golang.org/api v0.297.0 // @grafana/grafana-backend-group
	google.golang.org/genproto/googleapis/api v0.0.0-20261012220534-4341edf3f941 // @grafana/identity-access-team
	google.golang.org/genproto/googleapis/rpc v0.0.0-20261005182115-fad411399dd8 // @grafana/identity-access-team
	google.golang.org/grpc v1.84.0 // @grafana/grafana-catalog
	google.golang.org/protobuf v1.36.12 // @grafana/grafana-catalog
	gopkg.in/evanphx/json-patch.v4 v4.13.0 // @grafana/identity-access-team
	gopkg.in/ini.v1 v1.67.2 // @grafana/alerting-backend
	gopkg.in/mail.v2 v2.3.1 // @grafana/grafana-backend-group
	gopkg.in/yaml.v2 v2.4.0 // @grafana/identity-access-team
	k8s.io/api v0.37.1 // @grafana/grafana-app-platform-squad
	k8s.io/apiextensions-apiserver v0.37.1 // @grafana/grafana-app-platform-squad
	k8s.io/apimachinery v0.37.1 // @grafana/grafana-app-platform-squad
	k8s.io/apiserver v0.37.1 // @grafana/grafana-app-platform-squad
	k8s.io/client-go v0.37.1 // @grafana/grafana-app-platform-squad
	k8s.io/component-base v0.37.1 // @grafana/grafana-app-platform-squad
	k8s.io/klog/v2 v2.140.0 // @grafana/grafana-app-platform-squad
	k8s.io/kube-aggregator v0.37.0 // @grafana/grafana-app-platform-squad
	k8s.io/kube-openapi v0.0.0-20260821135717-be32def86098 // @grafana/grafana-app-platform-squad
	k8s.io/utils v0.0.0-20260707023825-cf1189d6abe3 // @grafana/data-sources-plugins
	pgregory.net/rapid v1.3.0 // @grafana/grafana-operator-experience-squad
	sigs.k8s.io/structured-merge-diff/v6 v6.4.2 // @grafana/grafana-app-platform-squad
	xorm.io/builder v0.3.13 // @grafana/grafana-backend-group
)

require (
	cel.dev/expr v0.25.3 // indirect
	cloud.google.com/go v0.123.0 // indirect
	cloud.google.com/go/auth v0.23.2 // indirect
	cloud.google.com/go/auth/oauth2adapt v0.2.8 // indirect
	cloud.google.com/go/compute/metadata v0.9.0 // indirect
	cloud.google.com/go/iam v1.12.0 // indirect
	cloud.google.com/go/longrunning v1.2.0 // indirect
	cloud.google.com/go/monitoring v1.30.0 // indirect
	cuelang.org/go v0.17.1 // indirect
	filippo.io/edwards25519 v1.2.0 // indirect
	filippo.io/hpke v0.4.0 // indirect
	github.com/Azure/azure-sdk-for-go/sdk/internal v1.12.0 // indirect
	github.com/Azure/azure-sdk-for-go/sdk/keyvault/internal v0.7.1 // indirect
	github.com/Azure/azure-sdk-for-go/sdk/security/keyvault/azkeys v1.4.0 // indirect
	github.com/Azure/azure-sdk-for-go/sdk/security/keyvault/internal v1.2.0 // indirect
	github.com/Azure/go-ansiterm v0.0.0-20261008234032-65faa4be4f89 // indirect
	github.com/Azure/go-autorest v14.2.0+incompatible // indirect
	github.com/Azure/go-autorest/autorest/date v0.3.0 // indirect
	github.com/Azure/go-autorest/autorest/to v0.4.1 // indirect
	github.com/Azure/go-autorest/autorest/validation v0.3.1 // indirect
	github.com/Azure/go-autorest/logger v0.2.1 // indirect
	github.com/Azure/go-autorest/tracing v0.6.0 // indirect
	github.com/Azure/go-ntlmssp v0.1.1 // indirect
	github.com/AzureAD/microsoft-authentication-library-for-go v1.8.0 // indirect
	github.com/FZambia/eagle v0.2.0 // indirect
	github.com/GoogleCloudPlatform/opentelemetry-operations-go/detectors/gcp v1.34.0 // indirect
	github.com/GoogleCloudPlatform/opentelemetry-operations-go/exporter/metric v0.57.0 // indirect
	github.com/GoogleCloudPlatform/opentelemetry-operations-go/internal/resourcemapping v0.57.0 // indirect
	github.com/IBM/pgxpoolprometheus v1.1.3 // indirect
	github.com/Machiel/slugify v1.0.1 // indirect
	github.com/Masterminds/goutils v1.1.1 // indirect
	github.com/Masterminds/squirrel v1.5.4 // indirect
	github.com/Microsoft/go-winio v0.6.3 // indirect
	github.com/NYTimes/gziphandler v1.1.1 // indirect
	github.com/PaesslerAG/gval v1.0.0 // indirect
	github.com/ProtonMail/go-crypto v1.5.2 // indirect
	github.com/RoaringBitmap/roaring/v2 v2.14.5 // indirect
	github.com/Yiling-J/theine-go v0.6.2 // indirect
	github.com/agext/levenshtein v1.2.3 // indirect
	github.com/alecthomas/units v0.0.0-20240927000941-0f3dac36c52b // indirect
	github.com/antithesishq/antithesis-sdk-go v0.7.2-default-no-op // indirect
	github.com/antlr4-go/antlr/v4 v4.13.1 // indirect
	github.com/apache/thrift v0.24.0 // indirect
	github.com/apparentlymart/go-textseg/v15 v15.0.0 // indirect
	github.com/armon/go-metrics v0.4.1 // indirect
	github.com/at-wat/mqtt-go v0.19.6 // indirect
	github.com/atotto/clipboard v0.1.4 // indirect
	github.com/aws/aws-sdk-go v1.55.8 // indirect
	github.com/aws/aws-sdk-go-v2/aws/protocol/eventstream v1.7.11 // indirect
	github.com/aws/aws-sdk-go-v2/feature/s3/transfermanager v0.2.3 // indirect
	github.com/aws/aws-sdk-go-v2/internal/configsources v1.5.2 // indirect
	github.com/aws/aws-sdk-go-v2/internal/endpoints/v2 v2.8.2 // indirect
	github.com/aws/aws-sdk-go-v2/internal/v4a v1.5.2 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/accept-encoding v1.13.19 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/checksum v1.9.18 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/presigned-url v1.14.2 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/s3shared v1.19.25 // indirect
	github.com/aws/aws-sdk-go-v2/service/signin v1.9.0 // indirect
	github.com/aws/aws-sdk-go-v2/service/sso v1.37.0 // indirect
	github.com/aws/aws-sdk-go-v2/service/ssooidc v1.42.0 // indirect
	github.com/aymanbagabas/go-osc52/v2 v2.0.1 // indirect
	github.com/bahlo/generic-list-go v0.2.0 // indirect
	github.com/barkimedes/go-deepcopy v0.0.0-20220514131651-17c30cfc62df // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/bits-and-blooms/bitset v1.24.4 // indirect
	github.com/blang/semver v3.5.1+incompatible // indirect
	github.com/blang/semver/v4 v4.0.0 // indirect
	github.com/blevesearch/geo v0.2.5 // indirect
	github.com/blevesearch/go-faiss v1.1.0 // indirect
	github.com/blevesearch/go-porterstemmer v1.0.3 // indirect
	github.com/blevesearch/gtreap v0.1.1 // indirect
	github.com/blevesearch/mmap-go v1.2.0 // indirect
	github.com/blevesearch/scorch_segment_api/v2 v2.4.7 // indirect
	github.com/blevesearch/segment v0.9.1 // indirect
	github.com/blevesearch/snowballstem v0.9.0 // indirect
	github.com/blevesearch/upsidedown_store_api v1.0.2 // indirect
	github.com/blevesearch/vellum v1.2.0 // indirect
	github.com/blevesearch/zapx/v11 v11.4.3 // indirect
	github.com/blevesearch/zapx/v12 v12.4.3 // indirect
	github.com/blevesearch/zapx/v13 v13.4.3 // indirect
	github.com/blevesearch/zapx/v14 v14.4.3 // indirect
	github.com/blevesearch/zapx/v15 v15.4.3 // indirect
	github.com/bufbuild/protocompile v0.14.1 // indirect
	github.com/buger/jsonparser v1.6.1 // indirect
	github.com/cenkalti/backoff/v5 v5.0.3 // indirect
	github.com/centrifugal/protocol v0.22.1 // indirect
	github.com/charmbracelet/colorprofile v0.4.2 // indirect
	github.com/charmbracelet/x/ansi v0.11.6 // indirect
	github.com/charmbracelet/x/cellbuf v0.0.15 // indirect
	github.com/charmbracelet/x/term v0.2.2 // indirect
	github.com/cheekybits/genny v1.0.0 // indirect
	github.com/clipperhouse/displaywidth v0.11.0 // indirect
	github.com/clipperhouse/uax29/v2 v2.7.0 // indirect
	github.com/cloudflare/circl v1.6.5 // indirect
	github.com/cncf/xds/go v0.0.0-20260202195803-dba9d589def2 // indirect
	github.com/cockroachdb/apd/v3 v3.2.3 // indirect
	github.com/containerd/errdefs v1.0.0 // indirect
	github.com/containerd/errdefs/pkg v0.3.0 // indirect
	github.com/containerd/log v0.2.0 // indirect
	github.com/containerd/platforms v0.2.1 // indirect
	github.com/coreos/go-semver v0.3.1 // indirect
	github.com/coreos/go-systemd/v22 v22.7.0 // indirect
	github.com/cpuguy83/dockercfg v0.3.2 // indirect
	github.com/cpuguy83/go-md2man/v2 v2.0.7 // indirect
	github.com/davecgh/go-spew v1.1.2-0.20180830191138-d8f796af33cc // indirect
	github.com/dennwc/varint v1.0.0 // indirect
	github.com/dgraph-io/ristretto/v2 v2.2.0 // indirect
	github.com/diegoholiveira/jsonlogic/v3 v3.7.4 // indirect
	github.com/distribution/reference v0.6.0 // indirect
	github.com/docker/go-connections v0.8.2 // indirect
	github.com/docker/go-units v0.5.0 // indirect
	github.com/dolthub/flatbuffers/v23 v23.3.3-dh.2 // indirect
	github.com/dolthub/jsonpath v0.0.2-0.20240227200619-19675ab05c71 // indirect
	github.com/dustin/go-humanize v1.0.1 // indirect; @grafana/observability-traces-and-profiling
	github.com/ebitengine/purego v0.11.1 // indirect
	github.com/edsrzf/mmap-go v1.2.1-0.20241212181136-fad1cd13edbd // indirect
	github.com/efficientgo/core v1.0.0-rc.3 // indirect
	github.com/elazarl/goproxy v1.9.2 // indirect
	github.com/emicklei/proto v1.14.3 // indirect
	github.com/emirpasic/gods v1.18.1 // indirect
	github.com/envoyproxy/go-control-plane/envoy v1.37.0 // indirect
	github.com/envoyproxy/protoc-gen-validate v1.3.3 // indirect
	github.com/erikgeiser/coninput v0.0.0-20211004153227-1c3628e74d0f // indirect
	github.com/facette/natsort v0.0.0-20181210072756-2cd4dd1e2dcb // indirect
	github.com/felixge/httpsnoop v1.1.0 // indirect
	github.com/fxamacker/cbor/v2 v2.9.6 // indirect
	github.com/go-asn1-ber/asn1-ber v1.5.4 // indirect
	github.com/go-kit/log v0.2.1 // indirect; @grafana/grafana-backend-group
	github.com/go-logfmt/logfmt v0.6.1 // indirect
	github.com/go-logr/stdr v1.2.2 // indirect
	github.com/go-ole/go-ole v1.3.0 // indirect
	github.com/go-openapi/analysis v1.0.1 // indirect
	github.com/go-openapi/errors v0.22.9 // indirect
	github.com/go-openapi/jsonpointer v1.0.2 // indirect
	github.com/go-openapi/jsonreference v1.0.3 // indirect
	github.com/go-openapi/loads v0.25.3 // indirect; @grafana/alerting-backend
	github.com/go-openapi/runtime/server-middleware v0.33.3 // indirect
	github.com/go-openapi/spec v1.0.1 // indirect
	github.com/go-openapi/swag v0.29.2 // indirect
	github.com/go-openapi/swag/cmdutils v0.29.2 // indirect
	github.com/go-openapi/swag/conv v0.29.2 // indirect
	github.com/go-openapi/swag/fileutils v0.29.2 // indirect
	github.com/go-openapi/swag/jsonutils v0.29.2 // indirect
	github.com/go-openapi/swag/loading v0.29.2 // indirect
	github.com/go-openapi/swag/mangling v0.29.2 // indirect
	github.com/go-openapi/swag/netutils v0.29.2 // indirect
	github.com/go-openapi/swag/pools v0.29.2 // indirect
	github.com/go-openapi/swag/stringutils v0.29.2 // indirect
	github.com/go-openapi/swag/typeutils v0.29.2 // indirect
	github.com/go-openapi/swag/yamlutils v0.29.2 // indirect
	github.com/go-openapi/validate v1.0.0 // indirect
	github.com/go-stack/stack v1.8.1 // indirect; @grafana/grafana-backend-group
	github.com/go-viper/mapstructure/v2 v2.5.0 // indirect
	github.com/goccy/go-json v0.11.2 // indirect
	github.com/gofrs/uuid v4.4.0+incompatible // indirect
	github.com/gogo/googleapis v1.4.1 // indirect
	github.com/gogo/status v1.1.1 // indirect
	github.com/golang-jwt/jwt/v5 v5.3.1 // indirect
	github.com/google/btree v1.1.3 // indirect
	github.com/google/cel-go v0.31.0 // indirect
	github.com/google/flatbuffers v25.12.19+incompatible // indirect
	github.com/google/gnostic-models v0.7.1 // indirect
	github.com/google/go-github/v73 v73.0.0 // indirect
	github.com/google/go-querystring v1.2.0 // indirect
	github.com/google/go-tpm v0.9.8 // indirect
	github.com/google/s2a-go v0.1.9 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/googleapis/enterprise-certificate-proxy v0.3.20 // indirect
	github.com/gopherjs/gopherjs v1.17.2 // indirect
	github.com/gorilla/websocket v1.5.4-0.20250319132907-e064f32e3674 // indirect; @grafana/grafana-app-platform-squad
	github.com/grafana/loki/pkg/push v0.0.0-20250823105456-332df2b20000 // indirect; @grafana/alerting-backend
	github.com/grafana/nanogit v1.7.3 // indirect
	github.com/grafana/otel-profiling-go v0.7.0 // indirect
	github.com/grafana/regexp v0.0.0-20250905093917-f7b3be9d1853 // indirect
	github.com/grafana/sqlds/v5 v5.3.1 // indirect
	github.com/hashicorp/consul/api v1.34.4 // indirect
	github.com/hashicorp/errwrap v1.1.0 // indirect
	github.com/hashicorp/go-cleanhttp v0.5.2 // indirect
	github.com/hashicorp/go-immutable-radix v1.3.1 // indirect
	github.com/hashicorp/go-metrics v0.6.1 // indirect
	github.com/hashicorp/go-msgpack/v2 v2.1.5 // indirect
	github.com/hashicorp/go-retryablehttp v0.7.8 // indirect
	github.com/hashicorp/go-rootcerts v1.0.2 // indirect
	github.com/hashicorp/go-secure-stdlib/parseutil v0.2.0 // indirect
	github.com/hashicorp/go-secure-stdlib/strutil v0.1.2 // indirect
	github.com/hashicorp/go-sockaddr v1.0.7 // indirect
	github.com/hashicorp/golang-lru v1.0.2 // indirect
	github.com/hashicorp/hcl v1.0.1-vault-7 // indirect
	github.com/hashicorp/memberlist v0.6.0 // indirect
	github.com/hashicorp/serf v0.10.4 // indirect
	github.com/hashicorp/vault/api v1.22.0 // indirect
	github.com/hashicorp/yamux v0.1.2 // indirect
	github.com/huandu/go-clone v1.7.3 // indirect
	github.com/huandu/go-sqlbuilder v1.40.2 // indirect
	github.com/huandu/xstrings v1.6.2 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/influxdata/line-protocol v0.0.0-20210922203350-b1ad95c89adf // indirect; @grafana/grafana-app-platform-squad
	github.com/invopop/jsonschema v0.14.0 // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	github.com/jaegertracing/jaeger-idl v0.14.0 // indirect
	github.com/jessevdk/go-flags v1.6.1 // indirect
	github.com/jhump/protoreflect v1.17.0 // indirect
	github.com/jmespath/go-jmespath v0.4.0 // indirect
	github.com/josharian/intern v1.0.0 // indirect
	github.com/jpillora/backoff v1.0.0 // indirect
	github.com/jszwedko/go-datemath v0.1.1-0.20260113213115-7f666eef0523 // indirect
	github.com/jtolds/gls v4.20.0+incompatible // indirect
	github.com/klauspost/compress v1.20.3 // indirect
	github.com/klauspost/cpuid/v2 v2.4.1 // indirect
	github.com/kylelemons/godebug v1.1.0 // indirect
	github.com/lann/builder v0.0.0-20180802200727-47ae307949d0 // indirect
	github.com/lann/ps v0.0.0-20150810152359-62de8c46ede0 // indirect
	github.com/lestrrat-go/strftime v1.0.4 // indirect
	github.com/lucasb-eyer/go-colorful v1.3.0 // indirect
	github.com/lufia/plan9stats v0.0.0-20260802145828-341c2f0c90b5 // indirect
	github.com/magefile/mage v1.17.2 // indirect
	github.com/magiconair/properties v1.18.12 // indirect
	github.com/mailru/easyjson v0.9.2 // indirect
	github.com/mattetti/filebuffer v1.0.1 // indirect
	github.com/mattn/go-colorable v0.1.16 // indirect
	github.com/mattn/go-isatty v0.0.24 // indirect; @grafana/grafana-backend-group
	github.com/mattn/go-localereader v0.0.1 // indirect
	github.com/mattn/go-runewidth v0.0.31 // indirect
	github.com/maypok86/otter/v2 v2.3.0 // indirect
	github.com/mdlayher/socket v0.6.1 // indirect
	github.com/mdlayher/vsock v1.3.0 // indirect
	github.com/mfridman/interpolate v0.0.2 // indirect
	github.com/miekg/dns v1.1.73 // indirect
	github.com/minio/highwayhash v1.0.4 // indirect
	github.com/mitchellh/copystructure v1.2.0 // indirect
	github.com/mitchellh/go-homedir v1.1.0 // indirect
	github.com/mitchellh/go-wordwrap v1.0.1 // indirect
	github.com/mitchellh/reflectwalk v1.0.2 // indirect
	github.com/mithrandie/csvq v1.18.1 // indirect
	github.com/mithrandie/csvq-driver v1.7.0 // indirect
	github.com/mithrandie/go-file/v2 v2.1.0 // indirect
	github.com/mithrandie/go-text v1.6.0 // indirect
	github.com/mithrandie/ternary v1.1.1 // indirect
	github.com/moby/docker-image-spec v1.3.1 // indirect
	github.com/moby/go-archive v0.3.3 // indirect
	github.com/moby/moby/api v1.56.1 // indirect
	github.com/moby/moby/client v0.6.2 // indirect
	github.com/moby/patternmatcher v0.6.1 // indirect
	github.com/moby/spdystream v0.5.1 // indirect
	github.com/moby/sys/sequential v0.7.0 // indirect
	github.com/moby/sys/user v0.4.1 // indirect
	github.com/moby/sys/userns v0.2.1 // indirect
	github.com/moby/term v0.5.2 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/mschoch/smat v0.2.0 // indirect
	github.com/muesli/ansi v0.0.0-20230316100256-276c6243b2f6 // indirect
	github.com/muesli/cancelreader v0.2.2 // indirect
	github.com/muesli/termenv v0.16.0 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/mxk/go-flowrate v0.0.0-20140419014527-cca7078d478f // indirect
	github.com/natefinch/wrap v0.2.0 // indirect
	github.com/nats-io/jwt/v2 v2.8.2 // indirect
	github.com/nats-io/nkeys v0.4.16 // indirect
	github.com/nats-io/nuid v1.0.1 // indirect
	github.com/ncruces/go-strftime v1.0.0 // indirect
	github.com/nikunjy/rules v1.5.0 // indirect
	github.com/oasdiff/yaml v0.1.1 // indirect
	github.com/oasdiff/yaml3 v0.0.14 // indirect
	github.com/oklog/run v1.2.0 // indirect
	github.com/oklog/ulid v1.3.1 // indirect
	github.com/olekukonko/cat v0.0.0-20250911104152-50322a0618f6 // indirect
	github.com/olekukonko/errors v1.3.0 // indirect
	github.com/olekukonko/ll v0.1.9 // indirect
	github.com/olekukonko/tablewriter v1.1.5 // indirect; @grafana/grafana-backend-group
	github.com/onsi/ginkgo v1.16.5 // indirect
	github.com/open-feature/go-sdk-contrib/providers/ofrep v0.1.7 // indirect; @grafana/grafana-backend-services-squad
	github.com/open-telemetry/opentelemetry-collector-contrib/internal/coreinternal v0.150.0 // indirect
	github.com/open-telemetry/opentelemetry-collector-contrib/pkg/core/xidutils v0.150.0 // indirect
	github.com/open-telemetry/opentelemetry-collector-contrib/pkg/translator/jaeger v0.150.0 // indirect
	github.com/opencontainers/go-digest v1.0.0 // indirect
	github.com/opencontainers/image-spec v1.1.1 // indirect
	github.com/opentracing-contrib/go-grpc v0.1.4 // indirect
	github.com/opentracing-contrib/go-stdlib v1.1.1 // indirect
	github.com/opentracing/opentracing-go v1.2.1-0.20220228012449-10b1cf09e00b // indirect
	github.com/pb33f/go-yaml v0.1.1 // indirect
	github.com/pb33f/ordered-map/v2 v2.3.2 // indirect
	github.com/pborman/uuid v1.2.1 // indirect
	github.com/pelletier/go-toml/v2 v2.4.3 // indirect
	github.com/phpdave11/gofpdi v1.0.14 // indirect
	github.com/pierrec/lz4/v4 v4.1.33 // indirect
	github.com/pires/go-proxyproto v0.15.0 // indirect
	github.com/pkg/browser v0.0.0-20240102092130-5ac0b6a4141c // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/planetscale/vtprotobuf v0.6.1-0.20250313105119-ba97887b0a25 // indirect
	github.com/pmezard/go-difflib v1.0.1-0.20181226105442-5d4384ee4fb2 // indirect
	github.com/power-devops/perfstat v0.0.0-20260916203055-22a1a467d9f0 // indirect
	github.com/prometheus/client_golang/exp v0.0.0-20260602051030-3537b20ac86b // indirect
	github.com/prometheus/common/sigv4 v0.1.0 // indirect
	github.com/prometheus/exporter-toolkit v0.19.0 // indirect
	github.com/prometheus/otlptranslator v1.0.0 // indirect
	github.com/prometheus/procfs v0.22.0 // indirect
	github.com/protocolbuffers/txtpbfmt v0.0.0-20261013103202-7c8a61a7a736 // indirect
	github.com/quagmt/udecimal v1.10.1 // indirect
	github.com/redis/go-redis/extra/rediscmd/v9 v9.22.0 // indirect
	github.com/redis/rueidis v1.0.77 // indirect
	github.com/remyoudompheng/bigfft v0.0.0-20230129092748-24d4a6f8daec // indirect
	github.com/rivo/uniseg v0.4.7 // indirect
	github.com/ryanuber/go-glob v1.0.0 // indirect
	github.com/sagikazarmark/locafero v0.11.0 // indirect
	github.com/santhosh-tekuri/jsonschema/v6 v6.0.3 // indirect
	github.com/sean-/seed v0.0.0-20170313163322-e2103e2c3529 // indirect
	github.com/segmentio/asm v1.2.1 // indirect
	github.com/segmentio/encoding v0.5.4 // indirect
	github.com/sercand/kuberesolver/v6 v6.0.1 // indirect
	github.com/sergi/go-diff v1.3.2-0.20230802210424-5b0b94c5c0d3 // indirect
	github.com/sethvargo/go-retry v0.4.0 // indirect
	github.com/shadowspore/fossil-delta v0.0.0-20241213113458-1d797d70cbe3 // indirect
	github.com/shirou/gopsutil/v4 v4.26.9 // indirect
	github.com/shurcooL/httpfs v0.0.0-20230704072500-f1e31cf0ba5c // indirect
	github.com/shurcooL/vfsgen v0.0.0-20230704071429-0000e147ea92 // indirect
	github.com/sirupsen/logrus v1.10.2 // indirect
	github.com/smallstep/pkcs7 v0.2.3 // indirect
	github.com/sourcegraph/conc v0.3.1-0.20240121214520-5f936abd7ae8 // indirect
	github.com/spf13/afero v1.15.0 // indirect
	github.com/spf13/cast v1.10.0 // indirect
	github.com/spf13/viper v1.21.0 // indirect
	github.com/spiffe/go-spiffe/v2 v2.8.1 // indirect
	github.com/stretchr/objx v0.8.0 // indirect
	github.com/subosito/gotenv v1.6.0 // indirect
	github.com/thanos-io/objstore v0.0.0-20250115091151-a54d0f04b42a // indirect
	github.com/tidwall/gjson v1.19.0 // indirect
	github.com/tidwall/match v1.1.1 // indirect
	github.com/tidwall/pretty v1.2.1 // indirect
	github.com/tidwall/sjson v1.2.5 // indirect
	github.com/tinylib/msgp v1.6.3 // indirect
	github.com/tjhop/slog-gokit v0.2.0 // indirect; @grafana/grafana-app-platform-squad
	github.com/tklauser/go-sysconf v0.4.0 // indirect
	github.com/tklauser/numcpus v0.12.0 // indirect
	github.com/trivago/tgo v1.0.7 // indirect
	github.com/uber/jaeger-client-go v2.30.0+incompatible // indirect
	github.com/uber/jaeger-lib v2.4.1+incompatible // indirect
	github.com/unknwon/bra v0.0.0-20200517080246-1e3013ecaff8 // indirect
	github.com/unknwon/com v1.0.1 // indirect
	github.com/unknwon/log v0.0.0-20200308114134-929b1006e34a // indirect
	github.com/urfave/cli v1.22.17 // indirect
	github.com/valyala/bytebufferpool v1.0.0 // indirect
	github.com/x448/float16 v0.8.4 // indirect
	github.com/xo/terminfo v0.0.0-20220910002029-abceb7e1c41e // indirect
	github.com/xrash/smetrics v0.0.0-20240521201337-686a1a2994c1 // indirect
	github.com/yudai/golcs v0.0.0-20170316035057-ecda9a501e82 // indirect
	github.com/yudai/pp v2.0.1+incompatible // indirect
	github.com/yusufpapurcu/wmi v1.2.4 // indirect
	github.com/zclconf/go-cty v1.16.3 // indirect
	github.com/zeebo/xxh3 v1.1.0 // indirect
	go.etcd.io/etcd/api/v3 v3.7.1 // indirect
	go.etcd.io/etcd/client/pkg/v3 v3.7.1 // indirect
	go.etcd.io/etcd/client/v3 v3.7.1 // indirect
	go.opentelemetry.io/auto/sdk v1.2.1 // indirect
	go.opentelemetry.io/collector/featuregate v1.66.0 // indirect
	go.opentelemetry.io/collector/pdata/pprofile v0.154.0 // indirect
	go.opentelemetry.io/contrib/bridges/prometheus v0.71.0 // indirect
	go.opentelemetry.io/contrib/detectors/gcp v1.44.0 // indirect
	go.opentelemetry.io/contrib/exporters/autoexport v0.71.0 // indirect
	go.opentelemetry.io/contrib/propagators/jaeger v1.47.0 // indirect
	go.opentelemetry.io/contrib/samplers/jaegerremote v0.38.0 // indirect
	go.opentelemetry.io/otel/exporters/jaeger v1.17.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlplog/otlploggrpc v0.22.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlplog/otlploghttp v0.22.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetricgrpc v1.46.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetrichttp v1.46.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlptrace v1.47.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc v1.47.0 // indirect
	go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp v1.47.0 // indirect
	go.opentelemetry.io/otel/exporters/prometheus v0.68.0 // indirect
	go.opentelemetry.io/otel/exporters/stdout/stdoutlog v0.22.0 // indirect
	go.opentelemetry.io/otel/exporters/stdout/stdoutmetric v1.46.0 // indirect
	go.opentelemetry.io/otel/exporters/stdout/stdouttrace v1.47.0 // indirect
	go.opentelemetry.io/otel/log v1.47.0 // indirect
	go.opentelemetry.io/otel/metric v1.47.0 // indirect
	go.opentelemetry.io/otel/sdk v1.47.0 // indirect; @grafana/grafana-backend-group
	go.opentelemetry.io/otel/sdk/log v0.22.0 // indirect
	go.opentelemetry.io/otel/sdk/metric v1.47.0 // indirect
	go.opentelemetry.io/proto/otlp v1.11.1 // indirect
	go.uber.org/multierr v1.11.0 // indirect
	go.yaml.in/yaml/v2 v2.4.4 // indirect
	golang.org/x/crypto v0.58.0 // indirect
	golang.org/x/exp v0.0.0-20261014143641-f0251eb4aa3e // indirect
	golang.org/x/mod v0.42.0 // indirect
	golang.org/x/sys v0.49.0 // indirect
	golang.org/x/telemetry v0.0.0-20261009151841-97e8ea77aa2a // indirect
	golang.org/x/term v0.47.0 // indirect
	golang.org/x/tools v0.52.0 // indirect
	golang.org/x/xerrors v0.0.0-20240903120638-7835f813f4da // indirect
	gomodules.xyz/jsonpatch/v3 v3.0.1 // indirect
	gomodules.xyz/orderedmap v0.1.0 // indirect
	google.golang.org/genproto v0.0.0-20260715232425-e75dac1f907d // indirect
	gopkg.in/alexcesaro/quotedprintable.v3 v3.0.0-20150716171945-2caba252f4dc // indirect
	gopkg.in/fsnotify/fsnotify.v1 v1.4.7 // indirect
	gopkg.in/inf.v0 v0.9.1 // indirect
	gopkg.in/natefinch/lumberjack.v2 v2.2.1 // indirect
	gopkg.in/src-d/go-errors.v1 v1.0.0 // indirect
	gopkg.in/telebot.v3 v3.3.8 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
	k8s.io/kms v0.37.1 // indirect
	k8s.io/streaming v0.37.1 // indirect
	modernc.org/libc v1.75.6 // indirect
	modernc.org/mathutil v1.7.1 // indirect
	modernc.org/memory v1.12.1 // indirect
	modernc.org/sqlite v1.58.0 // indirect
	sigs.k8s.io/apiserver-network-proxy/konnectivity-client v0.37.0 // indirect
	sigs.k8s.io/json v0.0.0-20260909141634-11ed52e25bc5 // indirect
	sigs.k8s.io/randfill v1.0.0 // indirect; @grafana/grafana-app-platform-squad
	sigs.k8s.io/yaml v1.6.0 // indirect
	software.sslmate.com/src/go-pkcs12 v0.7.2 // indirect
)

replace (
	// Use our fork of dolthub/go-mysql-server which adds TableHintedTable for FOR (...) hints
	// and makes non-cgo the default for developer builds.
	github.com/dolthub/go-mysql-server => github.com/grafana/go-mysql-server v0.20.2-grafana-4
	github.com/dolthub/vitess => github.com/grafana/vitess v0.0.0-grafana-2

	// Use our fork of memberlist which includes some fixes that haven't been merged upstream yet.
	github.com/hashicorp/memberlist => github.com/grafana/memberlist v0.3.1-0.20260515134459-1798cf41aca7

	// Use our fork of the upstream Alertmanager.
	github.com/prometheus/alertmanager => github.com/grafana/prometheus-alertmanager v0.25.1-0.20261009142442-7daeb08a4623
)

// This was retracted, but seems to be known by the Go module proxy,
// and is otherwise pulled in as a transitive dependency.
exclude k8s.io/client-go v12.0.0+incompatible
