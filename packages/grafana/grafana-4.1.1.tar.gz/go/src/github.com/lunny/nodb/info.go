package nodb

// todo, add info

// type Keyspace struct {
// 	Kvs       int `json:"kvs"`
// 	KvExpires int `json:"kv_expires"`

// 	Lists       int `json:"lists"`
// 	ListExpires int `json:"list_expires"`

// 	Bitmaps       int `json:"bitmaps"`
// 	BitmapExpires int `json:"bitmap_expires"`

// 	ZSets       int `json:"zsets"`
// 	ZSetExpires int `json:"zset_expires"`

// 	Hashes      int `json:"hashes"`
// 	HashExpires int `json:"hahsh_expires"`
// }

// type Info struct {
// 	KeySpaces [MaxDBNumber]Keyspace
// }
