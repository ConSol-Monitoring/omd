import app from './app';

app.initEchoSrv();
app.init();
