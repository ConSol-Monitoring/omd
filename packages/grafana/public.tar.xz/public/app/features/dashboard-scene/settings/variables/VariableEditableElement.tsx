import { type FormEvent, useId, useMemo, useRef, useState } from 'react';

import { VariableHide, VariableRefresh } from '@grafana/data';
import { selectors } from '@grafana/e2e-selectors';
import { Trans, t } from '@grafana/i18n';
import { locationService } from '@grafana/runtime';
import { useFlagGrafanaQueryVarEditorRedesign } from '@grafana/runtime/internal';
import {
  LocalValueVariable,
  MultiValueVariable,
  QueryVariable,
  type SceneObject,
  type SceneVariable,
  SceneVariableSet,
  sceneUtils,
  useSceneObjectState,
} from '@grafana/scenes';
import { Alert, Box, Button, Combobox, Field, Input, Stack, TextArea } from '@grafana/ui';
import { appEvents } from 'app/core/app_events';
import { OptionsPaneCategoryDescriptor } from 'app/features/dashboard/components/PanelEditor/OptionsPaneCategoryDescriptor';
import { OptionsPaneItemDescriptor } from 'app/features/dashboard/components/PanelEditor/OptionsPaneItemDescriptor';
import { ShowConfirmModalEvent } from 'app/types/events';

import { changeVariableDescription } from '../../actions/variable/changeVariableDescription';
import { changeVariableHideValue } from '../../actions/variable/changeVariableHideValue';
import { changeVariableLabel } from '../../actions/variable/changeVariableLabel';
import { changeVariableName } from '../../actions/variable/changeVariableName';
import { duplicateVariable } from '../../actions/variable/duplicateVariable';
import { removeVariable } from '../../actions/variable/removeVariable';
import { DashboardScene } from '../../scene/DashboardScene';
import { useSidebarInputAutoFocus } from '../../scene/layouts-shared/utils';
import { type BulkActionElement } from '../../scene/types/BulkActionElement';
import {
  type EditableDashboardElement,
  type EditableDashboardElementInfo,
  isEditableDashboardElement,
} from '../../scene/types/EditableDashboardElement';
import { VariableDisplaySelect } from '../../settings/variables/components/VariableDisplaySelect';
import {
  dropShadowedPredefinedVariables,
  getEditableVariableDefinition,
  restoreUnshadowedPredefinedVariables,
  validateVariableName,
} from '../../settings/variables/utils';
import { dashboardSceneGraph } from '../../utils/dashboardSceneGraph';
import { getTopPlacementLabel } from '../../utils/getTopPlacementLabel';

import { openChangeVariableTypePane } from './VariableTypeSelectionPane';
import { useVariableSelectionOptionsCategory } from './useVariableSelectionOptionsCategory';

// TODO fix conditional hook usage here...
function useSidebarOptions(this: VariableEditableElement, isNewElement: boolean): OptionsPaneCategoryDescriptor[] {
  const variable = this.variable;
  const variableOptionsCategoryId = useId();
  const variableNameId = useId();
  const labelId = useId();
  const descriptionId = useId();
  const variableDisplayId = useId();

  // Keep the variable activated while editing it in the side pane. The dashboard controls
  // component may unmount (e.g. when changing display to "hidden"), which would deactivate
  // the variable and destroy all state subscriptions used by the editors below.
  useSceneObjectState(variable, { shouldActivateOrKeepAlive: true });

  if (variable instanceof LocalValueVariable) {
    return useLocalVariableOptions(variable);
  }

  const basicOptions = useMemo(() => {
    return new OptionsPaneCategoryDescriptor({ title: '', id: variableOptionsCategoryId })
      .addItem(
        new OptionsPaneItemDescriptor({
          title: '',
          id: variableNameId,
          skipField: true,
          render: () => <VariableNameInput variable={variable} autoFocus={isNewElement} />,
        })
      )
      .addItem(
        new OptionsPaneItemDescriptor({
          title: t('dashboard.sidebar.variable.label', 'Label'),
          id: labelId,
          description: t('dashboard.sidebar.variable.label-description', 'Optional display name'),
          render: () => <VariableLabelInput variable={variable} />,
        })
      )
      .addItem(
        new OptionsPaneItemDescriptor({
          title: t('dashboard.sidebar.variable.description', 'Description'),
          id: descriptionId,
          render: () => <VariableDescriptionTextArea variable={variable} />,
        })
      )
      .addItem(
        new OptionsPaneItemDescriptor({
          title: '',
          id: variableDisplayId,
          skipField: true,
          render: () => <VariableDisplayInput variable={variable} />,
        })
      );
  }, [variableOptionsCategoryId, variableNameId, labelId, descriptionId, variableDisplayId, variable, isNewElement]);

  const categories = [basicOptions];
  const typeCategory = useVariableTypeCategory(variable);
  categories.push(typeCategory);

  if (variable instanceof MultiValueVariable) {
    categories.push(useVariableSelectionOptionsCategory(variable));
  }

  return categories;
}

export class VariableEditableElement implements EditableDashboardElement, BulkActionElement {
  public readonly isEditableDashboardElement = true;
  public readonly typeName = 'Variable';

  public constructor(public variable: SceneVariable) {}

  public getEditableElementInfo(): EditableDashboardElementInfo {
    if (this.variable instanceof LocalValueVariable) {
      return {
        typeName: t('dashboard.sidebar.elements.local-variable', 'Local variable'),
        icon: 'gf-variable',
        instanceName: this.variable.state.name,
        isHidden: true,
      };
    }

    const variableEditorDef = getEditableVariableDefinition(this.variable.state.type);
    const { label, name } = this.variable.state;
    const hasLabel = !!label && label.trim() !== '';
    const instanceName = hasLabel ? label! : name;
    const tooltip = hasLabel ? `$${name}` : undefined;

    if (sceneUtils.isAdHocVariable(this.variable)) {
      return {
        typeName: t('dashboard.sidebar.elements.filter', 'Filter'),
        icon: 'filter',
        instanceName,
        tooltip,
        isHidden: this.variable.state.hide === VariableHide.hideVariable,
      };
    }

    return {
      typeName: t('dashboard.sidebar.elements.variable', '{{type}} variable', { type: variableEditorDef.name }),
      icon: 'gf-variable',
      instanceName,
      tooltip,
      isHidden: this.variable.state.hide === VariableHide.hideVariable,
    };
  }

  public useSidebarOptions = useSidebarOptions.bind(this);

  public renderActions() {
    return <ChangeVariableTypeButton variable={this.variable} />;
  }

  public onDuplicate() {
    duplicateVariable(this.variable);
  }

  public onConfirmDelete() {
    const name = this.variable.state.name;
    appEvents.publish(
      new ShowConfirmModalEvent({
        title: t('dashboard-scene.variable-editable-element.delete-title', 'Delete variable'),
        text: t('dashboard-scene.variable-editable-element.delete-text', 'Are you sure you want to delete: {{name}}?', {
          name,
        }),
        yesText: t('dashboard-scene.variable-editable-element.delete-confirm', 'Delete variable'),
        onConfirm: () => {
          this.onDelete();
        },
      })
    );
  }

  public onDelete() {
    const set = this.variable.parent!;
    if (!(set instanceof SceneVariableSet)) {
      return;
    }

    removeVariable({
      source: set,
      removedObject: this.variable,
    });
  }

  public onChangeName(name: string) {
    this.variable.setState({ name });

    const result = validateVariableName(this.variable, name);
    if (result.errorMessage) {
      return result;
    }

    // Do not drop predefined vars here — onChangeName runs per keystroke (outline rename).
    // Drop happens on commit via onCommitName / changeVariableName.
    return;
  }

  /**
   * Called when an outline rename commits (blur / Enter). Restores any predefined
   * variable freed by the rename, then drops any shadowed by the committed name.
   */
  public onCommitName() {
    restoreUnshadowedPredefinedVariables(this.variable);
    dropShadowedPredefinedVariables(this.variable, this.variable.state.name);
  }

  public scrollIntoView() {
    let current: SceneObject | undefined = this.variable.parent;
    while (current) {
      if (isEditableDashboardElement(current) && current.scrollIntoView) {
        current.scrollIntoView();
        return;
      }
      current = current.parent;
    }
  }
}

interface VariableInputProps {
  variable: SceneVariable;
  id?: string;
}

function ChangeVariableTypeButton({ variable }: { variable: SceneVariable }) {
  if (!(variable.parent instanceof SceneVariableSet)) {
    return null;
  }

  return (
    <Button
      size="sm"
      onClick={() => openChangeVariableTypePane(variable)}
      data-testid={selectors.components.PanelEditor.ElementEditPane.changeVariableType}
      aria-label={t('dashboard.sidebar.variable.change-type-aria-label', 'Change variable type')}
      variant="secondary"
    >
      <Trans i18nKey="dashboard.sidebar.variable.change-type">Change type</Trans>
    </Button>
  );
}

function VariableNameInput({ variable, autoFocus }: { variable: SceneVariable; autoFocus: boolean }) {
  const { name } = variable.useState();
  const ref = useSidebarInputAutoFocus({ autoFocus });
  const [nameError, setNameError] = useState<string>();
  const [nameWarning, setNameWarning] = useState<string>();
  const id = useId();

  const onChange = (e: FormEvent<HTMLInputElement>) => {
    const nextName = e.currentTarget.value;
    const result = validateVariableName(variable, nextName);
    if (result.errorMessage !== nameError) {
      setNameError(result.errorMessage);
    }
    if (result.warningMessage !== nameWarning) {
      setNameWarning(result.warningMessage);
    }

    // Update live state for the input; drop shadowed predefined vars only on blur
    // commit (changeVariableName) so intermediate keystrokes cannot permanently remove them.
    variable.setState({ name: nextName });
  };

  const oldName = useRef(name);

  return (
    <>
      <Field
        label={t('dashboard.sidebar.variable.name', 'Name')}
        invalid={!!nameError}
        error={nameError}
        noMargin={false}
      >
        <Input
          id={id}
          ref={ref}
          value={name}
          onFocus={() => {
            oldName.current = name;
          }}
          onChange={onChange}
          onBlur={(e) => {
            const labelUnchanged = oldName.current === name;
            const shouldSkip = labelUnchanged;

            if (nameError) {
              setNameError(undefined);
              variable.setState({ name: oldName.current });
              return;
            }

            if (shouldSkip) {
              return;
            }

            changeVariableName({
              source: variable,
              oldValue: oldName.current,
              newValue: name,
            });
          }}
          data-testid={selectors.components.PanelEditor.ElementEditPane.variableNameInput}
          required
        />
      </Field>
      {/* Show warning message if the variable name is already used in the dashboard
        Unfortunately <Field> component only supports error messages, not warning messages.
      */}
      {nameWarning && <Alert title={nameWarning} severity="warning" topSpacing={0} bottomSpacing={1} />}
    </>
  );
}

function VariableLabelInput({ variable, id }: VariableInputProps) {
  const { label } = variable.useState();
  const oldLabel = useRef(label ?? '');

  return (
    <Input
      id={id}
      value={label}
      onFocus={() => {
        oldLabel.current = label ?? '';
      }}
      onChange={(e) => variable.setState({ label: e.currentTarget.value })}
      onBlur={(e) => {
        const labelUnchanged = oldLabel.current === e.currentTarget.value;
        const shouldSkip = labelUnchanged;

        if (shouldSkip) {
          return;
        }

        changeVariableLabel({
          source: variable,
          oldValue: oldLabel.current,
          newValue: e.currentTarget.value,
        });
      }}
      data-testid={selectors.components.PanelEditor.ElementEditPane.variableLabelInput}
    />
  );
}

function VariableDescriptionTextArea({ variable, id }: VariableInputProps) {
  const { description } = variable.useState();
  const oldDescription = useRef(description ?? '');

  return (
    <TextArea
      id={id}
      value={description ?? ''}
      placeholder={t('dashboard.sidebar.variable.description-placeholder', 'Descriptive text')}
      onFocus={() => {
        oldDescription.current = description ?? '';
      }}
      onChange={(e) => variable.setState({ description: e.currentTarget.value })}
      onBlur={(e) => {
        const labelUnchanged = oldDescription.current === e.currentTarget.value;
        const shouldSkip = labelUnchanged;

        if (shouldSkip) {
          return;
        }

        changeVariableDescription({
          source: variable,
          oldValue: oldDescription.current,
          newValue: e.currentTarget.value,
        });
      }}
    />
  );
}

function VariableDisplayInput({ variable }: VariableInputProps) {
  const { hide: display = VariableHide.dontHide } = variable.useState();
  const sectionOwner = dashboardSceneGraph.findSectionOwner(variable);
  const topPlacementLabel = sectionOwner ? getTopPlacementLabel(sectionOwner) : undefined;

  const onChange = (option: VariableHide) => {
    changeVariableHideValue({
      source: variable,
      oldValue: display,
      newValue: option,
    });
  };

  return (
    <VariableDisplaySelect
      display={display}
      type={variable.state.type}
      hideControlsMenuOption={shouldHideControlsMenuOption(variable)}
      topPlacementLabel={topPlacementLabel}
      onChange={onChange}
    />
  );
}

export function shouldHideControlsMenuOption(variable: SceneVariable): boolean {
  const set = variable.parent;
  const dashboardVariable = set instanceof SceneVariableSet && set.parent instanceof DashboardScene;
  return !dashboardVariable;
}

function useVariableTypeCategory(variable: SceneVariable) {
  const oldVariableId = useId();
  const refreshId = useId();
  const newQueryVarEditorEnabled = useFlagGrafanaQueryVarEditorRedesign();

  return useMemo(() => {
    const variableEditorDef = getEditableVariableDefinition(variable.state.type);

    const category = new OptionsPaneCategoryDescriptor({
      title: t('dashboard.sidebar.variable.type-category', '{{type}} options', {
        type: variableEditorDef.name,
      }),
      id: 'variable-type',
      isOpenDefault: true,
    });

    if (variableEditorDef.getOptions) {
      const options = variableEditorDef.getOptions(variable);
      options.forEach((option) => category.addItem(option));
    } else {
      category.addItem(
        new OptionsPaneItemDescriptor({
          title: '',
          id: oldVariableId,
          skipField: true,
          render: () => <OpenOldVariableEditButton variable={variable} />,
        })
      );
    }

    if (newQueryVarEditorEnabled && variable instanceof QueryVariable) {
      category.addItem(
        new OptionsPaneItemDescriptor({
          id: refreshId,
          title: t('variables.query-variable-refresh-select.label-refresh', 'Refresh'),
          description: t(
            'variables.query-variable-refresh-select.description-update-values-variable',
            'When to update the values of this variable'
          ),
          render: () => <RefreshSelect variable={variable} />,
        })
      );
    }

    return category;
  }, [oldVariableId, refreshId, newQueryVarEditorEnabled, variable]);
}

function RefreshSelect({ variable }: { variable: QueryVariable }) {
  const { refresh } = variable.useState();
  const options = useMemo(
    () => [
      {
        label: t('dashboard-scene.refresh-select.options.label.on-dashboard-load', 'On dashboard load'),
        value: VariableRefresh.onDashboardLoad,
      },
      {
        label: t('dashboard-scene.refresh-select.options.label.on-time-range-change', 'On time range change'),
        value: VariableRefresh.onTimeRangeChanged,
      },
    ],
    []
  );
  return (
    <Combobox
      options={options}
      value={refresh}
      onChange={(o) => {
        variable.setState({ refresh: o.value });
      }}
    />
  );
}

function OpenOldVariableEditButton({ variable }: VariableInputProps) {
  const onOpenVariableEdior = () => {
    const set = variable.parent!;
    if (!(set instanceof SceneVariableSet)) {
      return;
    }

    const variableIndex = set.state.variables.indexOf(variable);
    locationService.partial({ editview: 'variables', editIndex: variableIndex });
  };

  return (
    <Box display={'flex'} direction={'column'} paddingBottom={1}>
      <Button
        tooltip={t('dashboard.sidebar.variable.open-editor-tooltip', 'For more variable options open variable editor')}
        onClick={onOpenVariableEdior}
        size="sm"
        fullWidth
      >
        <Trans i18nKey="dashboard.sidebar.variable.open-editor">Open variable editor</Trans>
      </Button>
    </Box>
  );
}

function useLocalVariableOptions(variable: LocalValueVariable): OptionsPaneCategoryDescriptor[] {
  const localVariableOptionsCategoryId = useId();
  const localVariableId = useId();
  return useMemo(() => {
    const category = new OptionsPaneCategoryDescriptor({
      title: '',
      id: localVariableOptionsCategoryId,
    });

    category.addItem(
      new OptionsPaneItemDescriptor({
        title: '',
        id: localVariableId,
        skipField: true,
        render: () => {
          return (
            <Box paddingBottom={1}>
              <Stack>
                <Stack>
                  <span>${variable.state.name}</span>
                  <span>=</span>
                  <span>{variable.getValueText()}</span>
                </Stack>
              </Stack>
            </Box>
          );
        },
      })
    );

    return [category];
  }, [localVariableId, localVariableOptionsCategoryId, variable]);
}
