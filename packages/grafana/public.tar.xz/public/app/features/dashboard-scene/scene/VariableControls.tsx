import { css, cx } from '@emotion/css';
import { useCallback, useMemo, useState } from 'react';

import { type GrafanaTheme2, VariableHide } from '@grafana/data';
import { selectors } from '@grafana/e2e-selectors';
import { config } from '@grafana/runtime';
import {
  ControlsLabel,
  type ControlsLayout,
  sceneGraph,
  sceneUtils,
  type SceneVariable,
  type SceneVariables,
  SceneVariableSet,
  type SceneVariableState,
  useSceneObjectState,
} from '@grafana/scenes';
import { useElementSelection, useStyles2 } from '@grafana/ui';

import { duplicateVariable } from '../actions/variable/duplicateVariable';
import { removeVariable } from '../actions/variable/removeVariable';
import { SourceIcon } from '../settings/ProvisionedControlsSection';
import { VariableEditorModal } from '../settings/variables/editors/VariableEditorModal';
import { isVariableEditable } from '../settings/variables/utils';
import { getPredefinedOrigin } from '../utils/predefinedVariables';
import { filterSectionRepeatLocalVariables } from '../variables/utils';

import { ControlActionsPopover, VariableEditActions } from './ControlActionsPopover';
import { DashboardScene } from './DashboardScene';
import { AddVariableButton } from './VariableControlsAddButton';
import { VariableDescriptionTooltip } from './VariableDescriptionTooltip';
import { useTrackDashboardVariableValueChange } from './useTrackDashboardVariableValueChange';

export function VariableControls({
  dashboard,
  variablesOverride,
}: {
  dashboard: DashboardScene;
  variablesOverride?: SceneVariable[];
}) {
  const { variables: dashboardVariables } = sceneGraph.getVariables(dashboard)!.useState();
  const { isEditing } = dashboard.useState();
  const isEditingNewLayouts = isEditing && config.featureToggles.dashboardNewLayouts;
  const variables = variablesOverride ?? dashboardVariables;

  const visibleVariables = variables.filter(
    (v: SceneVariable) =>
      v.state.hide !== VariableHide.inControlsMenu &&
      (v.state.hide !== VariableHide.hideVariable || v.UNSAFE_renderAsHidden)
  );

  return (
    <>
      {visibleVariables.length > 0 &&
        visibleVariables.map((variable) => (
          <VariableValueSelectWrapper
            key={variable.state.key}
            variable={variable}
            isEditingNewLayouts={isEditingNewLayouts}
          />
        ))}
      {config.featureToggles.dashboardNewLayouts ? <AddVariableButton dashboard={dashboard} /> : null}
    </>
  );
}

interface VariableSelectProps {
  variable: SceneVariable;
  inMenu?: boolean;
  isEditingNewLayouts?: boolean;
}

export function VariableValueSelectWrapper({ variable, inMenu, isEditingNewLayouts }: VariableSelectProps) {
  const styles = useStyles2(getStyles);
  const state = useSceneObjectState<SceneVariableState>(variable, { shouldActivateOrKeepAlive: true });
  const { isSelected, isSelectable } = useElementSelection(variable.state.key);
  const isHidden = state.hide === VariableHide.hideVariable;
  const canEditControl = Boolean(isSelectable) && isVariableEditable(variable);
  const isReadOnlyControl = Boolean(isEditingNewLayouts) && !isVariableEditable(variable);
  const { markUserInitiated } = useTrackDashboardVariableValueChange(variable);

  const onClickEditVariable = useCallback(() => {
    const dashboard = sceneGraph.getAncestor(variable, DashboardScene);
    dashboard.state.sidebar.selectObject(variable);
  }, [variable]);

  const [isEditorOpen, setIsEditorOpen] = useState(false);

  const onClickEditVariableQuery = useCallback(() => {
    setIsEditorOpen(true);
  }, []);

  const onClickDeleteVariable = useCallback(() => {
    const set = variable.parent;
    if (set instanceof SceneVariableSet) {
      removeVariable({ source: set, removedObject: variable });
    }
  }, [variable]);

  const onClickDuplicateVariable = useCallback(() => {
    duplicateVariable(variable);
  }, [variable]);

  const editActions = useMemo(
    () => (
      <VariableEditActions
        variable={variable}
        onClickEdit={onClickEditVariable}
        onClickEditQuery={onClickEditVariableQuery}
        onClickDuplicate={onClickDuplicateVariable}
        onClickDelete={onClickDeleteVariable}
      />
    ),
    [variable, onClickDeleteVariable, onClickDuplicateVariable, onClickEditVariableQuery, onClickEditVariable]
  );

  const editorModal = isEditorOpen ? (
    <VariableEditorModal variable={variable} onClose={() => setIsEditorOpen(false)} />
  ) : null;

  // UNSAFE_renderAsHidden variables (like ScopesVariable) should always render invisibly
  if (isHidden && variable.UNSAFE_renderAsHidden) {
    return <variable.Component model={variable} />;
  }

  if (isHidden && !isEditingNewLayouts) {
    return null;
  }

  // For switch variables in menu, we want to show the switch on the left and the label on the right
  if (inMenu && sceneUtils.isSwitchVariable(variable)) {
    return (
      <>
        {editorModal}
        <ControlActionsPopover isEditable={canEditControl} content={editActions}>
          <div
            className={cx(
              styles.switchMenuContainer,
              isSelected && 'dashboard-selected-element',
              isSelectable && !isSelected && 'dashboard-selectable-element',
              isReadOnlyControl && styles.readOnlyControl
            )}
            data-testid={selectors.pages.Dashboard.SubMenu.submenuItem}
            data-dashboard-element-key={variable.state.key}
            data-dashboard-element-type="variable"
            onPointerDown={markUserInitiated}
          >
            <div className={styles.switchControl}>
              <variable.Component model={variable} />
            </div>
            <VariableLabel
              variable={variable}
              layout={'vertical'}
              className={cx(isSelectable && styles.labelSelectable, styles.switchLabel)}
            />
          </div>
        </ControlActionsPopover>
      </>
    );
  }

  if (inMenu) {
    return (
      <>
        {editorModal}
        <ControlActionsPopover isEditable={canEditControl} content={editActions}>
          <div
            className={cx(
              styles.verticalContainer,
              isSelected && 'dashboard-selected-element',
              isSelectable && !isSelected && 'dashboard-selectable-element',
              isReadOnlyControl && styles.readOnlyControl
            )}
            data-testid={selectors.pages.Dashboard.SubMenu.submenuItem}
            data-dashboard-element-key={variable.state.key}
            data-dashboard-element-type="variable"
            onPointerDown={markUserInitiated}
          >
            <VariableLabel
              variable={variable}
              layout={'vertical'}
              className={cx(isSelectable && styles.labelSelectable)}
            />
            <variable.Component model={variable} />
          </div>
        </ControlActionsPopover>
      </>
    );
  }

  return (
    <>
      {editorModal}
      <ControlActionsPopover isEditable={canEditControl} content={editActions}>
        <div
          className={cx(
            styles.container,
            isSelected && 'dashboard-selected-element',
            isSelectable && !isSelected && 'dashboard-selectable-element',
            isReadOnlyControl && styles.readOnlyControl
          )}
          data-testid={selectors.pages.Dashboard.SubMenu.submenuItem}
          data-dashboard-element-key={variable.state.key}
          data-dashboard-element-type="variable"
          onPointerDown={markUserInitiated}
        >
          <VariableLabel variable={variable} className={cx(isSelectable && styles.labelSelectable, styles.label)} />
          <variable.Component model={variable} />
        </div>
      </ControlActionsPopover>
    </>
  );
}

function VariableLabel({
  variable,
  className,
  layout,
}: {
  variable: SceneVariable;
  className?: string;
  layout?: ControlsLayout;
}) {
  const { state } = variable;
  const elementId = sceneUtils.getVariableControlId(state.type, state.key);

  if (variable.state.hide === VariableHide.hideLabel) {
    return null;
  }

  const labelOrName = state.label || state.name;
  const controlsLayout = layout ?? 'horizontal';
  const placement = controlsLayout === 'vertical' ? 'top' : 'bottom';
  const hasDescription = state.description != null && state.description !== '';
  const predefinedOrigin = getPredefinedOrigin(state.origin);
  const suffix =
    hasDescription || predefinedOrigin ? (
      <>
        {predefinedOrigin && <SourceIcon origin={state.origin} />}
        {hasDescription && <VariableDescriptionTooltip description={state.description!} placement={placement} />}
      </>
    ) : undefined;

  return (
    <ControlsLabel
      htmlFor={elementId}
      isLoading={state.loading}
      onCancel={() => variable.onCancel?.()}
      label={labelOrName}
      error={state.error}
      layout={controlsLayout}
      description={undefined}
      suffix={suffix}
      className={className}
    />
  );
}

export function SectionVariableControls({ variableSet }: { variableSet: SceneVariables }) {
  const { variables } = variableSet.useState();
  const styles = useStyles2(getSectionVariableStyles);

  const visibleVariables = filterSectionRepeatLocalVariables(variables, variableSet).filter(
    (v) => v.state.hide !== VariableHide.hideVariable
  );

  if (visibleVariables.length === 0) {
    return null;
  }

  return (
    // Prevent row selection on click (see RowItemRenderer onPointerUp)
    // eslint-disable-next-line jsx-a11y/no-static-element-interactions
    <div
      className={styles.sectionVariables}
      onPointerDown={(e) => e.stopPropagation()}
      onPointerUp={(e) => e.stopPropagation()}
    >
      {visibleVariables.map((variable) => (
        <VariableValueSelectWrapper key={variable.state.key} variable={variable} />
      ))}
    </div>
  );
}

const getSectionVariableStyles = (theme: GrafanaTheme2) => ({
  sectionVariables: css({
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: theme.spacing(1),
    marginBottom: theme.spacing(1),
  }),
});

const getStyles = (theme: GrafanaTheme2) => ({
  container: css({
    display: 'inline-flex',
    alignItems: 'center',
    verticalAlign: 'middle',
    // No border for second element (inputs) as label and input border is shared
    '> :nth-child(2)': css({
      borderTopLeftRadius: 'unset',
      borderBottomLeftRadius: 'unset',
    }),
    marginBottom: theme.spacing(1),
    marginRight: theme.spacing(1),
  }),
  verticalContainer: css({
    display: 'flex',
    flexDirection: 'column',
    padding: theme.spacing(1),
  }),
  switchMenuContainer: css({
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(1),
    padding: theme.spacing(1),
  }),
  switchControl: css({
    '& > div': {
      border: 'none',
      background: 'transparent',
      paddingRight: theme.spacing(0.5),
      height: theme.spacing(2),
    },
  }),
  switchLabel: css({
    marginTop: 0,
    marginBottom: 0,
  }),
  labelSelectable: css({
    cursor: 'pointer',
  }),
  label: css({
    display: 'flex',
    alignItems: 'center',
  }),
  readOnlyControl: css({
    opacity: 0.65,
    cursor: 'default',
    '&:hover': {
      color: 'inherit',
    },
  }),
});
