import { useMemo, useRef } from 'react';

import { selectors } from '@grafana/e2e-selectors';
import { Trans, t } from '@grafana/i18n';
import { config } from '@grafana/runtime';
import { Alert, Field, Input, TextLink } from '@grafana/ui';
import { OptionsPaneCategoryDescriptor } from 'app/features/dashboard/components/PanelEditor/OptionsPaneCategoryDescriptor';
import { OptionsPaneItemDescriptor } from 'app/features/dashboard/components/PanelEditor/OptionsPaneItemDescriptor';
import { RepeatRowSelect2 } from 'app/features/dashboard/components/RepeatRowSelect/RepeatRowSelect';
import { SHARED_DASHBOARD_QUERY } from 'app/plugins/datasource/dashboard/constants';
import { MIXED_DATASOURCE_NAME } from 'app/plugins/datasource/mixed/MixedDataSource';

import { edit } from '../../actions/utils/edit';
import { useConditionalRenderingEditor } from '../../conditional-rendering/hooks/useConditionalRenderingEditor';
import { SectionFiltersCategoryTitle, SectionFiltersList } from '../../sidebar/SectionFiltersList';
import { SectionVariablesCategoryTitle, SectionVariablesList } from '../../sidebar/SectionVariablesList';
import { SidebarCategoryType } from '../../sidebar/types';
import { getQueryRunnerFor } from '../../utils/utils';
import { useLayoutCategory } from '../layouts-shared/DashboardLayoutSelector';
import { generateUniqueTitle, useSidebarInputAutoFocus } from '../layouts-shared/utils';

import { type TabItem } from './TabItem';

export function useSidebarOptions(this: TabItem, isNewElement: boolean): OptionsPaneCategoryDescriptor[] {
  const model = this;
  const { layout } = model.useState();

  const tabCategory = useMemo(
    () =>
      new OptionsPaneCategoryDescriptor({ title: '', id: 'tab-item-options' }).addItem(
        new OptionsPaneItemDescriptor({
          title: t('dashboard.tabs-layout.tab-options.title-option', 'Title'),
          id: 'tab-options-title',
          render: (descriptor) => <TabTitleInput id={descriptor.props.id} tab={model} isNewElement={isNewElement} />,
        })
      ),
    [isNewElement, model]
  );

  const repeatCategory = useMemo(
    () =>
      new OptionsPaneCategoryDescriptor({
        title: t('dashboard.tabs-layout.tab-options.repeat.title', 'Repeat options'),
        id: 'repeat-options',
        isOpenDefault: false,
      }).addItem(
        new OptionsPaneItemDescriptor({
          title: t('dashboard.tabs-layout.tab-options.repeat.variable.title', 'Repeat by variable'),
          id: 'tab-options-repeat-variable',
          description: t(
            'dashboard.tabs-layout.tab-options.repeat.variable.description',
            'Repeat this tab for each value in the selected variable.'
          ),
          render: (descriptor) => <TabRepeatSelect id={descriptor.props.id} tab={model} />,
        })
      ),
    [model]
  );

  const layoutCategory = useLayoutCategory(layout);

  const sectionVariablesCategory = useMemo(() => {
    const category = new OptionsPaneCategoryDescriptor({
      title: t('dashboard.tabs-layout.tab-options.section-variables.title', 'Variables'),
      id: SidebarCategoryType.TabSectionVariables,
      isOpenDefault: true,
      renderTitle: (isExpanded: boolean) => (
        <SectionVariablesCategoryTitle sectionOwner={model} isExpanded={isExpanded} />
      ),
    });

    category.addItem(
      new OptionsPaneItemDescriptor({
        title: '',
        id: SidebarCategoryType.TabSectionVariablesList,
        skipField: true,
        render: () => <SectionVariablesList sectionOwner={model} />,
      })
    );

    return category;
  }, [model]);

  const sectionFiltersCategory = useMemo(() => {
    const category = new OptionsPaneCategoryDescriptor({
      title: t('dashboard.tabs-layout.tab-options.section-filters.title', 'Filters'),
      id: SidebarCategoryType.TabSectionFilters,
      isOpenDefault: true,
      renderTitle: () => <SectionFiltersCategoryTitle />,
    });

    category.addItem(
      new OptionsPaneItemDescriptor({
        title: '',
        id: SidebarCategoryType.TabSectionFiltersList,
        skipField: true,
        render: () => <SectionFiltersList sectionOwner={model} />,
      })
    );

    return category;
  }, [model]);

  const editOptions = [
    tabCategory,
    ...(config.featureToggles.dashboardUnifiedDrilldownControls ? [sectionFiltersCategory] : []),
    sectionVariablesCategory,
    ...layoutCategory,
    repeatCategory,
  ];

  const conditionalRenderingCategory = useMemo(
    () => useConditionalRenderingEditor(model.state.conditionalRendering),
    [model]
  );

  if (conditionalRenderingCategory) {
    editOptions.push(conditionalRenderingCategory);
  }

  return editOptions;
}

function TabTitleInput({ tab, isNewElement, id }: { tab: TabItem; isNewElement: boolean; id?: string }) {
  const { title } = tab.useState();
  const prevTitle = useRef('');

  const ref = useSidebarInputAutoFocus({ autoFocus: isNewElement });
  const hasUniqueTitle = tab.hasUniqueTitle();

  return (
    <Field
      invalid={!hasUniqueTitle}
      error={
        !hasUniqueTitle ? t('dashboard.tabs-layout.tab-options.title-not-unique', 'Title should be unique') : undefined
      }
    >
      <Input
        id={id}
        ref={ref}
        title={t('dashboard.tabs-layout.tab-options.title-option', 'Title')}
        value={title}
        onFocus={() => (prevTitle.current = title || '')}
        onBlur={() => editTabTitleAction(tab, title || '', prevTitle.current || '')}
        onChange={(e) => tab.onChangeTitle(e.currentTarget.value)}
        data-testid={selectors.components.PanelEditor.ElementEditPane.TabsLayout.titleInput}
      />
    </Field>
  );
}

function TabRepeatSelect({ tab, id }: { tab: TabItem; id?: string }) {
  const { layout } = tab.useState();

  const isAnyPanelUsingDashboardDS = layout.getVizPanels().some((vizPanel) => {
    const runner = getQueryRunnerFor(vizPanel);
    return (
      runner?.state.datasource?.uid === SHARED_DASHBOARD_QUERY ||
      (runner?.state.datasource?.uid === MIXED_DATASOURCE_NAME &&
        runner?.state.queries.some((query) => query.datasource?.uid === SHARED_DASHBOARD_QUERY))
    );
  });

  return (
    <>
      <RepeatRowSelect2
        id={id}
        sceneContext={tab}
        repeat={tab.state.repeatByVariable}
        onChange={(repeat) => tab.onChangeRepeat(repeat)}
      />
      {isAnyPanelUsingDashboardDS ? (
        <Alert
          data-testid={selectors.pages.Dashboard.Rows.Repeated.ConfigSection.warningMessage}
          severity="warning"
          title=""
          topSpacing={3}
          bottomSpacing={0}
        >
          <p>
            <Trans i18nKey="dashboard.tabs-layout.tab.repeat.warning">
              Panels in this tab use the {{ SHARED_DASHBOARD_QUERY }} data source. These panels will reference the panel
              in the original tab, not the ones in the repeated tabs.
            </Trans>
          </p>
          <TextLink
            external
            href={
              'https://grafana.com/docs/grafana/next/visualizations/dashboards/build-dashboards/create-dashboard/#repeating-rows-and-tabs-and-the-dashboard-special-data-source'
            }
          >
            <Trans i18nKey="dashboard.tabs-layout.tab.repeat.learn-more">Learn more</Trans>
          </TextLink>
        </Alert>
      ) : undefined}
    </>
  );
}

function editTabTitleAction(tab: TabItem, title: string, prevTitle: string) {
  if (title !== '' && title === prevTitle) {
    return;
  }

  if (title === '') {
    const tabs = tab.getParentLayout().getTabsIncludingRepeats();
    const existingNames = new Set(tabs.map((tab) => tab.state.title).filter((title) => title !== undefined));
    title = generateUniqueTitle('New tab', existingNames);
  }

  edit({
    description: t('dashboard.edit-actions.tab-title', 'Change tab title'),
    source: tab,
    perform: () => tab.onChangeTitle(title),
    undo: () => tab.onChangeTitle(prevTitle),
  });
}
