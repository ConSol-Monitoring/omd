import { type SceneDataState, sceneGraph, type SceneVariable } from '@grafana/scenes';
import { type DashboardLink, VariableHide } from '@grafana/schema';

import { isDashboardDataLayerSetState } from '../DashboardDataLayerSet';
import { type DashboardScene } from '../DashboardScene';

function getDashboardControlsLinks(links: DashboardLink[]) {
  return links.filter((link) => link.placement === 'inControlsMenu');
}

function getDashboardControlsVariables(variables: SceneVariable[]) {
  return variables.filter((v) => v.state.hide === VariableHide.inControlsMenu);
}

function getDashboardControlsAnnotations(dataState: SceneDataState) {
  return (isDashboardDataLayerSetState(dataState) ? dataState.annotationLayers : []).filter(
    (layer) => layer.state.placement === 'inControlsMenu' && !layer.state.isHidden
  );
}

function getDashboardControls(dashboard: DashboardScene) {
  const variables = getDashboardControlsVariables(sceneGraph.getVariables(dashboard)?.state.variables);
  const links = getDashboardControlsLinks(dashboard.state.links);
  const annotations = getDashboardControlsAnnotations(sceneGraph.getData(dashboard).state);

  return {
    variables,
    links,
    annotations,
  };
}

export function useDashboardControls(dashboard: DashboardScene) {
  const dashboardState = dashboard.useState();

  const variablesState = sceneGraph.getVariables(dashboard).useState();
  const variables = getDashboardControlsVariables(variablesState.variables);

  const dataState = sceneGraph.getData(dashboard).useState();
  const links = getDashboardControlsLinks(dashboardState.links);
  const annotations = getDashboardControlsAnnotations(dataState);

  return {
    variables,
    links,
    annotations,
  };
}

export function useHasDashboardControls(dashboard: DashboardScene) {
  const { variables, links, annotations } = useDashboardControls(dashboard);

  return variables.length > 0 || links.length > 0 || annotations.length > 0;
}

export function hasDashboardControls(dashboard: DashboardScene) {
  const { variables, links, annotations } = getDashboardControls(dashboard);

  return variables.length > 0 || links.length > 0 || annotations.length > 0;
}
