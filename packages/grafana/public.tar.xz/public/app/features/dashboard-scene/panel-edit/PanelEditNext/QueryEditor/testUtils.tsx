import { OpenFeatureProvider } from '@openfeature/react-sdk';
import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { type ReactElement, type ReactNode, useMemo, useState } from 'react';

import { type DataSourceInstanceSettings, getDefaultTimeRange, LoadingState, PluginType } from '@grafana/data';
import { VizPanel } from '@grafana/scenes';
import { type DataQuery } from '@grafana/schema';
import { getTestFeatureFlagClient } from '@grafana/test-utils/unstable';
import { type QueryGroupOptions } from 'app/types/query';

import { QueryEditorType } from '../constants';

import {
  type AlertingState,
  type DatasourceState,
  type PanelState,
  type QueryEditorActions,
  QueryEditorProvider,
  type QueryEditorTypeConfigState,
  type QueryEditorUIState,
  type QueryOptionsState,
  type QueryRunnerState,
  type StackedEditorState,
} from './QueryEditorContext';
import { type Transformation } from './types';

export const ds1SettingsMock: DataSourceInstanceSettings = {
  id: 1,
  uid: 'test',
  name: 'Test DS',
  type: 'test',
  meta: {
    id: 'test',
    name: 'Test',
    type: PluginType.datasource,
    info: {
      author: { name: '' },
      description: '',
      links: [],
      logos: { small: 'test-logo.png', large: '' },
      screenshots: [],
      updated: '',
      version: '',
    },
    module: '',
    baseUrl: '',
  },
  access: 'proxy',
  readOnly: false,
  jsonData: {},
};

export const dashboardDsSettingsMock: DataSourceInstanceSettings = {
  id: 99,
  uid: '-- Dashboard --',
  name: '-- Dashboard --',
  type: 'datasource',
  meta: {
    id: 'dashboard',
    name: '-- Dashboard --',
    type: PluginType.datasource,
    info: {
      author: { name: '' },
      description: '',
      links: [],
      logos: { small: '', large: '' },
      screenshots: [],
      updated: '',
      version: '',
    },
    module: '',
    baseUrl: '',
  },
  access: 'proxy',
  readOnly: false,
  jsonData: {},
};

export const mockActions: QueryEditorActions = {
  updateQueries: jest.fn(),
  updateSelectedQuery: jest.fn(),
  addQuery: jest.fn(),
  deleteQuery: jest.fn(),
  duplicateQuery: jest.fn(),
  runQueries: jest.fn(),
  changeDataSource: jest.fn(),
  toggleQueryHide: jest.fn(),
  onQueryOptionsChange: jest.fn(),
  addTransformation: jest.fn(),
  deleteTransformation: jest.fn(),
  toggleTransformationDisabled: jest.fn(),
  updateTransformation: jest.fn(),
  reorderTransformations: jest.fn(),
  bulkDeleteQueries: jest.fn(),
  bulkToggleQueriesHide: jest.fn(),
  bulkDeleteTransformations: jest.fn(),
  bulkToggleTransformationsDisabled: jest.fn(),
  bulkChangeDataSource: jest.fn(),
};

export const mockOptions: QueryGroupOptions = {
  queries: [],
  dataSource: { type: undefined, uid: undefined },
  maxDataPoints: undefined,
  minInterval: undefined,
  timeRange: {
    from: undefined,
    shift: undefined,
    hide: undefined,
  },
};

export const mockQueryOptionsState: QueryOptionsState = {
  options: mockOptions,
  isQueryOptionsOpen: false,
  openSidebar: jest.fn(),
  closeSidebar: jest.fn(),
  focusedField: null,
};

/**
 * Builds a fresh `StackedEditorState` for tests. Defaults to the natural "off" state; callers
 * pass overrides for the fields they care about (e.g. `{ enabled: true, enter: jest.fn() }`).
 * Each call returns new `jest.fn()` mocks so assertions don't leak between tests.
 */
export function makeStackedMode(overrides: Partial<StackedEditorState> = {}): StackedEditorState {
  return {
    enabled: false,
    enter: jest.fn(),
    exit: jest.fn(),
    syncActiveItem: jest.fn(),
    ...overrides,
  };
}

export const mockUIStateBase = {
  selectedQueryDsData: null,
  selectedQueryDsLoading: false,
  showingDatasourceHelp: false,
  toggleDatasourceHelp: jest.fn(),
  cardType: QueryEditorType.Query,
  queryOptions: mockQueryOptionsState,
  pendingExpression: null,
  setPendingExpression: jest.fn(),
  finalizePendingExpression: jest.fn(),
  pendingTransformation: null,
  setPendingTransformation: jest.fn(),
  finalizePendingTransformation: jest.fn(),
  selectedQueryRefIds: [] satisfies readonly string[],
  selectedTransformationIds: [] satisfies readonly string[],
  multiSelectMode: false,
  toggleQuerySelection: jest.fn(),
  toggleTransformationSelection: jest.fn(),
  clearSelection: jest.fn(),
  setMultiSelectMode: jest.fn(),
  stackedMode: makeStackedMode(),
  confirmingDeleteActionKey: null,
  setConfirmingDeleteActionKey: jest.fn(),
};

export const mockTransformToggles = {
  showHelp: false,
  toggleHelp: jest.fn(),
  showDebug: false,
  toggleDebug: jest.fn(),
};

/**
 * Mock typeConfig for tests - uses placeholder colors since tests don't need real theme values
 */
export const mockTypeConfig: QueryEditorTypeConfigState = {
  [QueryEditorType.Query]: {
    icon: 'database',
    color: '#ff9800',
    getLabel: () => 'Query',
    deleteConfirmation: true,
  },
  [QueryEditorType.Expression]: {
    icon: 'calculator-alt',
    color: '#9c27b0',
    getLabel: () => 'Expression',
    deleteConfirmation: true,
  },
  [QueryEditorType.Transformation]: {
    icon: 'process',
    color: '#4caf50',
    getLabel: () => 'Transformation',
    deleteConfirmation: true,
  },
  [QueryEditorType.Alert]: {
    icon: 'bell',
    color: '#666',
    getLabel: () => 'Alert',
    deleteConfirmation: false,
  },
};

interface CreateQueryEditorProviderOptions {
  queries?: DataQuery[];
  transformations?: Transformation[];
  selectedQuery?: DataQuery | null;
  selectedTransformation?: Transformation | null;
  uiStateOverrides?: Partial<QueryEditorUIState>;
  actionsOverrides?: Partial<QueryEditorActions>;
  dsState?: Partial<DatasourceState>;
  qrState?: Partial<QueryRunnerState>;
  panelState?: Partial<PanelState>;
  alertingState?: Partial<AlertingState>;
}

/**
 * Wires the inline-delete confirmation state with real React state so tests exercise the same
 * flow as production. Tests can still override `confirmingDeleteActionKey` / `setConfirmingDeleteActionKey`
 * via `uiStateOverrides` for edge cases.
 */
function StatefulConfirmationProvider({
  uiState,
  children,
  render,
}: {
  uiState: QueryEditorUIState;
  children: ReactNode;
  render: (uiState: QueryEditorUIState, children: ReactNode) => ReactElement;
}) {
  const [confirmingDeleteActionKey, setConfirmingDeleteActionKey] = useState<string | null>(
    uiState.confirmingDeleteActionKey ?? null
  );

  const wiredUiState = useMemo<QueryEditorUIState>(
    () => ({
      ...uiState,
      confirmingDeleteActionKey,
      setConfirmingDeleteActionKey,
    }),
    [uiState, confirmingDeleteActionKey]
  );

  return render(wiredUiState, children);
}

/**
 * Test helper to create a QueryEditorProvider with sensible defaults.
 * Pass only the props you need to customize.
 *
 * @example
 * const { user, ...result } = renderWithQueryEditorProvider(
 *   <MyComponent />,
 *   { queries: [mockQuery], selectedQuery: mockQuery }
 * );
 */
export function renderWithQueryEditorProvider(children: ReactElement, options: CreateQueryEditorProviderOptions = {}) {
  const {
    queries = [],
    transformations = [],
    selectedQuery = null,
    selectedTransformation = null,
    uiStateOverrides = {},
    actionsOverrides = {},
    dsState = {},
    qrState = {},
    panelState = {},
    alertingState = {},
  } = options;

  const defaultDsState: DatasourceState = {
    datasource: undefined,
    dsSettings: undefined,
    dsError: undefined,
    ...dsState,
  };

  const defaultQrState: QueryRunnerState = {
    queries,
    data: {
      state: LoadingState.Done,
      series: [],
      timeRange: getDefaultTimeRange(),
    },
    queryError: undefined,
    ...qrState,
  };

  const defaultPanelState: PanelState = {
    panel: new VizPanel({ key: 'panel-1' }),
    transformations,
    ...panelState,
  };

  const defaultUiState: QueryEditorUIState = {
    selectedQuery,
    selectedTransformation,
    selectedQueryRefIds: [],
    selectedTransformationIds: [],
    multiSelectMode: false,
    setSelectedQuery: jest.fn(),
    setSelectedTransformation: jest.fn(),
    setMultiSelectMode: jest.fn(),
    toggleQuerySelection: jest.fn(),
    toggleTransformationSelection: jest.fn(),
    clearSelection: jest.fn(),
    queryOptions: mockQueryOptionsState,
    selectedQueryDsData: null,
    selectedQueryDsLoading: false,
    showingDatasourceHelp: false,
    toggleDatasourceHelp: jest.fn(),
    transformToggles: mockTransformToggles,
    cardType: selectedTransformation ? QueryEditorType.Transformation : QueryEditorType.Query,
    pendingExpression: null,
    setPendingExpression: jest.fn(),
    finalizePendingExpression: jest.fn(),
    pendingTransformation: null,
    setPendingTransformation: jest.fn(),
    finalizePendingTransformation: jest.fn(),
    stackedMode: makeStackedMode(),
    selectedAlert: null,
    setSelectedAlert: jest.fn(),
    pendingSavedQuery: null,
    setPendingSavedQuery: jest.fn(),
    showVersionBanner: false,
    confirmingDeleteActionKey: null,
    setConfirmingDeleteActionKey: jest.fn(),
    ...uiStateOverrides,
  };

  const defaultActions: QueryEditorActions = {
    ...mockActions,
    ...actionsOverrides,
  };

  const defaultAlertingState: AlertingState = {
    alertRules: [],
    loading: false,
    isDashboardSaved: true,
    ...alertingState,
  };

  return {
    user: userEvent.setup({ pointerEventsCheck: 0 }),
    ...render(
      <OpenFeatureProvider client={getTestFeatureFlagClient()}>
        <StatefulConfirmationProvider
          uiState={defaultUiState}
          render={(wiredUiState, wiredChildren) => (
            <QueryEditorProvider
              dsState={defaultDsState}
              qrState={defaultQrState}
              panelState={defaultPanelState}
              uiState={wiredUiState}
              actions={defaultActions}
              alertingState={defaultAlertingState}
              typeConfig={mockTypeConfig}
            >
              {wiredChildren}
            </QueryEditorProvider>
          )}
        >
          {children}
        </StatefulConfirmationProvider>
      </OpenFeatureProvider>
    ),
  };
}
