import { screen, within } from '@testing-library/react';
import { render } from 'test/test-utils';

import { type DataSourceInstanceListItem } from '@grafana/data';
import { config } from '@grafana/runtime';
import { useDataSourceInstanceList } from '@grafana/runtime/unstable';
import { setTestFlags } from '@grafana/test-utils/unstable';
import { contextSrv } from 'app/core/services/context_srv';
import { ManagerKind } from 'app/features/apiserver/types';
import { getDashboardTemplatesTab } from 'app/features/dashboard/dashgrid/DashboardLibrary/enterprise-components/DashboardTemplatesTabExtension';
import { useDashboardGenerationAvailable } from 'app/features/dashboard-prompt/useDashboardGenerationAvailable';
import { useIsProvisionedInstance } from 'app/features/provisioning/hooks/useIsProvisionedInstance';
import { AccessControlAction } from 'app/types/accessControl';
import { type FolderDTO } from 'app/types/folders';

import { mockFolderDTO } from '../fixtures/folder.fixture';

import CreateNewButton from './CreateNewButton';

jest.mock('app/features/provisioning/hooks/useIsProvisionedInstance', () => ({
  useIsProvisionedInstance: jest.fn(),
}));

jest.mock(
  'app/features/dashboard/dashgrid/DashboardLibrary/enterprise-components/DashboardTemplatesTabExtension',
  () => ({
    getDashboardTemplatesTab: jest.fn(() => null),
  })
);

const mockGetDashboardTemplatesTab = jest.mocked(getDashboardTemplatesTab);

const defaultTestDataSource = {
  name: 'Test Data Source',
  uid: 'test-data-source-uid',
  type: 'grafana-testdata-datasource',
} as DataSourceInstanceListItem;

jest.mock('@grafana/runtime/unstable', () => ({
  ...jest.requireActual('@grafana/runtime/unstable'),
  useDataSourceInstanceList: jest.fn(() => ({ isLoading: false, items: [] })),
}));

jest.mock('app/features/dashboard-prompt/useDashboardGenerationAvailable', () => ({
  useDashboardGenerationAvailable: jest.fn(),
}));

// Stub the lazy-loaded modal: this suite covers the menu wiring, not the prompt itself.
jest.mock('app/features/dashboard-prompt/GenerateDashboardModal', () => ({
  GenerateDashboardModal: ({ onDismiss }: { onDismiss: () => void }) => (
    <div data-testid="generate-dashboard-modal">
      <button onClick={onDismiss}>Close prompt</button>
    </div>
  ),
}));

const mockUseDataSourceInstanceList = jest.mocked(useDataSourceInstanceList);
const mockUseDashboardGenerationAvailable = jest.mocked(useDashboardGenerationAvailable);

const mockUseIsProvisionedInstance = useIsProvisionedInstance as jest.MockedFunction<typeof useIsProvisionedInstance>;

const mockParentFolder = mockFolderDTO();

async function renderAndOpen(folder?: FolderDTO) {
  const { user } = render(
    <CreateNewButton canCreateDashboard canCreateFolder parentFolder={folder} isReadOnlyRepo={false} />
  );
  const newButton = screen.getByText('New');
  await user.click(newButton);
}

describe('NewActionsButton', () => {
  beforeEach(() => {
    mockUseIsProvisionedInstance.mockReturnValue(false);
    mockUseDashboardGenerationAvailable.mockReturnValue(false);
  });
  it('should display the correct urls with a given parent folder', async () => {
    await renderAndOpen(mockParentFolder);

    expect(screen.getByRole('menuitem', { name: 'New dashboard' })).toHaveAttribute(
      'href',
      `/dashboard/new?folderUid=${mockParentFolder.uid}`
    );
    expect(screen.getByRole('menuitem', { name: 'Import dashboard' })).toHaveAttribute(
      'href',
      `/dashboard/import?folderUid=${mockParentFolder.uid}`
    );
  });

  it('should display urls without params when there is no parent folder', async () => {
    await renderAndOpen();

    expect(screen.getByRole('menuitem', { name: 'New dashboard' })).toHaveAttribute('href', '/dashboard/new');
    expect(screen.getByRole('menuitem', { name: 'Import dashboard' })).toHaveAttribute('href', '/dashboard/import');
  });

  it('clicking the "New folder" button opens the drawer', async () => {
    const { user } = render(
      <CreateNewButton canCreateDashboard canCreateFolder parentFolder={mockParentFolder} isReadOnlyRepo={false} />
    );

    const newButton = screen.getByText('New');
    await user.click(newButton);
    await user.click(screen.getByRole('menuitem', { name: 'New folder' }));

    const drawer = screen.getByRole('dialog', { name: 'New folder' });
    expect(drawer).toBeInTheDocument();
    expect(within(drawer).getByRole('heading', { name: 'New folder' })).toBeInTheDocument();
    expect(within(drawer).getByText(`Location: ${mockParentFolder.title}`)).toBeInTheDocument();
  });

  it('renders dashboard items under a Dashboard group', async () => {
    await renderAndOpen();

    const dashboardGroup = screen.getByRole('group', { name: 'Dashboard' });
    expect(within(dashboardGroup).getByRole('menuitem', { name: 'New dashboard' })).toBeInTheDocument();
    expect(within(dashboardGroup).getByRole('menuitem', { name: 'Import dashboard' })).toBeInTheDocument();
  });

  it('should only render dashboard items when folder creation is disabled', async () => {
    const { user } = render(<CreateNewButton canCreateDashboard canCreateFolder={false} isReadOnlyRepo={false} />);
    const newButton = screen.getByText('New');
    await user.click(newButton);

    expect(screen.getByRole('menuitem', { name: 'New dashboard' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'Import dashboard' })).toBeInTheDocument();
    expect(screen.queryByRole('menuitem', { name: 'New folder' })).not.toBeInTheDocument();
  });

  it('should only render folder item when dashboard creation is disabled', async () => {
    const { user } = render(<CreateNewButton canCreateDashboard={false} canCreateFolder isReadOnlyRepo={false} />);
    const newButton = screen.getByText('New');
    await user.click(newButton);

    expect(screen.queryByRole('menuitem', { name: 'New dashboard' })).not.toBeInTheDocument();
    expect(screen.queryByRole('menuitem', { name: 'Import dashboard' })).not.toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'New folder' })).toBeInTheDocument();
  });

  it('should show Import dashboard button when folder is provisioned', async () => {
    const provisionedFolder = mockFolderDTO(1, { managedBy: ManagerKind.Repo });
    await renderAndOpen(provisionedFolder);

    expect(screen.getByRole('menuitem', { name: 'New dashboard' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'New folder' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'Import dashboard' })).toBeInTheDocument();
  });

  it('should show Import dashboard button when folder is not provisioned', async () => {
    const regularFolder = mockFolderDTO(1, { managedBy: undefined });
    await renderAndOpen(regularFolder);

    expect(screen.getByRole('menuitem', { name: 'New dashboard' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'New folder' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'Import dashboard' })).toBeInTheDocument();
  });

  it('should show Import dashboard button when entire instance is provisioned', async () => {
    mockUseIsProvisionedInstance.mockReturnValue(true);
    const regularFolder = mockFolderDTO(1, { managedBy: undefined });
    await renderAndOpen(regularFolder);

    expect(screen.getByRole('menuitem', { name: 'New dashboard' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'New folder' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'Import dashboard' })).toBeInTheDocument();
  });

  it('should show Import dashboard button when both instance and folder are provisioned', async () => {
    mockUseIsProvisionedInstance.mockReturnValue(true);
    const provisionedFolder = mockFolderDTO(1, { managedBy: ManagerKind.Repo });
    await renderAndOpen(provisionedFolder);

    expect(screen.getByRole('menuitem', { name: 'New dashboard' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'New folder' })).toBeInTheDocument();
    expect(screen.getByRole('menuitem', { name: 'Import dashboard' })).toBeInTheDocument();
  });

  describe('Dashboard from template button', () => {
    let originalPermissions: typeof contextSrv.user.permissions;

    beforeEach(() => {
      config.featureToggles.dashboardTemplates = true;
      // Reset to defaults: a test datasource is available, custom templates are off.
      mockUseDataSourceInstanceList.mockReturnValue({ isLoading: false, items: [defaultTestDataSource] });
      mockGetDashboardTemplatesTab.mockReturnValue(null);
      setTestFlags({ 'grafana.customDashboardTemplates': false });
      // Custom templates require dashboardtemplates:read; grant it by default (grafana-provisioned
      // templates don't depend on it).
      originalPermissions = contextSrv.user.permissions;
      contextSrv.user.permissions = { [AccessControlAction.DashboardTemplatesRead]: true };
    });

    afterEach(() => {
      contextSrv.user.permissions = originalPermissions;
    });

    it('should show a `Use template` button when the feature flag is enabled', async () => {
      await renderAndOpen();
      expect(screen.getByRole('menuitem', { name: 'Use template' })).toBeInTheDocument();
    });

    it('should not show a `Use template` button when neither templates feature is enabled', async () => {
      config.featureToggles.dashboardTemplates = false;
      mockUseDataSourceInstanceList.mockReturnValue({ isLoading: false, items: [] });
      await renderAndOpen();
      expect(screen.queryByRole('menuitem', { name: 'Use template' })).not.toBeInTheDocument();
    });

    it('should show a `Use template` button when only custom templates are enabled, even without a test datasource', async () => {
      config.featureToggles.dashboardTemplates = false;
      mockUseDataSourceInstanceList.mockReturnValue({ isLoading: false, items: [] });
      mockGetDashboardTemplatesTab.mockReturnValue(() => null);
      setTestFlags({ 'grafana.customDashboardTemplates': true });

      await renderAndOpen();
      expect(screen.getByRole('menuitem', { name: 'Use template' })).toBeInTheDocument();
    });

    it('should redirect the user to the dashboard from template page when the button is clicked', async () => {
      await renderAndOpen();
      const link = screen.getByRole('menuitem', { name: 'Use template' });
      expect(link).toHaveAttribute('href', '/dashboards?templateDashboards=true&source=createNewButton');
    });
  });

  describe('Generate dashboard item', () => {
    beforeEach(() => {
      mockUseDashboardGenerationAvailable.mockReturnValue(true);
    });

    it('shows the item directly after `New dashboard`, matching the QuickAdd menu', async () => {
      await renderAndOpen();

      const dashboardGroup = screen.getByRole('group', { name: 'Dashboard' });
      const items = within(dashboardGroup)
        .getAllByRole('menuitem')
        .map((item) => item.textContent);
      expect(items.slice(0, 2)).toEqual(['New dashboard', 'Generate dashboard']);
    });

    it('opens the prompt on click, and closes it again on dismiss', async () => {
      const { user } = render(<CreateNewButton canCreateDashboard canCreateFolder isReadOnlyRepo={false} />);
      await user.click(screen.getByText('New'));
      expect(screen.queryByTestId('generate-dashboard-modal')).not.toBeInTheDocument();

      await user.click(screen.getByRole('menuitem', { name: 'Generate dashboard' }));
      expect(await screen.findByTestId('generate-dashboard-modal')).toBeInTheDocument();

      await user.click(screen.getByRole('button', { name: 'Close prompt' }));
      expect(screen.queryByTestId('generate-dashboard-modal')).not.toBeInTheDocument();
    });

    it('does not show the item when generation is unavailable', async () => {
      mockUseDashboardGenerationAvailable.mockReturnValue(false);
      await renderAndOpen();
      expect(screen.queryByRole('menuitem', { name: 'Generate dashboard' })).not.toBeInTheDocument();
    });

    it('does not show the item when the user cannot create dashboards', async () => {
      const { user } = render(<CreateNewButton canCreateDashboard={false} canCreateFolder isReadOnlyRepo={false} />);
      await user.click(screen.getByText('New'));
      expect(screen.queryByRole('menuitem', { name: 'Generate dashboard' })).not.toBeInTheDocument();
    });
  });
});
