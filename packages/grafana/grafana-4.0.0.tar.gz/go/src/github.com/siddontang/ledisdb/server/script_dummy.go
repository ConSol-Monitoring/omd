// +build !lua

package server

type script struct {
}

func (app *App) openScript() {}

func (app *App) closeScript() {}
