package rocksdb

const DBName = "rocksdb"
