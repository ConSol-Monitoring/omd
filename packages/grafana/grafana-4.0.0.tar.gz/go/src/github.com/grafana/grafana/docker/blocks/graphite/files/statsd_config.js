{
  graphitePort: 2003,
  graphiteHost: "127.0.0.1",
  port: 8125,
  mgmt_port: 8126,
  backends: ['./backends/graphite'],
  debug: true
}
