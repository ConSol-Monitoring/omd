export const BASE_PATH = 'admin/authentication/';
