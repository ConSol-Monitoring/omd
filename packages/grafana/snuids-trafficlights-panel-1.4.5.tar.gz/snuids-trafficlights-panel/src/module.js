import {TrafficLightCtrl} from './trafficlight_ctrl';

export {
  TrafficLightCtrl as PanelCtrl
};
