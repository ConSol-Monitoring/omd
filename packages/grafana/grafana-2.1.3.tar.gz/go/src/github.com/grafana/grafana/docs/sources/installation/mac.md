---
page_title: Installing on Mac OS X
page_description: Grafana Installation guide for Mac OS X
page_keywords: grafana, installation, mac, osx, guide
---

# Installing on Mac

There is currently no binary build for Mac. But read the [build from
source](/project/building_from_source) page for instructions on how to
build it yourself.


