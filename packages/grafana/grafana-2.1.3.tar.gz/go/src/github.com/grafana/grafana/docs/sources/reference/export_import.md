---
page_title: Export & Import Guide
page_description: Export & Import Guide for Grafana
page_keywords: grafana, export, import, documentation
---

# Export and Import

You find the import view in the bottom of the search dropdown. From this view you
can import local json files or migrate dashboards stored in Elasticsearch or InfluxDB.
