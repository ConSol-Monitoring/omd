// +k8s:deepcopy-gen=package
// +k8s:openapi-gen=true
// +groupName=playlist.grafana.app

package v0alpha1 // import "github.com/grafana/grafana/pkg/apis/playlist/v0alpha1"
