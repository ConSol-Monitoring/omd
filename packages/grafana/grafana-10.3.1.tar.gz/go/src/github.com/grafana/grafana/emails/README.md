## Prerequisites

- npm install

## Tasks

- make (default task will build new inlines email templates)

## Result

Assembled email templates will be in `dist/` and final
inlined templates will be in `../public/emails/`
