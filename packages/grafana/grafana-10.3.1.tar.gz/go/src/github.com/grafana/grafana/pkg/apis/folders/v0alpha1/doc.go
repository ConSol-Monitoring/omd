// +k8s:deepcopy-gen=package
// +k8s:openapi-gen=true
// +groupName=folders.grafana.app

package v0alpha1 // import "github.com/grafana/grafana/pkg/apis/folders/v0alpha1"
