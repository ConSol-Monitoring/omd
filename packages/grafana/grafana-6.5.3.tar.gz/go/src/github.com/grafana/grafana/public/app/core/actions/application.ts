import { actionCreatorFactory } from 'app/core/redux';

export const toggleLogActions = actionCreatorFactory('TOGGLE_LOG_ACTIONS').create();
