/*! grafana - v2.1.3 - 2015-08-24
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache License */

define(["helpers","features/dashboard/rowCtrl"],function(a){"use strict";describe("RowCtrl",function(){var b=new a.ControllerTestContext;beforeEach(module("grafana.controllers")),beforeEach(b.providePhase()),beforeEach(b.createControllerPhase("RowCtrl"))})});