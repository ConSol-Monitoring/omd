/// <reference path="../../../public/app/headers/common.d.ts" />
declare var beforeEach: any;
declare var describe: any;
declare var it: any;
declare var sinon: any;
declare var expect: any;
declare var angularMocks: {
    module: any;
};
export { beforeEach, describe, it, sinon, expect, angularMocks };
