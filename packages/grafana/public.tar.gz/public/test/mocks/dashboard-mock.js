/*! grafana - v4.0.1-1480694114 - 2016-12-02
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define([],function(){"use strict";return{create:function(){return{title:"",tags:[],style:"dark",timezone:"browser",editable:!0,failover:!1,panel_hints:!0,rows:[],pulldowns:[{type:"templating"},{type:"annotations"}],nav:[{type:"timepicker"}],time:{from:"now-6h",to:"now"},templating:{list:[]},refresh:"10s"}}}});