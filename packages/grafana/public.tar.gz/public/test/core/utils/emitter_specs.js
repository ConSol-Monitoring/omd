/*! grafana - v3.0.0-beta11459429091 - 2016-03-31
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["test/lib/common","app/core/core"],function(a){var b,c;return{setters:[function(a){b=a},function(a){c=a}],execute:function(){b.describe("Emitter",function(){b.describe("given 2 subscribers",function(){b.it("should notfiy subscribers",function(){var a=new c.Emitter,d=!1,e=!1;a.on("test",function(){d=!0}),a.on("test",function(){e=!0}),a.emit("test",null),b.expect(d).to.be(!0),b.expect(e).to.be(!0)})})})}}});