/*! grafana - v2.5.0 - 2015-10-28
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./dashboardCtrl","./dashboardLoaderSrv","./dashboardNavCtrl","./snapshotTopNavCtrl","./saveDashboardAsCtrl","./playlistCtrl","./rowCtrl","./shareModalCtrl","./shareSnapshotCtrl","./submenuCtrl","./dashboardSrv","./keybindings","./viewStateSrv","./playlistSrv","./timeSrv","./unsavedChangesSrv","./directives/dashSearchView","./timepicker/timepicker","./graphiteImportCtrl","./dynamicDashboardSrv","./importCtrl"],function(){});