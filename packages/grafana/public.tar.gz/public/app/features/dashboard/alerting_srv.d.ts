/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare class AlertingSrv {
    dashboard: any;
    alerts: any[];
    init(dashboard: any, alerts: any): void;
}
