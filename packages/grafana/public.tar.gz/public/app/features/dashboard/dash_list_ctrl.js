/*! grafana - v3.1.1-1470047149 - 2016-08-01
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["app/core/core_module"],function(a){var b,c;return{setters:[function(a){b=a}],execute:function(){c=function(){function a(){}return a}(),a("DashListCtrl",c),b["default"].controller("DashListCtrl",c)}}});