/*! grafana - v2.6.0 - 2015-12-14
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./adminListUsersCtrl","./adminListOrgsCtrl","./adminEditOrgCtrl","./adminEditUserCtrl","./adminSettingsCtrl"],function(){});