import './adminListUsersCtrl';
import './adminListOrgsCtrl';
import './adminEditOrgCtrl';
import './adminEditUserCtrl';
export declare class AdminStatsCtrl {
    stats: any;
    /** @ngInject */
    constructor(backendSrv: any);
}
