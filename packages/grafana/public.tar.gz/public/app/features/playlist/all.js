/*! grafana - v4.2.0 - 2017-03-22
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./playlists_ctrl","./playlist_search","./playlist_srv","./playlist_edit_ctrl","./playlist_routes"],function(){});