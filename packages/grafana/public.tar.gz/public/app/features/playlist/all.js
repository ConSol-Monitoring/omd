/*! grafana - v3.0.0-beta21459801392 - 2016-04-04
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./playlists_ctrl","./playlist_search","./playlist_srv","./playlist_edit_ctrl","./playlist_routes"],function(){});