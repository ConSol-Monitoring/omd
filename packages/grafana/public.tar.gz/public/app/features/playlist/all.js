/*! grafana - v3.0.0-beta11459429091 - 2016-03-31
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./playlists_ctrl","./playlist_search","./playlist_srv","./playlist_edit_ctrl","./playlist_routes"],function(){});