/*! grafana - v4.0.0-1480439068 - 2016-11-29
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./org_users_ctrl","./profile_ctrl","./org_users_ctrl","./select_org_ctrl","./change_password_ctrl","./newOrgCtrl","./userInviteCtrl","./orgApiKeysCtrl","./orgDetailsCtrl","./prefs_control"],function(){});