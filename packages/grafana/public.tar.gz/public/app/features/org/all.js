/*! grafana - v3.0.0-beta11459429091 - 2016-03-31
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./org_users_ctrl","./newOrgCtrl","./userInviteCtrl","./orgApiKeysCtrl","./orgDetailsCtrl"],function(){});