/*! grafana - v2.5.0 - 2015-10-28
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./datasourcesCtrl","./datasourceEditCtrl","./orgUsersCtrl","./newOrgCtrl","./userInviteCtrl","./orgApiKeysCtrl","./orgDetailsCtrl"],function(){});