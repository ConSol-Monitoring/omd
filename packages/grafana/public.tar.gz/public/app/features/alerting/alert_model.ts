 ///<reference path="../../headers/common.d.ts" />

import _ from 'lodash';
import {QueryPart} from 'app/core/components/query_part/query_part';
import alertDef from './alert_def';

export class AlertModel {
  constructor() {
  }
}

