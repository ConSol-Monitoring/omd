/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare class VariableSrv {
    private $rootScope;
    private $q;
    private $location;
    private $injector;
    private templateSrv;
    dashboard: any;
    variables: any;
    /** @ngInject */
    constructor($rootScope: any, $q: any, $location: any, $injector: any, templateSrv: any);
    init(dashboard: any): any;
    onDashboardRefresh(): any;
    processVariable(variable: any, queryParams: any): any;
    createVariableFromModel(model: any): any;
    addVariable(variable: any): void;
    removeVariable(variable: any): void;
    updateOptions(variable: any): any;
    variableUpdated(variable: any, emitChangeEvents?: any): any;
    selectOptionsForCurrentValue(variable: any): any;
    validateVariableSelectionState(variable: any): any;
    setOptionFromUrl(variable: any, urlValue: any): any;
    setOptionAsCurrent(variable: any, option: any): any;
    updateUrlParamsWithCurrentVariables(): void;
    setAdhocFilter(options: any): void;
}
