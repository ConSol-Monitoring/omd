import { EventBusExtended } from '@grafana/data';

export interface PanelModelForLegacyQueryEditors {
  events: EventBusExtended;
}
