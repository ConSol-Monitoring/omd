/*! grafana - v4.4.3 - 2017-08-07
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register([],function(a,b){"use strict";var c;b&&b.id;return{setters:[],execute:function(){c=function(){function a(a,b){this.$scope=a,this.$injector=b,this.panel=this.panelCtrl.panel}return a.prototype.refresh=function(){this.panelCtrl.refresh()},a}(),a("QueryCtrl",c)}}});