/*! grafana - v4.4.1 - 2017-07-05
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panel_menu","./panel_directive","./solo_panel_ctrl","./query_ctrl","./panel_editor_tab","./query_editor_row","./query_troubleshooter"],function(){});