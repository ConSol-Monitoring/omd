/*! grafana - v2.6.0 - 2015-12-14
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panel_menu","./panel_directive","./panel_srv","./panel_helper","./solo_panel_ctrl"],function(){});