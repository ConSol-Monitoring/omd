/*! grafana - v4.1.2-1486989747 - 2017-02-13
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panel_menu","./panel_directive","./solo_panel_ctrl","./query_ctrl","./panel_editor_tab","./query_editor_row","./metrics_ds_selector"],function(){});