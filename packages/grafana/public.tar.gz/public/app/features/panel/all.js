/*! grafana - v3.0.0-beta21459801392 - 2016-04-04
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panel_menu","./panel_directive","./solo_panel_ctrl","./query_ctrl","./panel_editor_tab","./query_editor_row"],function(){});