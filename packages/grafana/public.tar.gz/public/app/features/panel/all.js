define([
  './panel_menu',
  './panel_directive',
  './solo_panel_ctrl',
  './query_ctrl',
  './panel_editor_tab',
  './query_editor_row',
  './query_troubleshooter',
], function () {});
