import React from 'react';

import { QueryTemplatesList } from './QueryTemplatesList';

export function QueryLibrary() {
  return <QueryTemplatesList />;
}
