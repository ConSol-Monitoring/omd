declare module 'chance';
