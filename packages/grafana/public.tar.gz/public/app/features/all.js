/*! grafana - v3.0.0-beta11459429091 - 2016-03-31
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panellinks/module","./dashlinks/module","./annotations/annotations_srv","./templating/templateSrv","./dashboard/all","./playlist/all","./snapshot/all","./panel/all","./profile/profileCtrl","./profile/changePasswordCtrl","./profile/selectOrgCtrl","./styleguide/styleguide"],function(){});