/*! grafana - v4.0.0-1480439068 - 2016-11-29
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panellinks/module","./dashlinks/module","./annotations/annotations_srv","./templating/all","./dashboard/all","./playlist/all","./snapshot/all","./panel/all","./styleguide/styleguide"],function(){});