/*! grafana - v3.1.1-1470047149 - 2016-08-01
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./snapshot_ctrl"],function(a){return{setters:[function(a){}],execute:function(){}}});