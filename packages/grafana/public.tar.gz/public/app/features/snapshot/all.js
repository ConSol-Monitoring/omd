/*! grafana - v3.0.2-1463383025 - 2016-05-16
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./snapshot_ctrl"],function(a){return{setters:[function(a){}],execute:function(){}}});