/*! grafana - v4.1.1-1484211277 - 2017-01-12
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./snapshot_ctrl"],function(a,b){"use strict";b&&b.id;return{setters:[function(a){}],execute:function(){}}});