/*! grafana - v4.4.3 - 2017-08-07
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./annotations_srv","./event_editor","./event_manager","./event","./annotation_tooltip"],function(a,b){"use strict";var c,d,e,f,g;b&&b.id;return{setters:[function(a){c=a},function(a){d=a},function(a){e=a},function(a){f=a},function(a){g=a}],execute:function(){a("AnnotationsSrv",c.AnnotationsSrv),a("eventEditor",d.eventEditor),a("EventManager",e.EventManager),a("AnnotationEvent",f.AnnotationEvent),a("annotationTooltipDirective",g.annotationTooltipDirective)}}});