export { uploadDashboardDirective } from './uploadDashboardDirective';
