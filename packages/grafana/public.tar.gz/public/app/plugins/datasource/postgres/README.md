# Grafana PostgreSQL Datasource -  Native Plugin

This is the built in PostgreSQL Datasource that is used to connect to PostgreSQL databases.
