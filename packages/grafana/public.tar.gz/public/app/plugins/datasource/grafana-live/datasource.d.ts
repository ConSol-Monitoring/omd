/// <reference path="../../../../../public/app/headers/common.d.ts" />
export declare class GrafanaStreamDS {
    subscription: any;
    /** @ngInject */
    constructor();
    query(options: any): any;
}
