declare var OpenTsDatasource: any;
export default OpenTsDatasource;

