/// <reference path="../../../../../public/app/headers/common.d.ts" />
/** @ngInject */
export declare function PrometheusDatasource(instanceSettings: any, $q: any, backendSrv: any, templateSrv: any, timeSrv: any): void;
