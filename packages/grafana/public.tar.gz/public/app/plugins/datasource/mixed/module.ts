///<reference path="../../../headers/common.d.ts" />

import {MixedDatasource} from './datasource';
export {MixedDatasource, MixedDatasource as Datasource};

