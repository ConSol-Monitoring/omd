/*! grafana - v2.1.0-pre1 - 2015-06-26
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache License */

define(["angular","lodash","kbn"],function(a){"use strict";var b=a.module("grafana.services");b.factory("SqlDatasource",function(){function a(){}return a})});