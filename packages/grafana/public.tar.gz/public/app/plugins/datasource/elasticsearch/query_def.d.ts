declare var test: any;
export default test;
