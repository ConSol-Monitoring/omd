import angular from 'angular';
export default angular.module('grafana.core', ['ngRoute']);
