/*! grafana - v3.0.2-1463383025 - 2016-05-16
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./time_series2"],function(a){"use strict";return a["default"]});