/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare function infoPopover(): {
    restrict: string;
    transclude: boolean;
    link: (scope: any, elem: any, attrs: any, ctrl: any, transclude: any) => void;
};
