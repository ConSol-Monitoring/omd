export interface FolderInfo {
  id: number;
  title: string;
  url: string;
}
