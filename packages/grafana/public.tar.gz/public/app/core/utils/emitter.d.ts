/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare class Emitter {
    subjects: any;
    constructor();
    emit(name: any, data?: any): void;
    on(name: any, handler: any, scope?: any): any;
    off(name: any, handler: any): void;
    dispose(): void;
}
