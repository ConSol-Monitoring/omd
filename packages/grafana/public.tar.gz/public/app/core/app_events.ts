import { Emitter } from './utils/emitter';

var appEvents = new Emitter();
export default appEvents;
