package httpclientprovider

import (
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/mwitkow/go-conntrack"

	"github.com/grafana/grafana-aws-sdk/pkg/awsauth"
	"github.com/grafana/grafana-aws-sdk/pkg/awsds"
	sdkhttpclient "github.com/grafana/grafana-plugin-sdk-go/backend/httpclient"
	"github.com/grafana/grafana-plugin-sdk-go/backend/proxy"
	"github.com/grafana/grafana-plugin-sdk-go/config"
	"github.com/grafana/grafana/pkg/infra/log"
	"github.com/grafana/grafana/pkg/infra/metrics/metricutil"
	"github.com/grafana/grafana/pkg/infra/tracing"
	"github.com/grafana/grafana/pkg/services/validations"
	"github.com/grafana/grafana/pkg/setting"
)

var newProviderFunc = sdkhttpclient.NewProvider

// New creates a new HTTP client provider with pre-configured middlewares.
func New(cfg *setting.Cfg, validator validations.DataSourceRequestURLValidator, tracer tracing.Tracer) *sdkhttpclient.Provider {
	logger := log.New("httpclient")

	middlewares := []sdkhttpclient.Middleware{
		TracingMiddleware(logger, tracer),
		DataSourceMetricsMiddleware(),
		sdkhttpclient.ContextualMiddleware(),
		SetUserAgentMiddleware(cfg.DataProxyUserAgent),
		sdkhttpclient.BasicAuthenticationMiddleware(),
		sdkhttpclient.CustomHeadersMiddleware(),
		sdkhttpclient.ResponseLimitMiddleware(cfg.ResponseLimit),
		RedirectLimitMiddleware(validator),
	}

	if httpLoggingEnabled(cfg.PluginSettings) {
		middlewares = append(middlewares, HTTPLoggerMiddleware(cfg.PluginSettings))
	}

	if cfg.IPRangeACEnabled {
		middlewares = append(middlewares, GrafanaRequestIDHeaderMiddleware(cfg, logger))
	}

	middlewares = append(middlewares, sdkhttpclient.ErrorSourceMiddleware())

	// SigV4 signing should be performed after all headers are added
	if cfg.SigV4AuthEnabled {
		awsCfg := config.NewGrafanaCfg(map[string]string{
			awsds.AllowedAuthProvidersEnvVarKeyName:          strings.Join(cfg.AWSAllowedAuthProviders, ","),
			awsds.AssumeRoleEnabledEnvVarKeyName:             strconv.FormatBool(cfg.AWSAssumeRoleEnabled),
			awsds.GrafanaAssumeRoleExternalIdKeyName:         cfg.AWSExternalId,
			awsds.ListMetricsPageLimitKeyName:                strconv.Itoa(cfg.AWSListMetricsPageLimit),
			awsds.SessionDurationEnvVarKeyName:               cfg.AWSSessionDuration,
			awsds.PerDatasourceHTTPProxyEnabledEnvVarKeyName: strconv.FormatBool(cfg.AWSPerDatasourceHTTPProxyEnabled),
			proxy.PluginSecureSocksProxyEnabled:              strconv.FormatBool(cfg.SecureSocksDSProxy.Enabled),
		})
		middlewares = append(middlewares, sdkhttpclient.NamedMiddlewareFunc("sigv4-aws-config", func(opts sdkhttpclient.Options, next http.RoundTripper) http.RoundTripper {
			sigv4 := awsauth.NewSigV4Middleware().CreateMiddleware(opts, next)
			return sdkhttpclient.RoundTripperFunc(func(req *http.Request) (*http.Response, error) {
				ctx := req.Context()
				// Normally the sigv4 middleware would read auth settings from ctx. But for frontend-only datasources using the data proxy,
				// GrafanaConfig is never injected into the request context. In this case fall back to cfg values
				if _, exists := awsds.ReadAuthSettingsFromContext(ctx); !exists {
					ctx = config.WithGrafanaConfig(ctx, awsCfg)
				}
				return sigv4.RoundTrip(req.WithContext(ctx))
			})
		}))
	}

	setDefaultTimeoutOptions(cfg)

	return newProviderFunc(sdkhttpclient.ProviderOptions{
		Middlewares: middlewares,
		ConfigureTransport: func(opts sdkhttpclient.Options, transport *http.Transport) {
			datasourceName, exists := opts.Labels["datasource_name"]
			if !exists {
				return
			}
			datasourceLabelName, err := metricutil.SanitizeLabelName(datasourceName)
			if err != nil {
				return
			}

			newConntrackRoundTripper(datasourceLabelName, transport)
		},
	})
}

// newConntrackRoundTripper takes a http.Transport and adds the Conntrack Dialer
// so we can instrument outbound connections
func newConntrackRoundTripper(name string, transport *http.Transport) *http.Transport {
	transport.DialContext = conntrack.NewDialContextFunc(
		conntrack.DialWithName(name),
		conntrack.DialWithDialContextFunc(transport.DialContext),
	)
	return transport
}

// setDefaultTimeoutOptions overrides the default timeout options for the SDK.
//
// Note: Not optimal changing global state, but hard to not do in this case.
func setDefaultTimeoutOptions(cfg *setting.Cfg) {
	sdkhttpclient.DefaultTimeoutOptions = sdkhttpclient.TimeoutOptions{
		Timeout:               time.Duration(cfg.DataProxyTimeout) * time.Second,
		DialTimeout:           time.Duration(cfg.DataProxyDialTimeout) * time.Second,
		KeepAlive:             time.Duration(cfg.DataProxyKeepAlive) * time.Second,
		TLSHandshakeTimeout:   time.Duration(cfg.DataProxyTLSHandshakeTimeout) * time.Second,
		ExpectContinueTimeout: time.Duration(cfg.DataProxyExpectContinueTimeout) * time.Second,
		MaxConnsPerHost:       cfg.DataProxyMaxConnsPerHost,
		MaxIdleConns:          cfg.DataProxyMaxIdleConns,
		MaxIdleConnsPerHost:   cfg.DataProxyMaxIdleConns,
		IdleConnTimeout:       time.Duration(cfg.DataProxyIdleConnTimeout) * time.Second,
	}
}
