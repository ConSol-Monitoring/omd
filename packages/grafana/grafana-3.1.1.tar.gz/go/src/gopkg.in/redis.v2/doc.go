/*
Package redis implements a Redis client.
*/
package redis
