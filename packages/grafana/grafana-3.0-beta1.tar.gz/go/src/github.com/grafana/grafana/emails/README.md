
- npm install
- gem install premailer
- grunt   (default task will build new inlines email templates)
- grunt watch  (will build on source html or css change)

assembled email templates will be in dist/ and final
inlined templates will be in ../public/emails/

