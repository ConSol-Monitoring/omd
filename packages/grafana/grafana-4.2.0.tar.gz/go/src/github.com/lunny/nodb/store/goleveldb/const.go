package goleveldb

const DBName = "goleveldb"
const MemDBName = "memory"
