import _ from 'lodash';
import {HistogramCtrl} from './histogram_ctrl';
import './histogram';

export {
  HistogramCtrl as PanelCtrl
};
