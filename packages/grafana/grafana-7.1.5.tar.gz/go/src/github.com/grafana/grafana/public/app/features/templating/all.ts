import coreModule from 'app/core/core_module';
import templateSrv from './template_srv';

coreModule.factory('templateSrv', () => templateSrv);
