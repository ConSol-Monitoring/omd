# inject [![Build Status](https://travis-ci.org/go-macaron/inject.svg?branch=master)](https://travis-ci.org/go-macaron/inject) [![](http://gocover.io/_badge/github.com/go-macaron/inject)](http://gocover.io/github.com/go-macaron/inject)

Package inject provides utilities for mapping and injecting dependencies in various ways.

**This a modified version of [codegangsta/inject](https://github.com/codegangsta/inject) for special purpose of Macaron**

**Please use the original version if you need dependency injection feature**

## License

This project is under the Apache License, Version 2.0. See the [LICENSE](LICENSE) file for the full license text.