module.exports = function(config) {
  return {
    me: {
      // Target-specific file lists and/or options go here.
    }
  };
};