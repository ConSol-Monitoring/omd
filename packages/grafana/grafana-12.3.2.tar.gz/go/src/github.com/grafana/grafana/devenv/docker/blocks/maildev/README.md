This block starts a test SMTP server on port 1025 and UI on port 12080
