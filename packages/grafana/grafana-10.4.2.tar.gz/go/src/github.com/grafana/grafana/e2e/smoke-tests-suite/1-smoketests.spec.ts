import { smokeTestScenario } from '../shared/smokeTestScenario';

smokeTestScenario();
