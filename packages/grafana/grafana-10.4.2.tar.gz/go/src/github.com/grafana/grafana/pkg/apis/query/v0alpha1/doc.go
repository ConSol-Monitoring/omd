// +k8s:deepcopy-gen=package
// +k8s:openapi-gen=true
// +k8s:defaulter-gen=TypeMeta
// +groupName=query.grafana.app

package v0alpha1 // import "github.com/grafana/grafana/pkg/apis/query/v0alpha1"
