// +k8s:deepcopy-gen=package
// +k8s:openapi-gen=true
// +k8s:defaulter-gen=TypeMeta
// +groupName=query.grafana.app

package template // import "github.com/grafana/grafana/pkg/apis/query/v0alpha1/template"
