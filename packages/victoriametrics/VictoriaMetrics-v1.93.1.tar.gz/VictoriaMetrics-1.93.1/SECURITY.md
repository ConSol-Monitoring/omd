# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| [latest release](https://docs.victoriametrics.com/CHANGELOG.html) | :white_check_mark: |
| v1.87.x LTS release | :white_check_mark: |
| v1.79.x LTS release | :white_check_mark: |
| other releases  | :x:                |

## Reporting a Vulnerability

Please report any security issues to security@victoriametrics.com
