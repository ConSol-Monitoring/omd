---
sort: 21
---

# Guides

1. [K8s monitoring via VM Single](k8s-monitoring-via-vm-single.html)
2. [K8s monitoring via VM Cluster](k8s-monitoring-via-vm-cluster.html)
3. [HA monitoring setup in K8s via VM Cluster](k8s-ha-monitoring-via-vm-cluster.html)