export type AggregatedDataSet = {
  key: number;
  value: aggregatedDataValue;
};
export type aggregatedDataValue = {[key: string]: number};
