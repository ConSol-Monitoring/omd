`vmselect` performs the incoming queries and fetches the required data
from `vmstorage`.
