# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| 1.81.x  | :white_check_mark: |
| 1.80.x  | :x:                |
| 1.79.x  | :white_check_mark: |
| < 1.78  | :x:                |

## Reporting a Vulnerability

Please report any security issues to security@victoriametrics.com
