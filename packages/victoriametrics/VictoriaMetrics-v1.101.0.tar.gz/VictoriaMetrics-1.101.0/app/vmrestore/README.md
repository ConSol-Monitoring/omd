See vmrestore docs [here](https://docs.victoriametrics.com/vmrestore/).

vmrestore docs can be edited at [docs/vmrestore.md](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/docs/vmrestore.md).
