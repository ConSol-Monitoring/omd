See vmbackup docs [here](https://docs.victoriametrics.com/vmbackup/).

vmbackup docs can be edited at [docs/vmbackup.md](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/docs/vmbackup.md).
