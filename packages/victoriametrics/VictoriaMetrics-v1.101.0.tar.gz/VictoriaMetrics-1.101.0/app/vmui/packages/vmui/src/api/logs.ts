export const getLogsUrl = (server: string): string =>
  `${server}/select/logsql/query`;
