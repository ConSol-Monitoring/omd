See vmalert docs [here](https://docs.victoriametrics.com/vmalert/).

vmalert docs can be edited at [docs/vmalert.md](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/docs/vmalert.md).
