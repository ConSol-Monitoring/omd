See vmauth docs [here](https://docs.victoriametrics.com/vmauth/).

vmauth docs can be edited at [docs/vmauth.md](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/docs/vmauth.md).
