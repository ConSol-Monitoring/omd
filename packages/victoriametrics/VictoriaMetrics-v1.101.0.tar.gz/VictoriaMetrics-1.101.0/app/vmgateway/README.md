See vmgateway docs [here](https://docs.victoriametrics.com/vmgateway/).

vmgateway docs can be edited at [docs/vmgateway.md](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/docs/vmgateway.md).
