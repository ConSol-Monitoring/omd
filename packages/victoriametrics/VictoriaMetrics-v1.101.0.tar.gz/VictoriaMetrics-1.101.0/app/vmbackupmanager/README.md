See vmbackupmanager docs [here](https://docs.victoriametrics.com/vmbackupmanager/).

vmbackupmanager docs can be edited at [docs/vmbackupmanager.md](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/docs/vmbackupmanager.md).
