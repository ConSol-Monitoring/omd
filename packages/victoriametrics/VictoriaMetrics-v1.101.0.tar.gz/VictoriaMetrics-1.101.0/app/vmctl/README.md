See vmctl docs [here](https://docs.victoriametrics.com/vmctl/).

vmctl docs can be edited at [docs/vmctl.md](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/docs/vmctl.md).
