See vmagent docs [here](https://docs.victoriametrics.com/vmagent/).

vmagent docs can be edited at [docs/vmagent.md](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/docs/vmagent.md).
