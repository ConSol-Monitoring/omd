See vmalert-tool docs [here](https://docs.victoriametrics.com/vmalert-tool.html).

vmalert-tool docs can be edited at [docs/vmalert-tool.md](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/docs/vmalert-tool.md).
