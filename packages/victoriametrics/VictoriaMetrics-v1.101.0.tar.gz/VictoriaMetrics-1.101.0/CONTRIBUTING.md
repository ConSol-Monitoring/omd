The document has been moved [here](https://docs.victoriametrics.com/contributing/).
