window.__VMUI_PREDEFINED_DASHBOARDS__ = [
  "perJobUsage.json"
];
