# metricsql

This package has been moved to [github.com/VictoriaMetrics/metricsql](https://github.com/VictoriaMetrics/metricsql).
