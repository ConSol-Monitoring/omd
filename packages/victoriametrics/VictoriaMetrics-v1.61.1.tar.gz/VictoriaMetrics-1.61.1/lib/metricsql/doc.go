// Package metricsql has been moved to https://github.com/VictoriaMetrics/metricsql .
//
package metricsql
