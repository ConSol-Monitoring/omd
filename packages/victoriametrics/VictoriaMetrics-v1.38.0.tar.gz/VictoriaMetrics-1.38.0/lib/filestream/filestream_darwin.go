package filestream

func (st *streamTracker) adviseDontNeed(n int, fdatasync bool) error {
	return nil
}

func (st *streamTracker) close() error {
	return nil
}
