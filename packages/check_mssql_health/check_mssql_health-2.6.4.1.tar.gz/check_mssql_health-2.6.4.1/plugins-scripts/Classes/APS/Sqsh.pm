package Classes::APS::Sqsh;
our @ISA = qw(Classes::APS Classes::Sybase::Sqsh);
use strict;
