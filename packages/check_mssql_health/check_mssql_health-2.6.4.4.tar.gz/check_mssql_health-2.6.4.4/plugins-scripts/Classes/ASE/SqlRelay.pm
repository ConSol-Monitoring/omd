package Classes::ASE::Sqlrelay;
our @ISA = qw(Classes::ASE Classes::Sybase::Sqlrelay);
use strict;
