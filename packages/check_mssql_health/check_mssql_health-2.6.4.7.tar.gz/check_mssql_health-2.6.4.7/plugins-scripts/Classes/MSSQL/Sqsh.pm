package Classes::MSSQL::Sqsh;
our @ISA = qw(Classes::MSSQL Classes::Sybase::Sqsh);
use strict;
