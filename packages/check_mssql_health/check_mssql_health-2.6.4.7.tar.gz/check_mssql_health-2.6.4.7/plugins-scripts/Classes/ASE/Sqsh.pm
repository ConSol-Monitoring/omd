package Classes::ASE::Sqsh;
our @ISA = qw(Classes::ASE Classes::Sybase::Sqsh);
use strict;
