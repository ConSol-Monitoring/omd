#!/usr/bin/env perl

use Data::Dumper;
print Dumper($external);

1;
