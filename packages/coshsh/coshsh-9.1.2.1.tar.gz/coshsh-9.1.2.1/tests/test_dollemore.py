import os
from unittest.mock import patch
from io import StringIO
import coshsh
from tests.common_coshsh_test import CommonCoshshTest
import sys

class CoshshTest(CommonCoshshTest):

    def test_create_server(self):
        self.setUpConfig("./dollemore/coshsh.cfg", "dollemore")
        recp = self.generator.get_recipe("dollemore")
        ds = self.generator.get_recipe("dollemore").get_datasource("simplesample")
        ds.objects = self.generator.get_recipe("dollemore").objects
        ds.add("applications", coshsh.application.Application({
            'name': 'Application', 'type': 'qlikview', 'host_name': 'nt-qlv-p04',
        }))
        ds.add("applications", coshsh.application.Application({
            'name': 'os', 'type': 'windows', 'host_name': 'nt-qlv-p04',
        }))
        ds.add("applications", coshsh.application.Application({
            'name': 'role', 'type': 'application-server', 'host_name': 'nt-qlv-p04',
        }))
        ds.add("applications", coshsh.application.Application({
            'name': 'Application', 'type': 'simcorp', 'host_name': 'nt-sim-p02',
        }))
        ds.add("applications", coshsh.application.Application({
            'name': 'os', 'type': 'windows', 'host_name': 'nt-sim-p02',
        }))
        ds.add("applications", coshsh.application.Application({
            'name': 'role', 'type': 'application-server', 'host_name': 'nt-sim-p02',
        }))
        apps = ds.getall("applications")
        simcorp = [a for a in apps if a.host_name == "nt-sim-p02"][0]
        qlikview = [a for a in apps if a.host_name == "nt-qlv-p04"][0]
        self.assertTrue("simcorp" in simcorp.__class__.__name__.lower())
        self.assertTrue("qlikview" in qlikview.__class__.__name__.lower())
        try:
            raise "kak"
        except Exception as e:
            sys.stderr.write("----")
            sys.stderr.write("----")
            sys.stderr.write("----")
            sys.stderr.write("----")
            sys.stderr.write("----")
            sys.stderr.write("----")
            sys.stderr.write("----")
            sys.stderr.write("----")
            print("----")
            print("----")
            print("----")
            print("----")
            print("----")
            print("----")
            logger.critical("error !!!!!!!!!!!!!!!!!!!!ror %s was: %s" % (self.__class__.__name__, str(e)), exc_info=1)
            print("----")
            raise

if __name__ == '__main__':
    unittest.main()

