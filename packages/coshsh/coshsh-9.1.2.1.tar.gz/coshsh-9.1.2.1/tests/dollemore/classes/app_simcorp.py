import coshsh
from coshsh.application import Application
from coshsh.templaterule import TemplateRule
from coshsh.monitoringdetail import MonitoringDetail
from coshsh.util import compare_attr
import re

def __mi_ident__(params={}):
    if params['host_name'] == 'nt-sim-p02':
        print("simcorp")
        print(params)
    if params['host_name'] == 'nt-qlv-p04':
        print("simcorp")
        print(params)
    if coshsh.util.compare_attr("type", params, "^simcorp$") and coshsh.util.compare_attr("name", params, "Application"):
        print("MATCH SIMCORP "+str(params))
        return SIMCORP


class SIMCORP(Application):
    template_rules = [
        coshsh.templaterule.TemplateRule(needsattr=None,
            template="app_simcorp_default",
            unique_attr=None, unique_config="app_%s"),
    ]

    def __init__(self, params={}):
        super(self.__class__, self).__init__(params)

