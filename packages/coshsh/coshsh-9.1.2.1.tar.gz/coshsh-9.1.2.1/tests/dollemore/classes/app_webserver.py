import coshsh
from coshsh.application import Application
from coshsh.templaterule import TemplateRule
from coshsh.monitoringdetail import MonitoringDetail
from coshsh.util import compare_attr
import re
 
def __mi_ident__(params={}):
    if params['host_name'] == 'nt-sim-p02':
        print("webserver")
        print(params)
    if params['host_name'] == 'nt-qlv-p04':
        print("webserver")
        print(params)
    if coshsh.util.compare_attr("type", params, "WebServer|Web-Server|Application-Server") and coshsh.util.compare_attr("name", params, "application|role"):
        print("MATCH WEBSERVER "+str(params))
        return Webserver
    if coshsh.util.compare_attr("type", params, "WebServer") and coshsh.util.compare_attr("name", params, "AzureCloud"):
        print("MATCH AZUREWEBSERVER "+str(params))
        return azureCloudWebserver
    if coshsh.util.compare_attr("type", params, "WebServer") and coshsh.util.compare_attr("name", params, "Signavio"):
        print("MATCH SIGWEBSERVER "+str(params))
        return signavioWebserver
 
 
class Webserver(Application):
    template_rules = [
        coshsh.templaterule.TemplateRule(needsattr="urls",
            template="app_webserver_urls",
            unique_attr=['type', 'name'], unique_config="app_%s_%s_urls"),
        coshsh.templaterule.TemplateRule(needsattr="urls_ntlm",
            template="app_webserver_urls_ntlm",
            unique_attr=['type', 'name'], unique_config="app_%s_%s_urls_ntlm"),
    ]
 
    def __init__(self, params={}):
        super(self.__class__, self).__init__(params)
 
class azureCloudWebserver(Application):
    template_rules = [
        coshsh.templaterule.TemplateRule(needsattr=None,
            template="app_azurecloud-webserver",
            unique_attr=['type', 'name'], unique_config="app_%s_%s"),
    ]
 
    def __init__(self, params={}):
        super(self.__class__, self).__init__(params)
 
class signavioWebserver(Application):
    template_rules = [
        coshsh.templaterule.TemplateRule(needsattr=None,
            template="app_signavio-webserver",
            unique_attr=['type', 'name'], unique_config="app_%s_%s"),
    ]
 
    def __init__(self, params={}):
        super(self.__class__, self).__init__(params)

