#!/usr/bin/env python
#-*- coding: utf-8 -*-
#
# This file belongs to coshsh.
# Copyright Gerhard Lausser.
# This software is licensed under the
# GNU Affero General Public License version 3 (see the file LICENSE).

"""
Generator: top-level entry point that reads cookbook config files and drives recipe execution.

Sole responsibility:
    - Parse one or more INI-style "cookbook" files to discover recipe, datasource,
      datarecipient, vault, and mapping definitions.
    - Instantiate Recipe objects wired to their declared components.
    - Iterate over recipes and delegate the collect -> assemble -> render -> output
      pipeline to each Recipe.

Does NOT:
    - Implement any pipeline logic itself (that lives in coshsh.recipe.Recipe).
    - Know about specific datasource, datarecipient, or vault plugins.
    - Write monitoring config files to disk (datarecipients do that).

Key classes:
    Generator -- the single class in this module; typically instantiated once
                 by the ``coshsh-cook`` CLI entry point.

AI agent note:
    The normal call sequence from ``bin/coshsh-cook`` is:
        1. generator = Generator()
        2. generator.set_default_log_level(...)
        3. generator.read_cookbook(cookbook_files, ...)   # parses config, creates recipes
        4. generator.run()                              # executes every recipe's pipeline
    read_cookbook() is where cookbook INI sections are classified by prefix
    (``recipe_``, ``datasource_``, ``datarecipient_``, ``vault_``, ``mapping_``)
    and wired into Recipe objects.  run() then simply iterates and delegates.
"""

from __future__ import annotations

import getpass
import logging
import os
import re
import sys
import time
from logging import DEBUG, INFO, getLogger
from pathlib import Path
from tempfile import gettempdir
from typing import Any, ClassVar

import coshsh
from coshsh.datainterface import CoshshDatainterface
from coshsh.vault import Vault  # noqa: F401 — side-effect import, loads coshsh.vault submodule

logger = logging.getLogger('coshsh')


class Generator:
    """Top-level controller that reads cookbook configs and runs recipes.

    A Generator owns an ordered collection of Recipe objects.  It is the only
    class that touches the cookbook INI files; once recipes are built, it hands
    control to each Recipe for the actual data pipeline.
    """

    base_dir: ClassVar[str] = str(Path(__file__).parent.parent)
    messages: ClassVar[list[str]] = []

    def __init__(self) -> None:
        # WHY: recipes is an odict (ordered dict) rather than a plain dict so
        # that recipes execute in the order they appear in the cookbook file.
        # The cookbook author controls execution order by section ordering, and
        # some deployments depend on earlier recipes populating shared state
        # (e.g. class factories or filesystem artifacts) before later ones run.
        self.recipes = coshsh.util.odict()
        self.default_log_level = "info"

    def set_default_log_level(self, default_log_level: str) -> None:
        """Set the log level that will be used when logging is initialized during read_cookbook().

        This must be called *before* read_cookbook() because the cookbook reader
        configures the logging subsystem based on this value.
        """
        self.default_log_level = default_log_level

    def add_recipe(self, *args: Any, **kwargs: Any) -> None:
        """Create a Recipe from keyword arguments and register it by name.

        kwargs are the key-value pairs extracted from one ``[recipe_*]``
        section of the cookbook.

        A ``RecipeInvalidConfig`` propagates to the caller and stops the run.
        Any other exception is logged and the recipe is skipped, as before.
        """
        try:
            recipe = coshsh.recipe.Recipe(**kwargs)
            self.recipes[kwargs["name"]] = recipe
        except coshsh.recipe.RecipeInvalidConfig:
            # WHY this one exception type escapes the handler below: that
            # handler drops the recipe and lets the run continue. For an
            # unreadable *run-safety* value that is the worst possible outcome
            # -- the run reports success while silently omitting every object
            # this recipe would have produced, and the missing objects are the
            # only evidence. A typo in max_delta, max_render_error_pct or
            # tolerate_missing_templates must stop the run instead, so those
            # three raise RecipeInvalidConfig and it travels past here to
            # bin/coshsh-cook, which exits 2 (FR-016, FR-016a).
            raise
        except Exception as e:
            # Deliberately left broad for every other construction failure.
            # Narrowing it further is out of scope and was explicitly rejected
            # during clarification.
            logger.error("exception creating a recipe: %s" % e)

    def get_recipe(self, name: str) -> Any:
        """Return the Recipe registered under *name*, or None if it does not exist."""
        return self.recipes.get(name, None)

    def add_pushgateway(self, *args: Any, **kwargs: Any) -> None:
        """Store Prometheus Pushgateway connection details for run()-time metrics export."""
        self.pg_job = kwargs.get("job", "coshsh")
        self.pg_address = kwargs.get("address", "127.0.0.1:9091")
        self.pg_username = kwargs.get("username", None)
        self.pg_password = kwargs.get("password", None)

    def export_recipe_metrics(self, recipe: Any, registry: Any, tic: float,
                              completed: bool, aborted: bool) -> None:
        """Fill *registry* with one recipe's gauges, ready to be pushed.

        Called only when run() has already established that prometheus_client
        imported successfully, so the local import here cannot fail.

        The split between the two lists below is the whole freshness contract,
        and it is not arbitrary:

        - The render gauges are exported on **every** run that got as far as
          rendering, aborted or not. pushadd_to_gateway replaces only the
          metrics a push actually carries and leaves every other one at its
          stored value, so a metric omitted from an aborted run's push would go
          on reporting the last *good* run's figures -- a recipe failing every
          night would show zero errors indefinitely. An aborted run is the one
          whose numbers an operator most needs.
        - The rest are exported only when output was actually published,
          because that is what they claim happened. coshsh_recipe_last_success
          in particular is the timestamp the standard liveness alarm subtracts
          from, (now - last_success) > threshold; that alarm can only fire if
          nothing but published output refreshes it. Do not move a gauge from
          the second list to the first without working out what it would then
          be asserting about a run that wrote nothing.
        """
        from prometheus_client import Gauge

        tally = recipe.render_tally
        gauges = [
            ("coshsh_recipe_render_errors",
             "The number of render errors", recipe.render_errors),
            ("coshsh_recipe_render_attempts",
             "The number of template render attempts", tally.attempts),
            ("coshsh_recipe_missing_templates",
             "The number of templates which could not be found", tally.missing),
            # The flag is a gauge of its own because missing_templates carries
            # the same value whether or not absences are tolerated: on its own
            # it cannot distinguish a deliberate omission from a counted
            # failure. With both, a consumer can compute either reading, and
            # the metric set stays additive rather than growing a gauge whose
            # meaning changes with config.
            ("coshsh_recipe_tolerate_missing_templates",
             "Whether this recipe declares missing templates tolerated",
             1 if tally.tolerate_missing else 0),
            # Exported rather than derived: under tolerate_missing_templates the
            # denominator is accountable attempts, so computing this externally
            # would mean reimplementing the policy in PromQL.
            ("coshsh_recipe_render_error_pct",
             "The percentage of failed renderings the abort decision was made on",
             tally.error_pct),
            ("coshsh_recipe_aborted",
             "Whether this run aborted because of template errors",
             1 if aborted else 0),
        ]
        if completed:
            gauges += [
                ("coshsh_recipe_last_generated",
                 "The timestamp when a configuration was generated", time.time()),
                ("coshsh_recipe_last_duration",
                 "The duration of a recipe", time.time() - tic),
                ("coshsh_recipe_last_success",
                 "The timestamp when the recipe successfully ran last time", time.time()),
            ]
        for name, documentation, value in gauges:
            Gauge(name, documentation, registry=registry).set(value)

        if completed:
            # The one labelled gauge, so it does not fit the table above.
            g = Gauge("coshsh_recipe_number_of_objects",
                "The number of objects of a certain type", ['type'],
                registry=registry)
            for objtype in recipe.objects.keys():
                g.labels(type=objtype).set(len(recipe.objects[objtype]))

    def run(self) -> int:
        """Execute every registered recipe's data pipeline.

        For each recipe the sequence is:
            update_item_class_factories -> pid_protect -> collect -> assemble ->
            render -> output -> pid_remove

        If a Prometheus Pushgateway was configured (via ``[prometheus_pushgateway]``
        in the cookbook), timing and object-count metrics are pushed after each
        recipe completes.
        """
        # WHY: Generator delegates to Recipe rather than running the pipeline
        # itself.  Each Recipe encapsulates its own datasources, datarecipients,
        # vaults, Jinja2 environment, class factories, and PID-file lock.
        # Keeping all pipeline logic inside Recipe means Generator stays a thin
        # orchestrator that only knows *which* recipes to run and in what
        # order -- it never touches raw host/application data.  This separation
        # makes it possible to test and reuse Recipe independently (e.g. in
        # unit tests that call recipe.collect() directly) and keeps Generator
        # focused on config parsing and recipe lifecycle management.
        #
        # NOTE: The prometheus_client import is inside a try/except because
        # the library is an optional dependency.  If it is not installed,
        # has_prometheus is set to False and all metrics-related code is skipped.
        try:
            # Gauge is imported here but used in export_recipe_metrics(): this
            # try block is the capability probe for the whole optional
            # dependency, so it names everything the run will need and fails
            # once, up front, rather than part-way through a recipe.
            from prometheus_client import CollectorRegistry, Gauge, push_to_gateway, pushadd_to_gateway
            from prometheus_client.exposition import basic_auth_handler, default_handler
            from urllib.parse import quote_plus
            from socket import gethostname
            has_prometheus = True
            try:
                coshshuser = getpass.getuser()
            except Exception:
                coshshuser = os.getenv("username")
            hostname = gethostname()
            if hasattr(self, "pg_username"):
                pg_auth_handler = lambda url, method, timeout, headers, data: basic_auth_handler(url, method, timeout, headers, data, self.pg_username, self.pg_password)
            else:
                pg_auth_handler = default_handler
        except Exception as e:
            if hasattr(self, "pg_job"):
                logger.critical("problem with prometheus modules: %s" % e, exc_info=1)
            has_prometheus = False
        if has_prometheus and not hasattr(self, "pg_address"):
            has_prometheus = False
        aborted_recipes = 0
        for recipe in self.recipes.values():
            recipe_completed = False
            recipe_aborted = False
            try:
                recipe.update_item_class_factories()
                coshsh.util.switch_logging(logfile=recipe.log_file)
                if recipe.pid_protect():
                    if has_prometheus:
                        registry = CollectorRegistry()
                    tic = time.time()
                    if recipe.collect():
                        recipe.assemble()
                        recipe.render()
                        if recipe.render_tally.too_many_errors:
                            # WHY skipping output() is the entire mechanism:
                            # output() is what calls cleanup_target_dir() and
                            # then writes. Not calling it is precisely what
                            # leaves the previous run's files where they are,
                            # byte for byte. Nothing has to be restored, because
                            # nothing was removed.
                            recipe_aborted = True
                            aborted_recipes += 1
                            logger.error(
                                "recipe %s aborted: %d of %d renderings failed [%s] (%.4f%%, maximum is %s%%). "
                                "nothing was written, the previous output is unchanged",
                                recipe.name, recipe.render_tally.template_errors,
                                recipe.render_tally.accountable_attempts,
                                recipe.render_tally.breakdown,
                                recipe.render_tally.error_pct,
                                recipe.render_tally.max_error_pct)
                        else:
                            recipe.output()
                            recipe_completed = True
                        if has_prometheus:
                            self.export_recipe_metrics(recipe, registry, tic,
                                                       recipe_completed, recipe_aborted)
                    if has_prometheus:
                        try:
                            pushadd_to_gateway(self.pg_address, grouping_key={
                                'hostname': hostname,
                                'username': coshshuser,
                                'cookbook': self.cookbook_files,
                                'recipe': recipe.name
                            }, job=self.pg_job, registry=registry, handler=pg_auth_handler)
                        except Exception as e:
                            logger.warning("could not write to pushgateway "+self.pg_address+": "+str(e))
                    recipe.pid_remove()
            except coshsh.recipe.RecipePidAlreadyRunning:
                logger.info("skipping recipe %s. already running" % (recipe.name))
            except coshsh.recipe.RecipePidNotWritable as e:
                logger.error("skipping recipe %s. cannot write pid file to %s" % (recipe.name, recipe.pid_dir))
            except coshsh.recipe.RecipePidGarbage:
                logger.error("skipping recipe %s. pid file %s contains garbage" % (recipe.name, recipe.pid_file))
            except Exception as exp:
                logger.error("skipping recipe %s (%s)" % (recipe.name, exp))
            else:
                # WHY an aborted recipe gets no "completed" line: "completed
                # with N problems" reads as success-with-caveats to an operator
                # skimming a log and to anything scraping it, and FR-009 forbids
                # reporting an aborted run as a successful completion. The abort
                # itself is already logged at ERROR where it happens, with the
                # numbers it was decided on.
                if recipe_completed:
                    breakdown = recipe.render_tally.breakdown
                    logger.info("recipe %s completed with %d problems out of %d rendering attempts%s",
                                recipe.name, recipe.render_errors, recipe.render_tally.attempts,
                                " [%s]" % breakdown if breakdown else "")
            if self.default_log_level == "debug":
                CoshshDatainterface.dump_classes_usage()
            coshsh.util.restore_logging()
        # WHY a count and not a bool: bin/coshsh-cook turns any non-zero result
        # into exit code 4, but the number is what makes the log and the exit
        # agree when a cookbook holds many recipes and only some of them
        # aborted. Callers that do not care simply ignore it.
        return aborted_recipes

    def read_cookbook(self, cookbook_files: list[str], default_recipe: str | None, force: Any, safe_output: Any) -> None:
        """Parse cookbook INI files and build fully wired Recipe objects.

        Parameters:
            cookbook_files  -- list of filesystem paths to INI cookbook files.
            default_recipe -- comma-separated recipe names from --recipe flag,
                              or None to use the cookbook's [defaults] section.
            force          -- if True, datasources re-read even if cache is fresh.
            safe_output    -- if True, datarecipients guard against accidental
                             mass-deletion of monitoring configs.
        """
        # WHY: Cookbook parsing -- the cookbook is one or more INI files whose
        # section names carry semantic prefixes (``recipe_``, ``datasource_``,
        # ``datarecipient_``, ``vault_``, ``mapping_``).  This method classifies
        # sections by prefix and collects their key-value pairs into dicts so
        # they can later be passed as **kwargs to the appropriate add_*()
        # methods.  The prefix-based convention keeps the cookbook format flat
        # and human-editable while still encoding the type of each component.
        #
        # After collecting all section configs, the method resolves which
        # recipes to run (explicit --recipe flag, ``[defaults].recipes``, or
        # all non-underscore-prefixed recipes).  For each selected recipe it:
        #   1. Instantiates the Recipe (add_recipe)
        #   2. Attaches vaults        (add_vault -- must run first so secrets
        #      are available for datasource/datarecipient password resolution)
        #   3. Attaches datasources   (add_datasource)
        #   4. Attaches datarecipients (add_datarecipient)
        # This ordering is critical; see the ``# WHY: Vault resolution order``
        # comment in recipe.py for details.
        self.cookbook_files = '___'.join(map(lambda cf: Path(cf).resolve().name, cookbook_files))
        recipe_configs = {}
        datasource_configs = {}
        datarecipient_configs = {}
        coshsh_config_mappings = {}
        vault_configs = {}
        recipes = []
        cookbook = coshsh.configparser.CoshshConfigParser()
        self.cookbook = cookbook
        cookbook.read(cookbook_files)
        if cookbook._sections == {}:
            print(f"Bad or missing cookbook files : {', '.join(cookbook_files)} ")
            sys.exit(2)
        for vault in [section for section in cookbook.sections() if section.startswith('vault_')]:
            vault_configs[vault.replace("vault_", "", 1).lower()] = cookbook.items(vault) + [('name', vault.replace("vault_", "", 1).lower())]
        for mapping in [section for section in cookbook.sections() if section.startswith('mapping_')]:
            coshsh_config_mappings[mapping.replace("mapping_", "")] = dict(cookbook.items(mapping))
        for ds in [section for section in cookbook.sections() if section.startswith('datarecipient_')]:
            datarecipient_configs[ds.replace("datarecipient_", "", 1).lower()] = cookbook.items(ds) + [('name', ds.replace("datarecipient_", "", 1).lower())]
        for ds in [section for section in cookbook.sections() if section.startswith('datasource_')]:
            datasource_configs[ds.replace("datasource_", "", 1).lower()] = cookbook.items(ds) + [('name', ds.replace("datasource_", "", 1).lower())]
        for recipe in [section for section in cookbook.sections() if section.startswith('recipe_')]:
            recipe_configs[recipe.replace("recipe_", "", 1).lower()] = cookbook.items(recipe) + [('name', recipe.replace("recipe_", "", 1).lower())]

        if default_recipe:
            recipes = [r.lower() for r in default_recipe.split(",")]
        else:
            if "defaults" in cookbook.sections() and "recipes" in [c[0] for c in cookbook.items("defaults")]:
                recipes = [recipe.lower() for recipe in dict(cookbook.items("defaults"))["recipes"].split(",")]
            else:
                recipes = filter( lambda r: not r.startswith("_"), recipe_configs.keys())
        if "defaults" in cookbook.sections() and "log_dir" in [c[0] for c in cookbook.items("defaults")]:
            log_dir = dict(cookbook.items("defaults"))["log_dir"]
            log_dir = re.sub('%.*?%', coshsh.util.substenv, log_dir)
        elif 'OMD_ROOT' in os.environ:
            log_dir = str(Path(os.environ['OMD_ROOT']) / "var" / "coshsh")
        else:
            log_dir = gettempdir()
        if "defaults" in cookbook.sections() and "pid_dir" in [c[0] for c in cookbook.items("defaults")]:
            pid_dir = dict(cookbook.items("defaults"))["pid_dir"]
            pid_dir = re.sub('%.*?%', coshsh.util.substenv, pid_dir)
        else:
            pid_dir = gettempdir()
        if "defaults" in cookbook.sections() and "backup_count" in [c[0] for c in cookbook.items("defaults")]:
            backup_count = int(dict(cookbook.items("defaults"))["backup_count"])
        else:
            backup_count = 2
        if self.default_log_level and self.default_log_level.lower() == "debug" or "defaults" in cookbook.sections() and "log_level" in [c[0] for c in cookbook.items("defaults")] and cookbook.items("defaults")["log_level"].lower() == "debug":
            coshsh.util.setup_logging(logdir=log_dir, scrnloglevel=DEBUG, backup_count=backup_count)
        else:
            coshsh.util.setup_logging(logdir=log_dir, scrnloglevel=INFO, backup_count=backup_count)
        self.log_dir = log_dir
        logger = getLogger('coshsh')

        for recipe in recipes:
            # WHY: Recipe names in the cookbook can be regex patterns (e.g.
            # ``[recipe_lebensmitteldiscounter_.*_.*]``).  We sort by
            # descending length so that more specific patterns are tried first,
            # giving an exact match priority over a broad wildcard.
            matching_recipes = [r for r in sorted(recipe_configs.keys(), key=lambda x: len(x), reverse=True) if re.match(r, recipe)]
            if recipe in recipe_configs.keys():
                matching_recipes = [recipe]
            elif matching_recipes:
                # [recipe_lebensmitteldiscounter_.*_.*] <- lebensmitteldiscounter_at_hq
                logger.info("no direct hit, but matching recipes found: %s", ", ".join(matching_recipes))
                recipe_configs[recipe] = recipe_configs[matching_recipes[0]]
                recipe_configs[recipe] = [('name', recipe) if kv[0] == 'name' else kv for kv in recipe_configs[recipe]]
            if matching_recipes:
                recipe_configs[recipe].append(('force', force))
                if not [v for k, v in recipe_configs[recipe] if k == "safe_output"] or not [v for k, v in recipe_configs[recipe] if k == "safe_output"][0]:
                    # commandline --safe-output has priority
                    recipe_configs[recipe].append(('safe_output', safe_output))
                if not [c for c in recipe_configs[recipe] if c[0] == 'pid_dir']:
                    recipe_configs[recipe].append(('pid_dir', pid_dir))
                recipe_configs[recipe].append(('coshsh_config_mappings', coshsh_config_mappings))
                self.add_recipe(**dict(recipe_configs[recipe]))
                if recipe not in self.recipes:
                    # something went wrong in add_recipe. we should already see
                    # an error message here.
                    continue
                #self.recipes[recipe].update_ds_dr_class_factories()
                vault_problems = False
                for vault in self.recipes[recipe].vault_names:
                    if vault in vault_configs.keys():
                        try:
                            self.recipes[recipe].add_vault(**dict(vault_configs[vault]))
                        except Exception as e:
                            vault_problems = True
                    else:
                        logger.error("Vault %s is unknown" % vault)
                if vault_problems:
                    # other than datasource and recipient, a vault is
                    # not just instantiated and provisioned with the
                    # attributes from the cookbook. in add_vault it is
                    # already opened and the data are read, because we
                    # need the secrets right now. in add_datasource and
                    # add_datarecipients we might need to resolve
                    # passwords which are a pointer to a vault's record.
                    # if anything goes wrong here, we immediately abort by
                    # removing the affected recipe. the generator then
                    # usually calls run() without running a recipe.
                    del self.recipes[recipe]
                    continue
                for ds in self.recipes[recipe].datasource_names:
                    if ds in datasource_configs.keys():
                        datasource_configs[ds].append(('coshsh_config_mappings', coshsh_config_mappings))
                        self.recipes[recipe].add_datasource(**dict(datasource_configs[ds]))
                    else:
                        logger.error("Datasource %s is unknown" % ds)
                for dr in self.recipes[recipe].datarecipient_names:
                    if dr == "datarecipient_coshsh_default":
                        # implicitely added by recipe.__init__
                        pass
                    elif dr in datarecipient_configs.keys():
                        datarecipient_configs[dr].append(('coshsh_config_mappings', coshsh_config_mappings))
                        self.recipes[recipe].add_datarecipient(**dict(datarecipient_configs[dr]))
                    else:
                        logger.error("Datarecipient %s is unknown" % dr)
            else:
                logger.error("Recipe %s is unknown" % recipe)

        if "prometheus_pushgateway" in cookbook.sections() and "address" in [c[0] for c in cookbook.items("prometheus_pushgateway")]:
            self.add_pushgateway(**dict(cookbook.items("prometheus_pushgateway")))
