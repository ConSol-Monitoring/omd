#!/usr/bin/env python
#-*- coding: utf-8 -*-
#
# This file belongs to coshsh.
# Copyright Gerhard Lausser.
# This software is licensed under the
# GNU Affero General Public License version 3 (see the file LICENSE).

"""Base class for all coshsh configuration objects (Host, Application,
Contact, HostGroup, ContactGroup).

Sole responsibility: provide template rendering and monitoring detail
resolution so that every configuration object can turn itself into one or
more output files for any monitoring tool.

This module does NOT handle plugin/class discovery -- that logic lives in
datainterface.py (CoshshDatainterface).
"""

from __future__ import annotations

import logging
import re
from copy import copy, deepcopy
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, TemplateNotFound, TemplateSyntaxError

import coshsh

logger = logging.getLogger('coshsh')


class EmptyObject:
    pass


class _TemplateFailure:
    """Remembers that a template could not be loaded, and why.

    Stored in the render pass's template_cache in place of the Template that
    could not be built, so a broken or absent template is read and parsed once
    per recipe run rather than once per object that references it. Without this
    a single bad template in a 60,000-object recipe means 60,000 file reads,
    60,000 parses and 60,000 identical tracebacks in the log.

    It does not change any count: every object referencing the template still
    records its own failure, because a rendering that did not happen is a
    rendering that did not happen however many objects shared the cause.
    """

    __slots__ = ("outcome",)

    def __init__(self, outcome: str) -> None:
        # coshsh.rendertally.MISSING or coshsh.rendertally.ERROR
        self.outcome = outcome


class Item(coshsh.datainterface.CoshshDatainterface):
    template_cache = {}

    @classmethod
    def reload_template_path(cls) -> None:
        loader = FileSystemLoader(cls.templates_path)
        cls.env = Environment(loader=loader)
        cls.env.trim_blocks = True

    def __init__(self, params: dict[str, Any] | None = None) -> None:
        """Initialise an Item from a dict of datasource parameters.

        Each key/value pair in *params* becomes an instance attribute.
        String values are stripped of surrounding whitespace unless the
        subclass opts out via ``dont_strip_attributes`` (bool or list).

        Sets up three core bookkeeping structures:
        - ``monitoring_details``: list of detail objects waiting to be
          resolved onto this item (see ``resolve_monitoring_details``).
        - ``config_files``: rendered output, ready to be written to disk.
        - ``object_chronicle``: audit trail of notable events for this
          object.
        """
        if params is None:
            params = {}
        for key in params:
            if hasattr(self, "dont_strip_attributes") and isinstance(params[key], str):
                if isinstance(self.dont_strip_attributes, bool) and self.dont_strip_attributes == True:
                    setattr(self, key, params[key])
                elif isinstance(self.dont_strip_attributes, list) and key in self.dont_strip_attributes:
                    setattr(self, key, params[key])
                else:
                    setattr(self, key, params[key].strip())
            elif isinstance(params[key], str):
                setattr(self, key, params[key].strip())
            else:
                setattr(self, key, params[key])

        if not hasattr(self, "monitoring_details"):
            # if not pre-set through the class
            self.monitoring_details = []
        else:
            setattr(self, "monitoring_details", list(self.__class__.monitoring_details))
        # WHY: config_files is a dict keyed by tool name (e.g. 'nagios',
        # 'prometheus') because different datarecipients route output to
        # different monitoring tools.  Each tool key maps to another dict of
        # {filename: rendered_content}, allowing a single Item to produce
        # output for multiple backends in a single render pass.
        self.config_files = {}
        self.object_chronicle = []

    def record_in_chronicle(self, message: str = "") -> None:
        if message:
            self.object_chronicle.append(message)

    def write_config(self, target_dir: str, want_tool: str | None = None) -> None:
        """Write all rendered config files for this item to disk.

        Creates a per-host subdirectory under *target_dir*/hosts/ and
        writes every file previously stored in ``self.config_files``.
        If *want_tool* is given, only files for that specific monitoring
        tool are written (e.g. ``want_tool='nagios'``); otherwise all
        tools are written.
        """
        my_target_dir = Path(target_dir) / "hosts" / self.host_name
        my_target_dir.mkdir(parents=True, exist_ok=True)
        for tool in self.config_files:
            if not want_tool or want_tool == tool:
                for file in self.config_files[tool]:
                    content = self.config_files[tool][file]
                    with open(my_target_dir / file, "w") as f:
                        f.write(content)

    def resolve_monitoring_details(self) -> None:
        """Flatten monitoring detail objects into attributes on this item.

        Each monitoring detail carries data from the datasource (e.g. a
        filesystem to monitor, a TCP port, login credentials).  Resolution
        walks the detail list and sets, appends, or merges each detail's
        payload onto the parent object.  After resolution the item has
        concrete attributes such as ``filesystems``, ``login``, ``ports``,
        ``urls``, ``services``, etc. that templates can reference directly.

        Details are consumed (removed from ``self.monitoring_details``) so
        that calling this method again is safe and idempotent.
        """
        details = list(self.monitoring_details)
        for detail in details:
            detail.resolve_onto(self)
        self.monitoring_details.clear()
        self.wemustrepeat()
        # example: if we have self.ports
        # and self.ports[0] has an inside property ports
        # and self has d default property port (set in __init__)
        # replace the self.port by self.ports[0].port
        for one_property in [detail.__class__.property.rstrip('s') for detail in details if detail.__class__.property_type == list and not hasattr(detail.__class__, "unique_attribute") and not hasattr(detail.__class__, "property_attr") and detail.__class__.property.endswith('s') and hasattr(self, detail.__class__.property.rstrip('s'))]:
            if hasattr(getattr(self, one_property + 's')[0], one_property):
                setattr(self, one_property, getattr(getattr(self, one_property + 's')[0], one_property))

    def wemustrepeat(self) -> None:
        """
        This method is called by some classes if different monitoring_details need to interact.
        Ex. (username/password was set in a LOGIN detail and/or a URL detail
        The name is a tribute to my favorite band.
        https://www.youtube.com/watch?v=hRguZr0xCOc&feature=youtu.be&t=212
        """
        # WHY: this is a post-detail-resolution hook.  It runs after ALL
        # monitoring_details have been promoted to attributes on the object
        # but before create_templates/create_hostgroups/create_contacts.
        # Subclasses override it to perform cross-detail reconciliation
        # (e.g. merging LOGIN credentials into URL details, setting host
        # macros from application details, or adding hostgroups based on
        # detail values).  The base implementation is intentionally a no-op.
        pass

    # WHY: datasources deliver list-type attributes as comma-separated
    # strings (Nagios format).  pythonize converts them to Python lists
    # so code can use append/extend/set operations.  depythonize is the
    # inverse, called before rendering to restore Nagios-compatible CSV.
    # The render_cfg_template cycle is: depythonize → render → pythonize,
    # so list form is the "resting state" between renders.  Note that
    # depythonize deduplicates and sorts all attributes EXCEPT templates
    # (template ordering matters for Nagios config inheritance).
    _csv_attributes = (
        "templates", "contactgroups", "contact_groups", "contacts",
        "hostgroups", "servicegroups", "members", "parents",
        "host_notification_commands", "service_notification_commands",
    )
    _no_dedup_csv_attributes = frozenset(("templates",))

    def pythonize(self) -> None:
        for attr in self._csv_attributes:
            val = getattr(self, attr, None)
            if val is not None and isinstance(val, str):
                setattr(self, attr, val.split(','))

    def depythonize(self) -> None:
        for attr in self._csv_attributes:
            val = getattr(self, attr, None)
            if val is not None and isinstance(val, list):
                if attr in self._no_dedup_csv_attributes:
                    setattr(self, attr, ",".join(val))
                else:
                    setattr(self, attr, ",".join(sorted(set(val))))

    def render_cfg_template(self, jinja2: Any, template_cache: dict[str, Any], name: str, output_name: str, suffix: str, for_tool: str, _skip_pythonize: bool = False, tally: Any = None, **kwargs: Any) -> int:
        """Load a single Jinja2 template and render it into ``config_files``.

        Parameters
        ----------
        jinja2 : object
            Object whose ``env`` attribute is a Jinja2 Environment.
        template_cache : dict
            Shared cache mapping template names to compiled Template objects.
        name : str
            Logical template name (without ``.tpl`` extension).
        output_name : str
            Base filename for the rendered output.
        suffix : str
            File extension appended to *output_name* (e.g. ``'cfg'``).
            When empty the file is written without an extension.
        for_tool : str
            Monitoring tool key (e.g. ``'nagios'``, ``'prometheus'``)
            under which the output is stored in ``self.config_files``.
        tally : RenderTally or None
            Where this attempt and its outcome are recorded.  ``None`` means
            "do not count" and never raises -- see the WHY note below.
        **kwargs
            Extra variables passed into the Jinja2 render context
            (typically ``self`` and the active recipe).

        Returns
        -------
        int
            Number of rendering errors encountered (0 on success).  Note that
            ``tally`` -- not this value -- is what the recipe counts with; the
            return value is a convenience for callers holding no tally.
        """
        # WHY tally is an explicit parameter and not kwargs["recipe"]: the
        # recipe does travel in **kwargs, but only because Item.render() packs
        # it there for the Jinja2 namespace, whose keys come from template-rule
        # configuration (rule.self_name).  Reaching into that dict would couple
        # the counting to an unrelated namespace and would silently count
        # nothing if a caller ever omitted "recipe".  Defaulting to None keeps
        # the parameter optional for callers outside this repository, and its
        # absence means "do not count" rather than an AttributeError.
        #
        # Exactly one outcome per call, recorded once at the end: a template
        # that fails to load never reaches the render block, so the two failure
        # regions below are mutually exclusive.
        outcome = coshsh.rendertally.OK
        cached = template_cache.get(name)
        if cached is None:
            try:
                cached = template_cache[name] = jinja2.env.get_template(name + ".tpl")
                logger.info("load template " + name)
            except TemplateSyntaxError as e:
                logger.critical("%s template %s has an error in line %d: %s" % (self.__class__.__name__, name, e.lineno, e.message), exc_info=1)
                cached = template_cache[name] = _TemplateFailure(coshsh.rendertally.ERROR)
            except TemplateNotFound:
                # WHY this logs at ERROR even for a recipe that tolerates absent
                # templates, and why the wording is fixed: tolerating an absence
                # suppresses the *verdict* (it leaves the abort percentage), never
                # the evidence. Deployments grep for this exact string to find a
                # half-deployed template pack, so keep the level and the phrasing.
                logger.error("cannot find template " + name)
                cached = template_cache[name] = _TemplateFailure(coshsh.rendertally.MISSING)
            except Exception as exp:
                logger.critical("error in template %s (%s,%s)" % (name, exp.__class__.__name__, exp), exc_info=1)
                cached = template_cache[name] = _TemplateFailure(coshsh.rendertally.ERROR)
        elif isinstance(cached, _TemplateFailure):
            # Same broken template, another object. It was already reported in
            # full, so repeating it here would only bury the run's other output
            # under thousands of identical tracebacks.
            #
            # DEBUG and not INFO because this is per-object: at 60,000 objects
            # even a one-line message is a log storm. Note where DEBUG goes --
            # the file handler is pinned at INFO (coshsh.util.setup_logging), so
            # these reach the console under --debug and never the log file.
            # That is the right trade here: a template that fails to *load* is
            # broken for every object equally, so which ones hit it adds little.
            # A failure while *rendering* is genuinely object-specific, and that
            # one still logs per object at CRITICAL further down.
            logger.debug("template %s already failed to load (%s), skipping it for %s",
                         name, cached.outcome, self)

        if isinstance(cached, _TemplateFailure):
            outcome = cached.outcome
        else:
            if not _skip_pythonize:
                # transform hostgroups, contacts, etc. from list to string
                self.depythonize()
            try:
                if not for_tool in self.config_files:
                    self.config_files[for_tool] = {}
                if suffix:
                    self.config_files[for_tool][output_name + "." + suffix] = cached.render(kwargs)
                else:
                    # files without suffix
                    self.config_files[for_tool][output_name] = cached.render(kwargs)
            except Exception as exp:
                if hasattr(self, "fingerprint"):
                    logger.critical("render exception in template %s for %s %s: %s" % (name, self, self.fingerprint(), exp), exc_info=1)
                else:
                    logger.critical("render exception in template %s for %s: %s" % (name, self, exp), exc_info=1)
                # Not an early return: pythonize() below must run either way, or
                # this object's list attributes stay in their string form and
                # every later rule renders them wrong.
                outcome = coshsh.rendertally.ERROR
            if not _skip_pythonize:
                # transform hostgroups, contacts, etc. back to lists
                self.pythonize()

        if tally is not None:
            tally.record(outcome)
        return 0 if outcome == coshsh.rendertally.OK else 1

    def render(self, template_cache: dict[str, Any], jinja2: Any, recipe: Any) -> int:
        """Render all applicable template rules for this item.

        Iterates over ``self.template_rules`` and evaluates each rule's
        conditions (``needsattr`` / ``isattr``) against the current
        object state.  When a rule matches it delegates to
        ``render_cfg_template`` to produce the output.

        Returns the total number of render errors across all rules.
        """
        render_errors = 0
        if not hasattr(self, 'template_rules'):
            return render_errors
        self.depythonize()
        for rule in self.template_rules:
            try:
                render_this = rule.matches(self)
            except Exception as e:
                logger.critical("error in %s template rules. please check %s. Error was: %s" % (self.__class__.__name__, rule, str(e)), exc_info=1)
                render_errors += 1
                # A rule that should have produced output and did not is a failed
                # rendering, so it counts as an attempt too -- excluding it would
                # flatter the percentage the abort decision is made on.
                recipe.render_tally.record(coshsh.rendertally.ERROR)
                render_this = False

            if render_this:
                # WHY: unique_config generates per-instance filenames
                # (e.g. one file per filesystem, one per URL) by
                # interpolating unique_attr values into a format string.
                # Default (else branch) generates one file per template
                # rule, using the template name as the output filename.
                if rule.unique_config and isinstance(rule.unique_attr, str) and hasattr(self, rule.unique_attr):
                    output_name = rule.unique_config % getattr(self, rule.unique_attr)
                elif rule.unique_config and isinstance(rule.unique_attr, list) and all(hasattr(self, ua) for ua in rule.unique_attr):
                    output_name = rule.unique_config % tuple(getattr(self, a) for a in rule.unique_attr)
                else:
                    output_name = rule.template
                render_errors += self.render_cfg_template(
                    jinja2, template_cache, rule.template, output_name,
                    rule.suffix, rule.for_tool, _skip_pythonize=True,
                    tally=recipe.render_tally,
                    **dict([(rule.self_name, self), ("recipe", recipe)]))
        self.pythonize()
        return render_errors

    def fingerprint(self) -> str:
        try:
            return f"{self.host_name}+{self.name}+{self.type}"
        except AttributeError:
            pass
        try:
            return f"{self.host_name}"
        except AttributeError:
            pass
        raise AttributeError("impossible fingerprint")

