define servicegroup {
  servicegroup_name {{ servicegroup.servicegroup_name }}
{% if servicegroup.alias %}
    alias              {{ servicegroup.alias }}
{% endif %}
}
