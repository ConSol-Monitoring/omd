from coshsh.host import Host
from coshsh.application import Application
from tests.common_coshsh_test import CommonCoshshTest

class CoshshTest(CommonCoshshTest):

    def tearDown(self):
        pass

    def test_nagiosconf(self):
        # todo: NAGIOSCONF
        pass

