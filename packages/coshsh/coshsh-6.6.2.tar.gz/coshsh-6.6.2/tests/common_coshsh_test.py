import os
import sys
import unittest
from configparser import RawConfigParser
import shutil
import coshsh
from coshsh.generator import Generator
from coshsh.host import Host

sys.dont_write_bytecode = True

class CommonCoshshTest(unittest.TestCase):
    def print_header(self):
        print("#" * 80 + "\n" + "#" + " " * 78 + "#")
        print("#" + str.center(self.id(), 78) + "#")
        print("#" + " " * 78 + "#\n" + "#" * 80 + "\n")

    def setUp(self):
        self.called_from_dir = os.getcwd()
        self.tests_run_in_dir = os.path.dirname(os.path.realpath(__file__))
        self.coshsh_base_dir = os.path.dirname(self.tests_run_in_dir)
        os.chdir(self.tests_run_in_dir)
        if not self.tests_run_in_dir in sys.path:
            sys.path.append(self.coshsh_base_dir)
        self.generator = coshsh.generator.Generator()
        setup_logging()
        if hasattr(self, "mySetUp"):
            getattr(self, "mySetUp")()
        if hasattr(self, "_configfile"):
            self.setUpConfig()
        if hasattr(self, "_objectsdir"):
            self.setUpObjectsDir()
        if hasattr(self, "mySetUpRm"):
            getattr(self, "mySetUpRm")()
        if hasattr(self, "mySetUpMk"):
            getattr(self, "mySetUpMk")()

    def setUpConfig(self):
        self.config = RawConfigParser()
        self.config.read(self._configfile)

    def setUpObjectsDir(self):
        shutil.rmtree(self._objectsdir, True)
        os.makedirs(self._objectsdir)

    def tearDown(self):
        if hasattr(self, '_objectsdir'):
            shutil.rmtree(self._objectsdir, True)
        os.chdir(self.called_from_dir)
