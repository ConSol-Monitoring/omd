#!/usr/bin/env python
#-*- encoding: utf-8 -*-
#
# Copyright Gerhard Lausser.
# This software is licensed under the
# GNU Affero General Public License version 3 (see the file LICENSE).

import csv
import os
import sys
import re
import socket
import logging
import yaml
import time
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
import shutil
import ipaddress
from pysnmp.hlapi import *
from pysnmp.smi import builder, view, compiler, error
import pprint

import coshsh
from coshsh.datasource import Datasource, DatasourceNotAvailable, DatasourceCorrupt
from coshsh.host import Host
from coshsh.application import Application
from coshsh.item import Item
from coshsh.contactgroup import ContactGroup
from coshsh.contact import Contact
from coshsh.monitoringdetail import MonitoringDetail
from coshsh.templaterule import TemplateRule
from coshsh.util import compare_attr

logger = logging.getLogger('coshsh')

def __ds_ident__(params={}):
    if coshsh.util.compare_attr("type", params, "discard"):
        return DsDiscard


class DsDiscard(coshsh.datasource.Datasource):
    def __init__(self, **kwargs):
        super(self.__class__, self).__init__(**kwargs)

    def read(self, filter=None, objects={}, force=False, **kwargs):
        self.objects = objects
        for k in self.objects.keys():
            self.objects[k] = {}
