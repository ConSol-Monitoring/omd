import unittest
import os
import sys
import shutil
from optparse import OptionParser
from configparser import RawConfigParser

sys.dont_write_bytecode = True

import coshsh
from coshsh.generator import Generator
from coshsh.datasource import Datasource
from coshsh.application import Application
from coshsh.monitoringdetail import MonitoringDetail
from coshsh.util import setup_logging


class CoshshTest(unittest.TestCase):
    def print_header(self):
        print("#" * 80 + "\n" + "#" + " " * 78 + "#")
        print("#" + str.center(self.id(), 78) + "#")
        print("#" + " " * 78 + "#\n" + "#" * 80 + "\n")

    def setUp(self):
        shutil.rmtree("./var/objects/test6", True)
        os.makedirs("./var/objects/test6")
        self.config = RawConfigParser()
        self.config.read('etc/coshsh.cfg')
        self.generator = coshsh.generator.Generator()
        setup_logging()
        self.generator.add_recipe(name='test6', **dict(self.config.items('recipe_TEST6')))
        self.config.set("datasource_CSVDETAILS", "name", "test6")

    def tearDown(self):
        shutil.rmtree("./var/objects/test6", True)
        print()

    def test_detail_dbpw(self):
        self.print_header()
        cfg = self.config.items("datasource_CSVDETAILS")
        objects = self.generator.recipes['test6'].objects
        ds = coshsh.datasource.Datasource(**dict(cfg))
        #ds.read(objects=objects)
        ds.objects = objects


        for hindex in range(10):
            host = coshsh.host.Host({"host_name": "test"+str(hindex)})
            ds.add('hosts', host)
            db = coshsh.application.Application({"host_name": "test"+str(hindex), "name": "db", "type": "oracle"})
            os = coshsh.application.Application({"host_name": "test"+str(hindex), "name": "os", "type": "linux"})
            ds.add('applications', db)
            ds.add('applications', os)

        login = coshsh.monitoringdetail.MonitoringDetail({
            'host_name': '*',
            'name': 'db',
            'type': 'oracle',
            'monitoring_type': 'LOGIN',
            'monitoring_0': 'haerpfer',
            'monitoring_1': 'n3rv3ns43ge',
        })
        ds.add('details', login)
        andi = coshsh.monitoringdetail.MonitoringDetail({
            'host_name': 'test5',
            'name': 'db',
            'type': 'oracle',
            'monitoring_type': 'LOGIN',
            'monitoring_0': 'andi',
            'monitoring_1': 'n3rv3ns43ge',
        })
        ds.add('details', andi)

        palim = coshsh.monitoringdetail.MonitoringDetail({
            'host_name': '*',
            'monitoring_type': 'CUSTOMMACRO',
            'monitoring_0': 'OTTO',
            'monitoring_1': 'palim',
        })
        ds.add('details', palim)
        troeoet = coshsh.monitoringdetail.MonitoringDetail({
            'host_name': 'test4',
            'monitoring_type': 'CUSTOMMACRO',
            'monitoring_0': 'OTTO',
            'monitoring_1': 'troeoet',
        })
        ds.add('details', troeoet)

        self.generator.recipes['test6'].assemble()

        for app in ds.getall('applications'):
            if app.type == 'oracle':
                self.assertTrue(hasattr(app, 'login'))
                if app.host_name == 'test5':
                    self.assertTrue(app.login.username == 'andi')
                else:
                    self.assertTrue(app.login.username == 'haerpfer')
        for host in ds.getall('hosts'):
            if host.host_name == 'test4':
                self.assertTrue(host.custom_macros['OTTO'] == 'troeoet')
            else:
                self.assertTrue(host.custom_macros['OTTO'] == 'palim')


if __name__ == '__main__':
    unittest.main()


