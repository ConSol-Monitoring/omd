# 0.0.1 - 27.09.2016
## Features:
- Ping mode - tests if InfluxDB is alive
- Disk mode - measures the disk usage
- Number of Services/Measurements
- Difference of Services/Measurements