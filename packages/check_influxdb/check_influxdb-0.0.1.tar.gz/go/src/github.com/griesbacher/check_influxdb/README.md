# check_influxdb
Monitoring Plugin to check the health of an InfluxDB
