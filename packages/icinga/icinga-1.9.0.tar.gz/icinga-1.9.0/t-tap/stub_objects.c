/* Stub file for common/objects.c */
service * find_service(char *host_name, char *svc_desc) {}
host * find_host(char *name) {}
hostgroup * find_hostgroup(char *name) {}
contactgroup * find_contactgroup(char *name) {}
servicegroup * find_servicegroup(char *name) {}
contact * find_contact(char *name) {}
command * find_command(char *name) {}
timeperiod * find_timeperiod(char *name) {}

