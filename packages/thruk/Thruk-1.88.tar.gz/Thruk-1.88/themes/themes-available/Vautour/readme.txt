Vautour Style


1. DESCRIPTION

Vautour Style is a skin for Nagios 3.X.
Original stylesheets and original icons have been modified to provide a different presentation for the Nagios web interface.


2. CREDITS

Vautour Style have been created by Yoann LAMY.
The menu of Vautour Style use the javascript framework MooTools (http://mootools.net/).
The icons of Vautour Style use "Silk icon set" (http://www.famfamfam.com/lab/icons/silk/) created by Mark James. "Silk icon set" is licensed under Creative Commons Attribution 2.5 License (http://creativecommons.org/licenses/by/2.5/).


3. INSTALL

Extract the contents of this ZIP file in the Nagios web content folder (usually /usr/local/nagios/share/) : unzip vautour_style.zip -d /usr/local/nagios/share/