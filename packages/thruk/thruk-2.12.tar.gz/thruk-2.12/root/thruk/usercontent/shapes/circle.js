// See http://docs.sencha.com/extjs/4.1.1/#!/api/Ext.draw.Sprite
type: "circle",
radius: "100",
x: 50,
y: 50
