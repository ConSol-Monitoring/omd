#!/bin/bash
# vim: expandtab:ts=4:sw=4:syntax=perl

# read rc files if exist
unset PROFILEDOTD
[ -e /etc/thruk/thruk.env  ] && . /etc/thruk/thruk.env
[ -e ~/etc/thruk/thruk.env ] && . ~/etc/thruk/thruk.env
[ -e ~/.thruk              ] && . ~/.thruk
[ -e ~/.profile            ] && . ~/.profile

BASEDIR=$(dirname $0)/..

# git version
if [ -d $BASEDIR/.git -a -e $BASEDIR/lib/Thruk.pm ]; then
  export PERL5LIB="$BASEDIR/lib:$PERL5LIB";
  if [ "$OMD_ROOT" != "" -a "$THRUK_CONFIG" = "" ]; then export THRUK_CONFIG="$OMD_ROOT/etc/thruk"; fi
  if [ "$THRUK_CONFIG" = "" ]; then export THRUK_CONFIG="$BASEDIR/"; fi

# omd
elif [ "$OMD_ROOT" != "" ]; then
  export PERL5LIB=$OMD_ROOT/share/thruk/lib:$PERL5LIB
  if [ "$THRUK_CONFIG" = "" ]; then export THRUK_CONFIG="$OMD_ROOT/etc/thruk"; fi

# pkg installation
else
  export PERL5LIB=$PERL5LIB:@DATADIR@/lib:@THRUKLIBS@;
  if [ "$THRUK_CONFIG" = "" ]; then export THRUK_CONFIG='@SYSCONFDIR@'; fi
fi

eval 'exec perl -x $0 ${1+"$@"} ;'
    if 0;
# / this slash makes vscode syntax highlighting work
#! -*- perl -*-
#line 35

use warnings;
use strict;
use Cpanel::JSON::XS qw(encode_json);
use LWP::Simple qw(get);

use Thruk::Controller::rest_v1 ();

my $output_file = "lib/Thruk/Controller/Rest/V1/livestatus_docs.pm";
my $source_url  = "https://raw.githubusercontent.com/naemon/naemon.github.io/refs/heads/master/src/documentation/usersguide/livestatus.columns.json";

# ── 1. Fetch Naemon livestatus columns JSON ─────────────────────────────
my $json_text = get($source_url);
die("failed to fetch $source_url\n") unless $json_text;
my $raw = eval { Cpanel::JSON::XS::decode_json($json_text) };
die("failed to parse JSON: $@\n") if $@;

# ── 2. Table → REST path mapping ────────────────────────────────────────
# Each naemon table generates two endpoints: list and single-item
my %table_paths = (
    hosts               =>        ['/hosts',                    '/hosts/<name>'],
    services            =>        ['/services',                 '/services/<host>/<service>'],
    hostgroups          =>        ['/hostgroups',               '/hostgroups/<name>'],
    servicegroups       =>        ['/servicegroups',            '/servicegroups/<name>'],
    contacts            =>        ['/contacts',                 '/contacts/<name>'],
    contactgroups       =>        ['/contactgroups',            '/contactgroups/<name>'],
    comments            =>        ['/comments',                 '/comments/<id>'],
    downtimes           =>        ['/downtimes',                '/downtimes/<id>'],
    timeperiods         =>        ['/timeperiods',              '/timeperiods/<name>'],
    commands            =>        ['/commands',                 '/commands/<name>'],
    hostsbygroup        =>        ['/hostsbygroup',             '/hostsbygroup/<hostgroup>'],
    servicesbygroup     =>        ['/servicesbygroup',          '/servicesbygroup/<servicegroup>'],
    servicesbyhostgroup =>        ['/servicesbyhostgroup',      '/servicesbyhostgroup/<hostgroup>'],
    log                 =>        ['/logs'],
    status              =>        ['/processinfo']
);

# Type mapping: naemon documentation types → thruk types
my %type_map = (
    int    => 'number',
    float  => 'number',
    string => 'string',
    list   => 'array_of_strings',
    dict   => 'string',
);

# ── 3. Parse naemon columns and group by table ──────────────────────────
my %table_columns;
for my $entry (@$raw) {
    my($table, $column, $description, $naemon_type) = @$entry;
    push @{$table_columns{$table}}, {
        name        => $column,
        description => $description,
        naemon_type => $naemon_type,
    };
}

# ── 4. Build the output JSON ────────────────────────────────────────────
my %output;
for my $table (sort keys %table_paths) {
    my @columns = @{$table_columns{$table} // []};
    next unless @columns;

    my $cols = [];
    for my $c (@columns) {
        my $type = $type_map{$c->{naemon_type}} // 'string';
        $type = 'time' if $type eq 'number' && ($c->{description} =~ m/\bunix\s+timestamp\b/imx || $c->{name} eq 'last_log_rotation');
        my($guessed_type, $unit) = Thruk::Controller::rest_v1::guess_field_type($table_paths{$table}->[0], $c->{name});
        push @$cols, {
            name        => $c->{name},
            type        => $type,
            unit        => $type eq $guessed_type ? $unit : '',
            description => $c->{description},
        };
    }

    for my $path (@{$table_paths{$table}}) {
        $output{$path}{GET}{columns} = $cols;
    }
}

# ── 5. Write the output file (only replace the __DATA__ section) ────────
my $header = <<'HEADER';
package Thruk::Controller::Rest::V1::livestatus_docs;

use warnings;
use strict;
use Cpanel::JSON::XS qw/decode_json/;

=head1 NAME

Thruk::Controller::Rest::V1::livestatus_docs - Livestatus table column metadata

=head1 DESCRIPTION

Contains column attributes for Livestatus table endpoints like /hosts and /services.
These are merged with endpoint-specific docs at runtime.

Generated from naemon.github.io livestatus.columns.json

=head1 METHODS

=head2 keys

    keys()

returns raw attributes for livestatus rest endpoints

=cut

##########################################################
sub keys {
    our $doc_data;
    if(!$doc_data) {
        my $data = "";
        while(<DATA>) {
            my $line = $_;
            next if $line =~ m/^\s*\#/mx;
            next if $line =~ m/^\s*$/mx;
            $data .= $line;
        }
        $doc_data = decode_json($data);
    }
    return($doc_data);
}

##########################################################

1;

__DATA__
HEADER

my $encoder = Cpanel::JSON::XS->new->utf8->canonical->pretty->indent_length(1)->space_before(0);
my $json = $encoder->encode(\%output);
$json   .= "\n" unless $json =~ m/\n\z/;

my $updated = 0;
my $content;
if(-e $output_file) {
    open(my $in, '<', $output_file) or die "cannot read $output_file: $!";
    local $/;
    my $existing = <$in>;
    close($in);

    my $marker = "__DATA__\n";
    my $pos    = index($existing, $marker);

    die "cannot update $output_file: '__DATA__' marker not found\n" if $pos < 0;
    $content = substr($existing, 0, $pos + length($marker)) . $json;
    $updated = 1;
} else {
    # first run: create the file including the default header above
    $content = $header . $json;
}

open(my $fh, '>', $output_file) or die "cannot write $output_file: $!";
print $fh $content;
close($fh);

print $updated ? "Updated __DATA__ section of $output_file (header preserved)\n" : "Generated $output_file\n";
printf "  Tables: %d\n", scalar keys %table_paths;
printf "  Endpoints: %d\n", scalar keys %output;

# Report tables in source but not mapped
for my $table (sort keys %table_columns) {
    if (!exists $table_paths{$table}) {
        printf "  WARNING: unmapped table '%s' (%d columns)\n", $table, scalar @{$table_columns{$table}};
    }
}
