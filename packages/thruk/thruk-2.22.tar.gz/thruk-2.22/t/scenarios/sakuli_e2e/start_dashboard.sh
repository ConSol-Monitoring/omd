#!/bin/bash

cd $SAKULI_ROOT/sahi/userdata/bin/
./start_dashboard.sh &
