# Security Policy

## Supported Versions

This is an open source project and professional support is available from 

- https://www.consol.com/product-solutions/open-source-monitoring/

Besides that always the last stable release is supported but response is limited due to my spare time.

## Reporting a Vulnerability

Please report securtiy related issues here:

- https://github.com/sni/Thruk/security
- or by email at security (at) thruk.org
