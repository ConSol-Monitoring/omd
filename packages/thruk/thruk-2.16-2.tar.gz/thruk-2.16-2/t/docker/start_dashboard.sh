#!/bin/bash

cd sakuli/sahi/userdata/bin/
./start_dashboard.sh &
