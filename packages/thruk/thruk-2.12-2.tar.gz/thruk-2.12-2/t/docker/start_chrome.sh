#!/bin/bash

/usr/bin/google-chrome --no-sandbox --no-default-browser-check --no-first-run --disable-infobars --user-data-dir=/tmp
