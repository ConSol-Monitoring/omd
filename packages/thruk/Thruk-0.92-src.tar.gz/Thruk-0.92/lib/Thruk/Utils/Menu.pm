package Thruk::Utils::Menu;

=head1 NAME

Thruk::Utils::Menu - Menu Utilities Collection for Thruk

=head1 DESCRIPTION

Menu Utilities Collection for Thruk

=cut

use strict;
use warnings;
use Carp;
use Data::Dumper;
use File::Slurp;


##############################################
=head1 METHODS

=head2 read_navigation

  read_navigation()

reads the navigation

=cut
sub read_navigation {
    my $c = shift;

    $c->stats->profile(begin => "Utils::Menu::read_navigation()");

    my $file = $c->config->{'project_root'}.'/menu.conf';
    $file    = $c->config->{'project_root'}.'/menu_local.conf' if -e $c->config->{'project_root'}.'/menu_local.conf';
    if(defined $ENV{'CATALYST_CONFIG'}) {
        $file = $ENV{'CATALYST_CONFIG'}.'/menu.conf'       if -e $ENV{'CATALYST_CONFIG'}.'/menu.conf';
        $file = $ENV{'CATALYST_CONFIG'}.'/menu_local.conf' if -e $ENV{'CATALYST_CONFIG'}.'/menu_local.conf';
    }

    if( exists $c->config->{'cache_navigation'} and $c->config->{'cache_navigation'} == 0 ) {
        _renew_navigation($c, $file);
    }
    else {
        # (dev,ino,mode,nlink,uid,gid,rdev,size,atime,mtime,ctime,blksize,blocks)
        my @menu_conf_stat = stat($file);
        my $last_stat = $c->cache->get('menu_conf_stat');
        if(!defined $last_stat
           or $last_stat->[1] != $menu_conf_stat[1] # inode changed
           or $last_stat->[9] != $menu_conf_stat[9] # modify time changed
          ) {
            $c->log->info("menu.conf has changed, updating...") if defined $last_stat;
            $c->cache->set('menu_conf_stat', \@menu_conf_stat);

            _renew_navigation($c, $file);
        } elsif(!$c->config->{'cache_navigation'}) {
            _renew_navigation($c, $file);
        } else {
            # return cached version
            $c->stash->{'navigation'}  = $c->cache->get('navigation');
        }
    }

    $c->stats->profile(end => "Utils::Menu::read_navigation()");

    return;
}


##############################################

=head2 add_section

  add_section()

add a new section

=cut
sub add_section {
    my %section = @_;
    $section{'links'} = [];
    $section{'icon'}  = '' unless defined $section{'icon'};
    push(@{$Thruk::Utils::Menu::navigation}, \%section);
    return;
}


##############################################

=head2 add_link

  add_link()

add a new link to last section

=cut
sub add_link {
    my %link = @_;
    my $last_section = $Thruk::Utils::Menu::navigation->[scalar @{$Thruk::Utils::Menu::navigation} - 1];
    $link{'links'}  = [] unless defined $link{'links'};
    $link{'target'} = _get_menu_target() unless defined $link{'target'};
    $link{'href'}   = _get_menu_link($link{'href'});
    push(@{$last_section->{'links'}}, \%link);
    return;
}


##############################################

=head2 add_sub_link

  add_sub_link()

add a new sub link to last link

=cut
sub add_sub_link {
    my %link = @_;
    my $last_section = $Thruk::Utils::Menu::navigation->[scalar @{$Thruk::Utils::Menu::navigation} - 1];
    my $last_link    = $last_section->{'links'}->[scalar @{$last_section->{'links'}} - 1];
    $link{'target'}  = _get_menu_target() unless defined $link{'target'};
    $link{'links'}   = [] unless defined $link{'links'};
    $link{'href'}    = _get_menu_link($link{'href'});
    $link{'name'}    = "" unless defined $link{'name'};
    push(@{$last_link->{'links'}}, \%link);
    return;
}


##############################################

=head2 add_sub_sub_link

  add_sub_sub_link()

add a new additional link to last sub link

=cut
sub add_sub_sub_link {
    my %link = @_;
    my $last_section  = $Thruk::Utils::Menu::navigation->[scalar @{$Thruk::Utils::Menu::navigation} - 1];
    my $last_link     = $last_section->{'links'}->[scalar @{$last_section->{'links'}} - 1];
    my $last_sub_link = $last_link->{'links'}->[scalar @{$last_link->{'links'}} - 1];
    $link{'target'}   = _get_menu_target() unless defined $link{'target'};
    $link{'href'}     = _get_menu_link($link{'href'});
    $link{'name'}     = "" unless defined $link{'name'};
    push(@{$last_sub_link->{'links'}}, \%link);
    return;
}


##############################################

=head2 add_search

  add_search()

add a new search to the last section

=cut
sub add_search {
    my %search = @_;
    my $last_section  = $Thruk::Utils::Menu::navigation->[scalar @{$Thruk::Utils::Menu::navigation} - 1];
    $search{'search'} = 1;
    $search{'target'} = _get_menu_target() unless defined $search{'target'};
    $search{'href'}   = _get_menu_link($search{'href'});
    push(@{$last_section->{'links'}}, \%search);
    return;
}

##############################################

=head2 insert_item

  insert_item()

add a new item in existing category

=cut
sub insert_item {
    my($category, $item) = @_;

    $Thruk::Utils::Menu::additional_items = [] unless defined $Thruk::Utils::Menu::additional_items;
    push @{$Thruk::Utils::Menu::additional_items}, [ $category, $item ];

    return 1;
}

##############################################

=head2 _get_menu_target

  _get_menu_target()

returns the current prefered target

=cut
sub _renew_navigation {
    my($c, $file) = @_;

    $Thruk::Utils::Menu::c          = $c;
    $Thruk::Utils::Menu::navigation = [];

    ## no critic
    eval(read_file($file));
    ## use critic
    if($@) {
        $c->log->error("error while loading navigation from ".$file.": ".$@);
        confess($@);
    }

    if(defined $Thruk::Utils::Menu::additional_items) {
        for my $to_add (@{$Thruk::Utils::Menu::additional_items}) {
            my $section       = _get_section_by_name($to_add->[0]) || next;
            my $link          = $to_add->[1];

            # only visible for some roles?
            if(defined $link->{'roles'}) {
                my $has_access = 1;
                my @roles = ref $link->{'roles'} eq 'ARRAY' ? @{$link->{'roles'}} : [ $link->{'roles'} ];
                for my $role (@roles) {
                    $has_access = 0 unless $c->check_user_roles( $role );
                }
                next unless $has_access;
            }

            $link->{'links'}  = [] unless defined $link->{'links'};
            $link->{'target'} = _get_menu_target() unless defined $link->{'target'};
            $link->{'href'}   = _get_menu_link($link->{'href'});
            push(@{$section->{'links'}}, $link);
        }
    }

    $c->stash->{'navigation'}  = $Thruk::Utils::Menu::navigation;
    if($c->config->{'cache_navigation'}) {
        $c->cache->set('navigation', $Thruk::Utils::Menu::navigation);
    }
    return;
}

##############################################

=head2 _get_menu_target

  _get_menu_target()

returns the current prefered target

=cut
sub _get_menu_target {
    my $c = $Thruk::Utils::Menu::c;

    return $c->{'stash'}->{'target'} if defined $c->{'stash'}->{'target'};
    if($c->{'stash'}->{'use_frames'}) {
        return("main");
    }
    return("_self");
}


##############################################

=head2 _get_menu_link

  _get_menu_link()

returns the link with prefix

=cut
sub _get_menu_link {
    my $link = shift;
    my $c = $Thruk::Utils::Menu::c;
    return "" unless defined $link;
    return $c->stash->{'url_prefix'}.substr($link,1) if $link =~ m/^\/thruk\//mx;
    return $link;
}


##############################################

=head2 _get_section_by_name

  _get_section_by_name()

returns a section by name

=cut
sub _get_section_by_name {
    my $name = shift;

    for my $section (@{$Thruk::Utils::Menu::navigation}) {
        return $section if $section->{'name'} eq $name;
    }
    return;
}

##############################################

1;

=head1 AUTHOR

Sven Nierlein, 2010, <nierlein@cpan.org>

=head1 LICENSE

This library is free software, you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut
