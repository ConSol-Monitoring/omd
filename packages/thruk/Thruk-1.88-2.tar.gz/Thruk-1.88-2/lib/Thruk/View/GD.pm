package Thruk::View::GD;
use parent 'Catalyst::View::GD';

use strict;

=head1 NAME

Thruk::View::GD - GD View for Thruk

=head1 DESCRIPTION

GD View for Thruk.

=head1 AUTHOR

=head1 SEE ALSO

L<Thruk>

Sven Nierlein, 2009-2014, <sven@nierlein.org>

=head1 LICENSE

This library is free software, you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
