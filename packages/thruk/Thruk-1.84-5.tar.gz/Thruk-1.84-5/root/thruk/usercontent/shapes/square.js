// See http://docs.sencha.com/extjs/4.1.1/#!/api/Ext.draw.Sprite
type: "rect",
width: 100,
height: 100
