Have two direct dependencies where one specifies a direct transient version,
and the other can take any transient but overlapping version. Resolving should pass.