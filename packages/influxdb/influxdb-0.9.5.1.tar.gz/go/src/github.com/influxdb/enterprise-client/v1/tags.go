package client

// Tags is a mapping of key/values representing tags
// in an InfluxDB instance
type Tags map[string]string
