package client

type Values map[string]interface{}
