package custombytesnonstruct

import testing "testing"

func TestCustomBytesNonStruct(t *testing.T) {
}
