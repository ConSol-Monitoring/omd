collectD Client
============
This directory contains code for generating collectd load.
