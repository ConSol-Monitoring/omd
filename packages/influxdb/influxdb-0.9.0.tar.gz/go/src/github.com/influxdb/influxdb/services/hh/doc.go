/*
Package hh implements a hinted handoff for writes

*/
package hh
