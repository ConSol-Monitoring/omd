Import govendor config in vendor dir.
