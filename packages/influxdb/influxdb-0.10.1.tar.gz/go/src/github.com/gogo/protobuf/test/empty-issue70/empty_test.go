package empty

import (
	"testing"
)

func TestEmpty(t *testing.T) {

}
