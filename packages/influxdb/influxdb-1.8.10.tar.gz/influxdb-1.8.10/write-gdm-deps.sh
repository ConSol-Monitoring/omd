#!/bin/bash
dep status -f $'{{.ProjectRoot}} {{.Revision}}\n'
