# histou
Adds templates to Grafana in combination with nagflux
