## v0.1.1 - upcoming:
### Features
- template cache

### Fixes
- multiple Grafana gaps

## v0.1.0 - 12.11.2015
### Features
- Change Dashboard to Grafana v.2.5.0

### Fixes
- changed panelid counter start to 1
- change background color only on dashboard-solo

## v0.0.1 - 29.10.2015
### Features
- Everything :wink:
