## v0.1.1 - upcoming:
### Features
- syntax check on php templates, malformed templates will be ignored but an error appears in the apache error.log
- template cache, the valid templates will be cached
- default datasource is the name of the influxdb database from the config

### Fixes
- multiple Grafana gaps
- simple template: naming problem
- star regex in perfLabel works, but an exact match wins against star
- downtime query warning within the query editor
- percentage in queries

## v0.1.0 - 12.11.2015
### Features
- Change Dashboard to Grafana v.2.5.0

### Fixes
- changed panelid counter start to 1
- change background color only on dashboard-solo

## v0.0.1 - 29.10.2015
### Features
- Everything :wink:
