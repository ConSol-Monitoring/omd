# histou [![Circle CI](https://circleci.com/gh/Griesbacher/histou/tree/master.svg?style=svg)](https://circleci.com/gh/Griesbacher/histou/tree/master)
Adds templates to Grafana in combination with nagflux
