[![Circle CI](https://circleci.com/gh/Griesbacher/histou/tree/master.svg?style=svg)](https://circleci.com/gh/Griesbacher/histou/tree/master)
[![Coverage Status](https://coveralls.io/repos/Griesbacher/histou/badge.svg?branch=master&service=github)](https://coveralls.io/github/Griesbacher/histou?branch=master)
# histou
Adds templates to Grafana in combination with nagflux
