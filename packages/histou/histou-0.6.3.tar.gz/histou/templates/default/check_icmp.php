<?php
/**
Icmp Check Template File.
@category Template_File
@package Histou/templates/default
@author Philip Griesbacher
@license http://opensource.org/licenses/gpl-license.php GNU Public License
@link https://github.com/ConSol/histou
**/

$rule = new \histou\template\Rule(
    $host = '*',
    $service = '*',
    $command = '*',
    $perfLabel = array('^rta$', '^pl$', '^rtmax$', '^rtmin$') /* does not work with check_icmp using multiple IPs right now */
);

$genTemplate = function ($perfData) {
    $colors = array('#085DFF', '#07ff78', '#db07ff');
    $dashboard = \histou\grafana\dashboard\DashboardFactory::generateDashboard($perfData['host'].'-'.$perfData['service']);

    $row = new \histou\grafana\Row($perfData['host'].' '.$perfData['service'].' '.$perfData['command']);
    $panelTitle = $perfData['host'].' - '.$perfData['service'].' - rta';
    if ($perfData['service'] == "hostcheck") {
        $panelTitle = $perfData['host'].' - rta';
    }
    $panel = \histou\grafana\graphpanel\GraphPanelFactory::generatePanel($panelTitle);
    $i = 0;
    foreach (array('rta', 'rtmin', 'rtmax') as $type) {
        $target = $panel->genTargetSimple($perfData['host'], $perfData['service'], $perfData['command'], $type, $colors[$i]);
        $target = $panel->addWarnToTarget($target, $type);
        $target = $panel->addCritToTarget($target, $type);
        $panel->addTarget($target);

        $downtime = $panel->genDowntimeTarget($perfData['host'], $perfData['service'], $perfData['command'], $type);
        $panel->addTarget($downtime);
        $panel->fillBelowLine($type.'-value', 2);
        $i++;
    }
    if (isset($perfData['perfLabel']['rta']['unit'])) {
        $panel->setLeftUnit($perfData['perfLabel']['rta']['unit']);
    }
    $row->addPanel($panel);
    $dashboard->addRow($row);
    $row = new \histou\grafana\Row($perfData['host'].' '.$perfData['service'].' '.$perfData['command']);
    $panelTitle = $perfData['host'].' - '.$perfData['service'].' - pl';
    if ($perfData['service'] == "hostcheck") {
        $panelTitle = $perfData['host'].' - pl';
    }
    $panel = \histou\grafana\graphpanel\GraphPanelFactory::generatePanel($panelTitle);
    $target = $panel->genTargetSimple($perfData['host'], $perfData['service'], $perfData['command'], 'pl');
    $target = $panel->addWarnToTarget($target, $type);
    $target = $panel->addCritToTarget($target, $type);
    $panel->addTarget($target);

    $downtime = $panel->genDowntimeTarget($perfData['host'], $perfData['service'], $perfData['command'], 'pl');
    $panel->addTarget($downtime);
    $panel->fillBelowLine($type.'-value', 2);

    $row->addPanel($panel);
    $dashboard->addRow($row);
    $dashboard->addDefaultAnnotations($perfData['host'], $perfData['service']);
    return $dashboard;
};
