interface PathPrefixProps {
  pathPrefix?: string;
}

export default PathPrefixProps;
