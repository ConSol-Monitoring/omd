export function specializeIdentifier(value: any, stack: any): any;
export function extendIdentifier(value: any, stack: any): any;
