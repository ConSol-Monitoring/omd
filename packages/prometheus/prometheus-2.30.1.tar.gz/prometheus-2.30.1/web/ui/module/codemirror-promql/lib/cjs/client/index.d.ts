export { PrometheusClient, PrometheusConfig, CacheConfig } from './prometheus';
export declare type FetchFn = (input: RequestInfo, init?: RequestInit) => Promise<Response>;
