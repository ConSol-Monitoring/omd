import { SyntaxNode } from 'lezer-tree';
import { ValueType } from '../types';
export declare function getType(node: SyntaxNode | null): ValueType;
