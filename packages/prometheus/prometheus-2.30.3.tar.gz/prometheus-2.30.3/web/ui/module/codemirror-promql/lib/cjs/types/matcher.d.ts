export declare class Matcher {
    type: number;
    name: string;
    value: string;
    constructor(type: number, name: string, value: string);
    matchesEmpty(): boolean;
}
