import { HighlightStyle } from '@codemirror/highlight';
export declare const promQLHighlightMaterialTheme: HighlightStyle;
export declare const customTheme: import("@codemirror/state").Extension;
