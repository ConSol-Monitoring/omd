export const API_PATH = 'api/v1';
