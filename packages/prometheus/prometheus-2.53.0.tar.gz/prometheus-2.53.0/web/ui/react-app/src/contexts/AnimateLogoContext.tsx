import { createContext } from 'react';

export const AnimateLogoContext = createContext<boolean>(false);
