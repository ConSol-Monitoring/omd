Maintainers of this repository with their focus areas:

* Björn Rabenstein <beorn@soundcloud.com>: Local storage; general code-level issues.
* Brian Brazil <brian.brazil@robustperception.io>: Console templates; semantics of PromQL, service discovery, and relabeling.
* Fabian Reinartz <fabian.reinartz@coreos.com>: PromQL parsing and evaluation; implementation of retrieval, alert notification, and service discovery.
* Julius Volz <julius.volz@gmail.com>: Remote storage integrations; web UI.

