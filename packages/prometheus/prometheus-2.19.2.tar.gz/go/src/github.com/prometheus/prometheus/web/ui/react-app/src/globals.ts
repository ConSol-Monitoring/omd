import jquery from 'jquery';

(window as any).jQuery = jquery;
(window as any).moment = require('moment');
