global.fetch = require('isomorphic-fetch')
