azuread package
=========================================

azuread provides an http.RoundTripper that attaches an Azure AD accessToken
to remote write requests.

This module is considered internal to Prometheus, without any stability
guarantees for external usage.
