# Text collector example scripts

These scripts are examples to be used with the Node Exporter Textfile
Collector.

For more information see:
https://github.com/prometheus/node_exporter#textfile-collector
