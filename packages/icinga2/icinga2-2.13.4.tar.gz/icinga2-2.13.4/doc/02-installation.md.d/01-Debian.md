# Install Icinga 2 on Debian
<!-- {% set debian = True %} -->
<!-- {% include "02-installation.md" %} -->
