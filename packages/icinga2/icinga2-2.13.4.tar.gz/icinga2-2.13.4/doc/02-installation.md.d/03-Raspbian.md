# Install Icinga 2 on Raspbian
<!-- {% set raspbian = True %} -->
<!-- {% include "02-installation.md" %} -->
