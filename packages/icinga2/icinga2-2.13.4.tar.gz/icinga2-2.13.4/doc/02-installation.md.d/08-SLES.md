# Install Icinga 2 on SLES
<!-- {% set sles = True %} -->
<!-- {% include "02-installation.md" %} -->
