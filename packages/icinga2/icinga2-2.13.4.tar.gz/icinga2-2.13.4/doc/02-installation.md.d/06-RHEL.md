# Install Icinga 2 on RHEL
<!-- {% set rhel = True %} -->
<!-- {% include "02-installation.md" %} -->
