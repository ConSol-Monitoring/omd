# Install Icinga 2 on Amazon Linux
<!-- {% set amazon_linux = True %} -->
<!-- {% include "02-installation.md" %} -->
