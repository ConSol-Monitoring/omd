# Install Icinga 2 on Windows
<!-- {% set windows = True %} -->
<!-- {% include "02-installation.md" %} -->
