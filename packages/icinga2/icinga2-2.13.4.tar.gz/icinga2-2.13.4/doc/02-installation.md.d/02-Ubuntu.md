# Install Icinga 2 on Ubuntu
<!-- {% set ubuntu = True %} -->
<!-- {% include "02-installation.md" %} -->
