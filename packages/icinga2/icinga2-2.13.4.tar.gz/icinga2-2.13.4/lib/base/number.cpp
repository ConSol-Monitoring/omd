/* Icinga 2 | (c) 2012 Icinga GmbH | GPLv2+ */

#include "base/number.hpp"
#include "base/primitivetype.hpp"

using namespace icinga;

REGISTER_BUILTIN_TYPE(Number, Number::GetPrototype());

