package main

import "github.com/prometheus/alertmanager/cli"

func main() {
	cli.Execute()
}
