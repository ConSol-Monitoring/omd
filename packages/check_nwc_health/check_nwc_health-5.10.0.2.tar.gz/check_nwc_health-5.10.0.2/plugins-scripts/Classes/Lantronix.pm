package Classes::Lantronix;
our @ISA = qw(Classes::Device);
use strict;
