package Classes::UPNP;
our @ISA = qw(Classes::Device);
use strict;

