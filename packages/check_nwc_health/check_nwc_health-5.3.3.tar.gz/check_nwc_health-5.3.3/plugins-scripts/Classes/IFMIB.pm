package Classes::IFMIB;
our @ISA = qw(Classes::Device);
use strict;

