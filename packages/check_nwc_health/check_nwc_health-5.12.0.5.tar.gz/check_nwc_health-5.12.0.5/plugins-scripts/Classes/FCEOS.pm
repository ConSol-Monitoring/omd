package Classes::FCEOS;
our @ISA = qw(Classes::Device);
use strict;

